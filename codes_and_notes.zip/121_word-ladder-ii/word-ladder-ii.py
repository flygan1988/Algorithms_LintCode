# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/word-ladder-ii
@Language: Python
@Datetime: 16-08-14 19:10
'''

from string import ascii_lowercase
class Solution:
    # @param start, a string
    # @param end, a string
    # @param dict, a set of string
    # @return a list of lists of string
    def findLadders(self, start, end, dict):
        # write your code here
        dict.add(start)
        dict.add(end)
        Map = {}
        distance = {}
        self.bfs(Map, distance, start, dict)
        result = []
        path = []
        self.dfs(Map, distance, result, path, start, end, dict)
        return result
        
    def bfs(self, Map, distance, start, dict):
        for word in dict:
            Map[word] = []
        distance[start] = 0
        queue = []
        queue.insert(0,start)
        while len(queue) != 0:
            cur = queue.pop()
            for neighbor in self.getNeighbors(cur, dict):
                Map[neighbor].append(cur)
                if neighbor not in distance:
                    distance[neighbor] = distance[cur] + 1
                    queue.insert(0,neighbor)
                    
    def dfs(self, Map, distance, result, path, start, cur, dict):
        path.insert(0,cur)
        if start == cur:
            result.append(list(path))
            #return
        #path.insert(0,cur)
        for neighbor in self.getNeighbors(cur, dict):
            if neighbor in distance and distance[neighbor] == distance[cur] - 1:
                self.dfs(Map, distance, result, path, start, neighbor, dict)
        path.pop(0)
        
    
    def getNeighbors(self, word, dict):
        neighbors = []
        for i in range(len(word)):
            for c in ascii_lowercase:
                if c == word[i]:
                    continue
                tmp = word[:i] + c + word[i+1:]
                if tmp in dict:
                    neighbors.append(tmp)
        return neighbors
            