/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/word-ladder-ii
@Language: Java
@Datetime: 16-08-14 18:11
*/

public class Solution {
    public List<List<String>> findLadders(String start, String end,
            Set<String> dict) {
        HashMap<String,ArrayList<String>> map = new HashMap<String,ArrayList<String>>();
        HashMap<String,Integer> distance = new HashMap<String,Integer>();
        dict.add(start);
        dict.add(end);
        bfs(start,map,distance,dict);
        List<List<String>> res = new ArrayList<List<String>>();
        List<String> path = new ArrayList<String>();
        dfs(start,end,res,path,map,distance);
        return res;
    }
    
    public void bfs(String start, HashMap<String,ArrayList<String>> map, HashMap<String,Integer> distance, Set<String> dict){
        Queue<String> q = new LinkedList<>();
        for(String word:dict){
            map.put(word,new ArrayList<String>());
        }
        q.offer(start);
        distance.put(start,0);
        while(!q.isEmpty()){
            String cur = q.poll();
            for(String word:getNextWords(cur,dict)){
                map.get(word).add(cur);
                if(!distance.containsKey(word)){
                    distance.put(word,distance.get(cur)+1);
                    q.offer(word);
                }
            }
        }
    } 
    
    public void dfs(String start, String cur, List<List<String>> res, List<String> path,HashMap<String,ArrayList<String>> map, HashMap<String,Integer> distance){
        path.add(cur);
        if(cur.equals(start)){
            Collections.reverse(path);
            res.add(new ArrayList<String>(path));
            Collections.reverse(path);
        }
        else{
            for(String word:map.get(cur)){
                if(distance.containsKey(word) && distance.get(word)+1 == distance.get(cur)){
                    dfs(start,word,res,path,map,distance);
                }
            }
        }
        path.remove(path.size()-1);
    }
    public ArrayList<String> getNextWords(String word, Set<String> dict){
        ArrayList<String> res = new ArrayList<String>();
        for(int i=0; i<word.length(); i++){
            for(char c='a'; c<='z'; c++){
                if(word.charAt(i) == c){
                    continue;
                }
                String next = word.substring(0,i) + c + word.substring(i+1);
                if(dict.contains(next)){
                    res.add(next);
                }
            }
        }
        return res;
    }
}