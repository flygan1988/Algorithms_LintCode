/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/word-search-ii
@Language: Java
@Datetime: 16-07-01 23:40
*/

class TrieNode{
    char c;
    String s;
    boolean hasWord = false;
    HashMap<Character,TrieNode> children = new HashMap<Character,TrieNode>();
    TrieNode(){};
    TrieNode(char c){
        this.c = c;
        s = "";
    }
}
public class Solution {
    /**
     * @param board: A list of lists of character
     * @param words: A list of string
     * @return: A list of string
     */
    TrieNode root = new TrieNode();
    int[] dx = {-1,1,0,0};
    int[] dy = {0,0,-1,1};
    public ArrayList<String> wordSearchII(char[][] board, ArrayList<String> words) {
        // write your code here
        //insert all the word into trie tree
        ArrayList<String> result = new ArrayList<String>();
        if(board == null || board.length == 0){
            return result;
        }
        for(String word:words){
            insertWord(word);
        }
        int m = board.length, n = board[0].length;
        boolean[][] visit = new boolean[m][n];
        //ArrayList<String> res = new ArrayList<String>();
        for(int i=0; i<m; i++){
            for(int j=0; j<n; j++){
                search(board,i,j,root,result);
            }
        }
        return result;
    }
    public void insertWord(String word){
        TrieNode cur = root;
        for(int i=0; i<word.length(); i++){
            char c = word.charAt(i);
            if(!cur.children.containsKey(c)){
                cur.children.put(c,new TrieNode(c));
            }
            cur = cur.children.get(c);
        }
        cur.hasWord = true;
        cur.s = word;
    }
    public void search(char[][] board, int x, int y, TrieNode root, ArrayList<String> res){
        if(root.hasWord){
            if(!res.contains(root.s)){
              res.add(root.s);  
            }
        }
        if(x<0 || x>=board.length || y<0 || y>=board[0].length || board[x][y]=='0' || root == null){
            return;
        }
        if(root.children.containsKey(board[x][y])){
            for(int i=0; i<4; i++){
                char now = board[x][y];
                board[x][y] = '0';
                search(board,x+dx[i],y+dy[i],root.children.get(now),res);
                board[x][y] = now;
            }
        }
    }
}