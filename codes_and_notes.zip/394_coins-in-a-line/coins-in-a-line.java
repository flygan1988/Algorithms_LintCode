/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/coins-in-a-line
@Language: Java
@Datetime: 16-07-06 04:08
*/

public class Solution {
    /**
     * @param n: an integer
     * @return: a boolean which equals to true if the first player will win
     */
    public boolean firstWillWin(int n) {
        // write your code here
        if(n == 0){
            return false;
        }
        boolean[] f = new boolean[2];
        f[0] = true;
        f[1] = true;
        for(int i=3; i<=n; i++){
            if(f[0] && f[1]){
                f[0] = f[1];
                f[1] = false;
            }else{
                f[0] = f[1];
                f[1] = true;
            }
        }
        return f[1];
    }
}