```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/coins-in-a-line
@Language: Markdown
@Datetime: 16-07-06 04:08
```

f[i] = false; only if f[i-1] == true && f[i-2] == true;