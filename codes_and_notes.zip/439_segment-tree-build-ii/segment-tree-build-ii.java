/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/segment-tree-build-ii
@Language: Java
@Datetime: 16-06-30 02:45
*/

/**
 * Definition of SegmentTreeNode:
 * public class SegmentTreeNode {
 *     public int start, end, max;
 *     public SegmentTreeNode left, right;
 *     public SegmentTreeNode(int start, int end, int max) {
 *         this.start = start;
 *         this.end = end;
 *         this.max = max
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution {
    /**
     *@param A: a list of integer
     *@return: The root of Segment Tree
     */
    public SegmentTreeNode build(int[] A) {
        // write your code here
        return helper(A,0,A.length-1);
        
    }
    public SegmentTreeNode helper(int[] A, int start, int end){
        SegmentTreeNode root = new SegmentTreeNode(start,end,maxValue(A,start,end));
        if(start > end){
            return null;
        }
        if(start == end){
            return root;
        }
        SegmentTreeNode left = helper(A,start,(start+end)/2);
        SegmentTreeNode right = helper(A,(start+end)/2+1,end);
        root.left = left;
        root.right = right;
        return root;
    }
    public int maxValue(int[] A, int start, int end){
        int max = Integer.MIN_VALUE;
        for(int i=start; i<=end; i++){
            max = Math.max(max,A[i]);
        }
        return max;
    }
}