```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/triangle
@Language: Markdown
@Datetime: 16-07-09 02:04
```

use dynamic programming;
use two-dimensional array f[x][y]to store the minimum sum from A[x][y] to the bottom.