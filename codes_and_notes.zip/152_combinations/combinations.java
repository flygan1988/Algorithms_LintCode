/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/combinations
@Language: Java
@Datetime: 16-07-05 16:37
*/

public class Solution {
    /**
     * @param n: Given the range of numbers
     * @param k: Given the numbers of combinations
     * @return: All the combinations of k numbers out of 1..n
     */
    public List<List<Integer>> combine(int n, int k) {
		// write your code here
		List<List<Integer>> res = new ArrayList<List<Integer>>();
		if(k > n){
		    return res;
		}
		ArrayList<Integer> list = new ArrayList<Integer>();
		helper(res,list,1,n,k);
		return res;
    }
    public void helper(List<List<Integer>> res, ArrayList<Integer> list, int start, int n, int k){
        if(list.size() == k){
            res.add(new ArrayList<Integer>(list));
            return;
        }
        for(int i=start; i<=n; i++){
            list.add(i);
            helper(res,list,i+1,n,k);
            list.remove(list.size()-1);
        }
    }
}