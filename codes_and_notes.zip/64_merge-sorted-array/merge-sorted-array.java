/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/merge-sorted-array
@Language: Java
@Datetime: 16-08-18 03:41
*/

class Solution {
    /**
     * @param A: sorted integer array A which has m elements, 
     *           but size of A is m+n
     * @param B: sorted integer array B which has n elements
     * @return: void
     */
    public void mergeSortedArray(int[] A, int m, int[] B, int n) {
        // write your code here
        for(int i=0; i<n; i++){
            int j = m-1;
            while(j >= 0){
                if(A[j] < B[i]){
                    break;
                }
                A[j+1] = A[j];
                j--;
            }
            A[j+1] = B[i];
            m++;
        }
    }
}