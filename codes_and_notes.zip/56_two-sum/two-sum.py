# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/two-sum
@Language: Python
@Datetime: 16-07-12 13:43
'''

class Solution:
    """
    @param numbers : An array of Integer
    @param target : target = numbers[index1] + numbers[index2]
    @return : [index1 + 1, index2 + 1] (index1 < index2)
    """
    def twoSum(self, numbers, target):
        # write your code here
        if not numbers or len(numbers) < 2:
            return []
        res = []
        dic = {}
        for i in range(len(numbers)):
            dic[numbers[i]] = i+1
        for i in range(len(numbers)):
            if target-numbers[i] in dic:
                res.append(i+1)
                res.append(dic[target-numbers[i]])
                return res
        return []