# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/subsets-ii
@Language: Python
@Datetime: 16-07-15 02:34
'''

class Solution:
    """
    @param S: A set of numbers.
    @return: A list of lists. All valid subsets.
    """
    def subsetsWithDup(self, S):
        # write your code here
        ans = []
        path = []
        visit = [False for i in range(len(S))]
        S.sort()
        self.search(ans, path, 0, visit, S)
        return ans
        
    def search(self, ans, path, pos, visit, S):
        ans.append(list(path))
        for i in range(pos, len(S)):
            if visit[i] or (i != 0 and S[i]==S[i-1] and not visit[i-1]):
                continue
            path.append(S[i])
            visit[i] = True
            self.search(ans, path, i+1, visit, S)
            path.pop()
            visit[i] = False