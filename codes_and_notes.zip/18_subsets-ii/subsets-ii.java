/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/subsets-ii
@Language: Java
@Datetime: 16-06-04 21:06
*/

class Solution {
    /**
     * @param S: A set of numbers.
     * @return: A list of lists. All valid subsets.
     */
    public ArrayList<ArrayList<Integer>> subsetsWithDup(ArrayList<Integer> S) {
        // write your code here
        ArrayList<ArrayList<Integer>> rst = new ArrayList<ArrayList<Integer>>();
        ArrayList<Integer> list = new ArrayList<Integer>();
        int pos = 0;
        Collections.sort(S);
        searchSubset(rst,list,S,0);
        return rst;
    }
    public void searchSubset(ArrayList<ArrayList<Integer>> rst, ArrayList<Integer> list, ArrayList<Integer> S, int pos){
        rst.add(new ArrayList(list));
        for(int i=pos; i<S.size(); i++){
            if(i != pos && S.get(i) == S.get(i-1)){
                continue;
            }
            list.add(S.get(i));
            searchSubset(rst,list,S,i+1);
            list.remove(list.size()-1);
        }
    }
}
