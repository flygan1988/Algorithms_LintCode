# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/find-peak-element
@Language: Python
@Datetime: 16-07-08 01:21
'''

class Solution:
    #@param A: An integers list.
    #@return: return any of peek positions.
    def findPeak(self, A):
        # write your code here
        left = 0
        right = len(A)-1
        while left < right-1:
            mid = (left + right)/2
            if A[mid] < A[mid+1]:
                left = mid
            else:
                right = mid
        if A[left] < A[right]:
            return right
        return left