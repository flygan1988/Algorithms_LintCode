/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/perfect-squares
@Language: Java
@Datetime: 16-07-01 05:01
*/

public class Solution {
    /**
     * @param n a positive integer
     * @return an integer
     */
     /**
    public int numSquares(int n) {
        // Write your code here
        ArrayList<Integer> nums = new ArrayList<Integer>();
        for(int i=1; i<n/2; i++){
            if(i*i < n){
                nums.add(i*i);
            }else{
                break;
            }
        }
        ArrayList<ArrayList<Integer>> res = new ArrayList<ArrayList<Integer>>(); 
        ArrayList<Integer> list = new ArrayList<Integer>();
        search(nums,list,n,res);
        return res.size()>0?res.get(0).size():0;
    }
    public void search(ArrayList<Integer> nums, ArrayList<Integer> list, int n, ArrayList<ArrayList<Integer>> res){
        if(n < 0){
            //list.clear();
            return;
        }
        if(n == 0){
            res.add(new ArrayList<Integer>(list));
            return;
        }
        for(int i=nums.size()-1; i>=0; i--){
            list.add(nums.get(i));
            search(nums,list,n-nums.get(i),res);
            list.remove(list.size()-1);
        }
    }**/
    public int numSquares(int n) {
        int[] memo = new int[n + 1];
        Arrays.fill(memo, Integer.MAX_VALUE);
        memo[0] = 0;
        int i = 0;
        while (++i * i <= n) {
            for (int j = i * i; j < memo.length; j++) {
                memo[j] = Math.min(memo[j], memo[j - (i * i)] + 1);
            }
        }
        return memo[n];
    }
}