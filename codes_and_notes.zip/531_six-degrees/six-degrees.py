# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/six-degrees
@Language: Python
@Datetime: 16-07-14 21:56
'''

# Definition for Undirected graph node
# class UndirectedGraphNode:
#     def __init__(self, x):
#         self.label = x
#         self.neighbors = []

class Solution:
    '''
    @param {UndirectedGraphNode[]} graph a list of Undirected graph node
    @param {UndirectedGraphNode} s, t two Undirected graph nodes
    @return {int} an integer
    '''
    def sixDegrees(self, graph, s, t):
        # Write your code here
        if s == t:
            return 0
        queue = []
        dic = {}
        queue.insert(0,s)
        dic[s] = True
        degree = 0
        while len(queue) != 0:
            size = len(queue)
            for i in range(size):
                now = queue.pop()
                #dic[now] = True
                for neighbor in now.neighbors:
                    if neighbor in dic:
                        continue
                    if neighbor == t:
                        degree += 1
                        return degree
                    queue.insert(0, neighbor)
                    dic[neighbor] = True
            degree += 1
        return -1