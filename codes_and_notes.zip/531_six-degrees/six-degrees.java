/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/six-degrees
@Language: Java
@Datetime: 16-06-04 18:39
*/

/**
 * Definition for Undirected graph.
 * class UndirectedGraphNode {
 *     int label;
 *     List<UndirectedGraphNode> neighbors;
 *     UndirectedGraphNode(int x) { 
 *         label = x;
 *         neighbors = new ArrayList<UndirectedGraphNode>(); 
 *     }
 * };
 */
public class Solution {
    /**
     * @param graph a list of Undirected graph node
     * @param s, t two Undirected graph nodes
     * @return an integer
     */
    //Solution 1: BFS
    public int sixDegrees(List<UndirectedGraphNode> graph,
                          UndirectedGraphNode s,
                          UndirectedGraphNode t) {
        // Write your code here
        int degree = 0;
        //boolean find = false;
        HashMap<UndirectedGraphNode,Boolean> visited = new HashMap<UndirectedGraphNode,Boolean>();
        Queue<UndirectedGraphNode> queue = new LinkedList<>();
        for(UndirectedGraphNode node:graph){
            visited.put(node,false);
        }
        queue.offer(s);
        //visited.put(s,true);
        while(!queue.isEmpty()){
            int size = queue.size();
            for(int i=0; i<size; i++){
                UndirectedGraphNode now = queue.poll();
                visited.put(now,true);
                if(now == t){
                    //find = true;
                    return degree;
                }
                for(UndirectedGraphNode node:now.neighbors){
                    if(!visited.get(node)){
                        queue.offer(node);
                    }
                }
            }
            degree++;
        }
        return -1;
    }
    public void dfs_degree(UndirectedGraphNode s, UndirectedGraphNode t, HashMap<UndirectedGraphNode,Boolean> visited, int degree, int tmp){
        //visited.put(s,true);
        if(s == t){
            tmp = degree;
            return;
        }
        for(UndirectedGraphNode node:s.neighbors){
            if(visited.get(node)){
                return;
            }
            degree++;
            visited.put(node,true);
            dfs_degree(node,t,visited,degree,tmp);
        }
        degree--;
    }
}