# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/lru-cache
@Language: Python
@Datetime: 16-07-14 03:45
'''

class Node:
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.prev = None
        self.next = None

class LRUCache:
    dic = {}
    head = Node(-1,-1)
    tail = Node(-1,-1)
    # @param capacity, an integer
    def __init__(self, capacity):
        # write your code here
        self.capacity = capacity
        LRUCache.head.next = LRUCache.tail
        LRUCache.tail.prev = LRUCache.head
    # @return an integer
    def get(self, key):
        # write your code here
        if key not in LRUCache.dic:
            return -1
        node = LRUCache.dic[key]
        value = node.value
        node.prev.next = node.next
        node.next.prev = node.prev
        self.moveTail(node)
        return value
    # @param key, an integer
    # @param value, an integer
    # @return nothing
    def set(self, key, value):
        # write your code here
        if self.get(key) != -1:
            LRUCache.dic[key].value = value
            return
        if len(LRUCache.dic) == self.capacity:
            k = LRUCache.head.next.key
            del LRUCache.dic[k]
            LRUCache.head.next = LRUCache.head.next.next
            LRUCache.head.next.prev = LRUCache.head
        node = Node(key,value)
        self.moveTail(node)
        LRUCache.dic[key] = node
        
    def moveTail(self, p):
        p.next = LRUCache.tail
        p.prev = LRUCache.tail.prev
        LRUCache.tail.prev = p
        p.prev.next = p