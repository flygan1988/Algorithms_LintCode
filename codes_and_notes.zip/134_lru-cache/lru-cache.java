/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/lru-cache
@Language: Java
@Datetime: 16-06-04 02:30
*/

class Node{
    Node prev;
    Node next;
    int key;
    int value;
    public Node(int key,int value){
        this.key = key;
        this.value = value;
        this.prev = null;
        this.next = null;
    }
}
public class Solution {
    HashMap<Integer,Node> hash = new HashMap<Integer,Node>();
    Node head = new Node(-1,-1);
    Node tail = new Node(-1,-1);
    int capacity;
    // @param capacity, an integer
    public Solution(int capacity) {
        // write your code here
        this.capacity = capacity;
        head.next = tail;
        tail.prev = head;
    }

    // @return an integer
    public int get(int key) {
        // write your code here
        if(!hash.containsKey(key)){
            return -1;
        }
        Node p = hash.get(key);
        p.prev.next = p.next;
        p.next.prev = p.prev;
        moveTail(p);
        return hash.get(key).value;
    }

    // @param key, an integer
    // @param value, an integer
    // @return nothing
    public void set(int key, int value) {
        // write your code here
        if(get(key)!=-1){
            hash.get(key).value = value;
            //moveTail(hash.get(key));
            return;
        }
        if(hash.size()==capacity){
            hash.remove(head.next.key);
            head.next = head.next.next;
            head.next.prev = head;
        }
        Node p = new Node(key,value);
        hash.put(key,p);
        moveTail(p);
    }
    public void moveTail(Node node){
        node.prev = tail.prev;
        tail.prev = node;
        node.prev.next = node;
        node.next = tail;
    }
}