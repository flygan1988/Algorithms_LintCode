# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/binary-tree-maximum-path-sum
@Language: Python
@Datetime: 16-07-08 22:30
'''

"""
Definition of TreeNode:
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left, self.right = None, None
"""
class resultType:
    def __init__(self, singlePath, maxPath):
        self.singlePath = singlePath
        self.maxPath = maxPath

class Solution:
    """
    @param root: The root of binary tree.
    @return: An integer
    """
    def maxPathSum(self, root):
        # write your code here
        res = self.helper(root)
        return res.maxPath
        
    def helper(self,root):
        if root is None:
            return resultType(0,-sys.maxint)
        left = self.helper(root.left)
        right = self.helper(root.right)
        
        singlePath = max(left.singlePath,right.singlePath)+root.val
        singlePath = max(singlePath,0)
        maxPath = max(left.maxPath,right.maxPath)
        maxPath = max(maxPath,left.singlePath+right.singlePath+root.val)
        
        return resultType(singlePath,maxPath);