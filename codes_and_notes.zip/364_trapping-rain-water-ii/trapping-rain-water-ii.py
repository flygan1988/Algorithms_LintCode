# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/trapping-rain-water-ii
@Language: Python
@Datetime: 16-08-04 21:27
'''

from heapq import heappush,heappop
class Solution:
    # @param heights: a matrix of integers
    # @return: an integer
    def trapRainWater(self, heights):
        # write your code here
        m = len(heights)
        n = len(heights[0])
        minheap = []
        offsets = [(-1,0),(1,0),(0,-1),(0,1)]
        visit = [[0 for j in range(n)] for i in range(m)]
        
        for i in range(m):
            heappush(minheap,(heights[i][0],i,0))
            visit[i][0] = 1
            heappush(minheap,(heights[i][n-1],i,n-1))
            visit[i][n-1] = 1
        for j in range(1,n-1):
            heappush(minheap,(heights[0][j],0,j))
            visit[0][j] = 1
            heappush(minheap,(heights[m-1][j],m-1,j))
            visit[m-1][j] = 1
        total = 0
        while len(minheap) != 0:
            h,x,y = heappop(minheap)
            for dx,dy in offsets:
                xx = x+dx
                yy = y+dy
                if xx>=0 and xx<m and yy>=0 and yy<n and not visit[xx][yy]:
                    visit[xx][yy] = 1
                    new_h = max(h,heights[xx][yy])
                    heappush(minheap,(new_h,xx,yy))
                    total += max(0,h-heights[xx][yy])
        return total
