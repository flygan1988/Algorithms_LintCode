/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/trapping-rain-water-ii
@Language: Java
@Datetime: 16-08-04 20:54
*/

class Point{
    int x, y, h;
    public Point(){};
    public Point(int x, int y, int h){
        this.x = x;
        this.y = y;
        this.h = h;
    }
}
class PointComparator implements Comparator<Point>{
    @Override
    public int compare(Point p1, Point p2){
        if(p1.h > p2.h){
            return 1;
        }
        else if(p1.h == p2.h){
            return 0;
        }
        else{
            return -1;
        }
    }
}
public class Solution {
    /**
     * @param heights: a matrix of integers
     * @return: an integer
     */
    int[] dx = {-1,1,0,0};
    int[] dy = {0,0,-1,1};
    public int trapRainWater(int[][] heights) {
        // write your code here
        if(heights.length == 0){
            return 0;
        }
        int res = 0;
        int m = heights.length;
        int n = heights[0].length;
        int[][] visited = new int[m][n];
        PriorityQueue<Point> q = new PriorityQueue<Point>(1,new PointComparator());
        for(int i=0; i<m; i++){
            q.offer(new Point(i,0,heights[i][0]));
            q.offer(new Point(i,n-1,heights[i][n-1]));
            visited[i][0] = 1;
            visited[i][n-1] = 1;
        }
        for(int j=1; j<n-1; j++){
            q.offer(new Point(0,j,heights[0][j]));
            q.offer(new Point(m-1,j,heights[m-1][j]));
            visited[0][j] = 1;
            visited[m-1][j] = 1;
        }
        while(!q.isEmpty()){
            Point p = q.poll();
            for(int i=0; i<4; i++){
                int nx = p.x + dx[i];
                int ny = p.y + dy[i];
                if(nx>=0 && nx<m && ny>=0 && ny<n && visited[nx][ny]==0){
                    visited[nx][ny] = 1;
                    q.offer(new Point(nx,ny,Math.max(p.h,heights[nx][ny])));
                    res = res + Math.max(0,p.h-heights[nx][ny]);
                }
            }
        }
        return res;
    }
};