```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/trapping-rain-water-ii
@Language: Markdown
@Datetime: 16-08-04 21:27
```

Data Structure:Heap
Using a two-dimension array to store wether a point in the array heights is visited. 
From outter to inner, pop the minimum item from the heap and judge its up,down,left,right item is visited. if visited, continue, otherwise put the item in the heap. Meanwhile update result if heights[item]>heights[minimum item].