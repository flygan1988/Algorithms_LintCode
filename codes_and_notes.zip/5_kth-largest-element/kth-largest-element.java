/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/kth-largest-element
@Language: Java
@Datetime: 16-05-19 04:40
*/

class Solution {
    /*
     * @param k : description of k
     * @param nums : array of nums
     * @return: description of return
     */
    public int kthLargestElement(int k, int[] nums) {
        // write your code here
        return helper(nums,0,nums.length-1,k);
    }
    public int helper(int[] nums, int start, int end, int k){
        int t = partion(nums,start,end);
        if(t+1 < k){
            return helper(nums,t+1,end,k);
        }
        else if(t+1 > k){
            return helper(nums,start,t-1,k);
        }
        else{
            return nums[t];
        }
    }
    public int partion(int[] nums, int start, int end){
        int left = start;
        int right = end;
        int pivot = nums[start];
        while(left < right){
            while(nums[right]<=pivot && left<right){
                right--;
            }
            nums[left] = nums[right];
            while(nums[left]>=pivot && left<right){
                left++;
            }
            nums[right] = nums[left];
        }
        nums[left] = pivot;
        return left;
    }
};