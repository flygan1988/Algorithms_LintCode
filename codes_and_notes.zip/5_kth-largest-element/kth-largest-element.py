# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/kth-largest-element
@Language: Python
@Datetime: 16-08-07 22:53
'''

class Solution:
    # @param k & A a integer and an array
    # @return ans a integer
    def kthLargestElement(self, k, A):
        return self.helper(A,0,len(A)-1,k)
        
    def helper(self, A, start, end, k):
        index = self.partition(A,start,end)
        if index == k-1:
            return A[index]
        elif index > k-1:
            return self.helper(A,start,index-1,k)
        else:
            return self.helper(A,index+1,end,k)
    
    def partition(self, A, start, end):
        pivot = A[start]
        left = start
        right = end
        while left < right:
            while left < right and A[right] <= pivot:
                right -= 1
            A[left] = A[right]
            while left < right and A[left] >= pivot:
                left += 1
            A[right] = A[left]
        A[left] = pivot
        return left
        