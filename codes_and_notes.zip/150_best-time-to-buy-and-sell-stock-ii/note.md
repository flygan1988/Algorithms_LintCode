```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/best-time-to-buy-and-sell-stock-ii
@Language: Markdown
@Datetime: 16-07-13 02:48
```

http://liangjiabin.com/blog/2015/04/leetcode-best-time-to-buy-and-sell-stock.html