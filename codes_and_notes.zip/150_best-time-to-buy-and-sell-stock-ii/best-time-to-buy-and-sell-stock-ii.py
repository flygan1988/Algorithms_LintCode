# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/best-time-to-buy-and-sell-stock-ii
@Language: Python
@Datetime: 16-07-13 02:48
'''

class Solution:
    """
    @param prices: Given an integer array
    @return: Maximum profit
    """
    def maxProfit(self, prices):
        # write your code here
        maxProfit = 0
        for i in range(1,len(prices)):
            if prices[i]>prices[i-1]:
                maxProfit += prices[i]-prices[i-1]
        return maxProfit