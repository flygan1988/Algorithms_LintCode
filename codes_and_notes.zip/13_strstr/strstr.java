/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/strstr
@Language: Java
@Datetime: 16-05-27 01:58
*/

class Solution {
    /**
     * Returns a index to the first occurrence of target in source,
     * or -1  if target is not part of source.
     * @param source string to be scanned.
     * @param target string containing the sequence of characters to match.
     */
    public int strStr(String source, String target) {
        //write your code here
        if(target == null || source == null){
            return -1;
        }
        if(target.length() == 0){
            return 0;
        }
        int j = 0;
        for(int i=0; i<source.length(); i++){
            if(source.charAt(i) == target.charAt(j)){
                j++;
                while(j<target.length()&&i+j<source.length()){
                    if(source.charAt(i+j)!=target.charAt(j)){
                        break;
                    }
                    j++;
                }
                if(j == target.length()){
                    return i;
                }
                else{
                    j = 0;
                }
            }
        }
        return -1;
    }
}
