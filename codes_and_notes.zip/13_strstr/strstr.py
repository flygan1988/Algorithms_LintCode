# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/strstr
@Language: Python
@Datetime: 16-08-17 18:49
'''

class Solution:
    def strStr(self, source, target):
        # write your code here
        if source is None or target is None:
            return -1
        if len(target) == 0:
            return 0
        
        for i in range(len(source)):
            j = 0
            if source[i] == target[j]:
                while j < len(target) and i+j < len(source):
                    if source[i+j] != target[j]:
                        break
                    j += 1
                if j == len(target):
                    return i
        return -1