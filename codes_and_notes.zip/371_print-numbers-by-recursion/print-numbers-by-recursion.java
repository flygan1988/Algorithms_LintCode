/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/print-numbers-by-recursion
@Language: Java
@Datetime: 16-06-30 15:46
*/

public class Solution {
    /**
     * @param n: An integer.
     * return : An array storing 1 to the largest number with n digits.
     */
    public List<Integer> numbersByRecursion(int n) {
        // write your code here
        List<Integer> result = new ArrayList<Integer>();
        if(n==0){
            return result;
        }
        helper(n,result);
        return result;
    }
    public int helper(int n, List<Integer> res){
        if(n == 0){
            return 1;
        }
        int base = helper(n-1,res);
        int size = res.size();
        for(int i=1; i<=9; i++){
            int curBase = i*base;
            res.add(curBase);
            for(int j=0; j<size; j++){
                res.add(curBase+res.get(j));
            }
        }
        return base*10;
    }
}