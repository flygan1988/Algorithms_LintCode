```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/reverse-linked-list-ii
@Language: Markdown
@Datetime: 16-07-10 14:51
```

first step: find the head node;
second step: find the mth node; using two pointer to point the next two nodes of mNode;
third step: loop