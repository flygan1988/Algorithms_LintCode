/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/reverse-linked-list-ii
@Language: Java
@Datetime: 16-03-27 19:09
*/

/**
 * Definition for ListNode
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) {
 *         val = x;
 *         next = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @param ListNode head is the head of the linked list 
     * @oaram m and n
     * @return: The head of the reversed ListNode
     */
    public ListNode reverseBetween(ListNode head, int m , int n) {
        // write your code
        if(head == null){
            return head;
        }
        ListNode dummy = new ListNode(0);
        dummy.next = head;
        head = dummy;
        for(int i=1; i<m; i++){
            if(head.next == null){
                return null;
            }
            head = head.next;
        }
        ListNode mNode = head.next;
        ListNode nNode = mNode;
        ListNode postNode = nNode.next;
        for(int i=m; i<n; i++){
            ListNode temp = postNode.next;
            postNode.next = nNode;
            nNode = postNode;
            postNode = temp;
        }
        head.next = nNode;
        mNode.next = postNode;
        return dummy.next;
        
    }
}