# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/median-of-two-sorted-arrays
@Language: Python
@Datetime: 16-07-12 16:04
'''

class Solution:
    """
    @param A: An integer array.
    @param B: An integer array.
    @return: a double whose format is *.5 or *.0
    """
    def findMedianSortedArrays(self, A, B):
        # write your code here
        k = (len(A)+len(B))/2
        if (len(A)+len(B))%2 == 1:
            return self.findKth(A,0,B,0,k+1)
        else:
            return (self.findKth(A,0,B,0,k)+self.findKth(A,0,B,0,k+1))/2.0
            
    def findKth(self, A, A_start, B, B_start, k):
        if A_start >= len(A):
            return B[B_start+k-1]
        if B_start >= len(B):
            return A[A_start+k-1]
        if k==1:
            return min(A[A_start],B[B_start])
            
        if A_start + k/2 -1 < len(A):
            A_key = A[A_start+k/2-1]
        else:
            A_key = sys.maxint
            
        if B_start + k/2 -1 < len(B):
            B_key = B[B_start+k/2-1]
        else:
            B_key = sys.maxint
            
        if A_key < B_key:
            return self.findKth(A,A_start+k/2,B,B_start,k-k/2)
        else:
            return self.findKth(A,A_start,B,B_start+k/2,k-k/2)