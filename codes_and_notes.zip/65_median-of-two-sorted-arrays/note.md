```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/median-of-two-sorted-arrays
@Language: Markdown
@Datetime: 16-07-12 16:04
```

Find the Kth largest number in array A and Array B, then the median is either (k+1)th largest number(when A.length + B.length is odd) or the half of the sum of the k th and the (k+1)th number(when A.length + B.length is even).
We set A_key = 
1. A[A_start+k/2-1], when the index less than A.length
2. Integer.MAX_VALUE, when the index is out of bound.
the same as B_key.
processing:
when A_key < B_key, we know that the k th number must be located at A[A_start + k/2] and B[B_start], then we can drop the numbers before A_start+k/2-1, this can be implemented by moving the start index to A_start+k/2. Recursively, we can get the kth number in A and B.
the same as B.
