/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/single-number
@Language: Java
@Datetime: 16-08-17 20:45
*/

public class Solution {
    /**
      *@param A : an integer array
      *return : a integer 
      */
    //Solution 1: O(nlogn)
    // public int singleNumber(int[] A) {
    //     // Write your code here
    //     if(A == null || A.length == 0){
    //         return 0;
    //     }
    //     Arrays.sort(A);
    //     for(int i=0; i<A.length-1; i++){
    //         if(A[i] != A[i+1]){
    //             return A[i];
    //         }
    //         i++;
    //     }
    //     return A[A.length-1];
    // }
    public int singleNumber(int[] A) {
        // Write your code here
        int ans = 0;
        for(int i=0; i<A.length; i++){
            ans = ans^A[i];
        }
        return ans;
    }
}