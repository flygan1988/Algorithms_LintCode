/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/letter-combinations-of-a-phone-number
@Language: Java
@Datetime: 16-06-09 03:24
*/

public class Solution {
    /**
     * @param digits A digital string
     * @return all posible letter combinations
     */
    public ArrayList<String> letterCombinations(String digits) {
        // Write your code here
        ArrayList<String> result = new ArrayList<String>();
        HashMap<Integer,String> map = new HashMap<Integer,String>();
        map.put(0,"");
        map.put(1,"");
        map.put(2,"abc"); 
        map.put(3,"def");
        map.put(4,"ghi");
        map.put(5,"jkl");
        map.put(6,"mno");
        map.put(7,"pqrs");
        map.put(8,"tuv");
        map.put(9,"wxyz");
        if(digits == null || digits.length() == 0){
            return result;
        }
        ArrayList<Character> tmp = new ArrayList<>();
        getString(digits,result,tmp,map);
        return result;
    }
    private void getString(String digits, ArrayList<String> result, ArrayList<Character> tmp, HashMap<Integer,String> map){
        if(digits.length() == 0){
            String s = "";
            for(int i=0; i<tmp.size(); i++){
                s += tmp.get(i);
            }
            result.add(s);
            return;
        }
        int curr = Integer.valueOf(digits.substring(0,1));
        String letters = map.get(curr);
        for(int i=0; i<letters.length(); i++){
            tmp.add(letters.charAt(i));
            getString(digits.substring(1),result,tmp,map);
            tmp.remove(tmp.size()-1);
        }
    }
}