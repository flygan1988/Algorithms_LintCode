```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/binary-search-tree-iterator
@Language: Markdown
@Datetime: 16-07-08 22:52
```

use a ArrayList nodes to nodes in in-order traveral.
index i to record the current position.