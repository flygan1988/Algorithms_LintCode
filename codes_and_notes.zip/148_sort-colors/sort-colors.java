/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/sort-colors
@Language: Java
@Datetime: 16-04-03 03:31
*/

class Solution {
    /**
     * @param nums: A list of integer which is 0, 1 or 2 
     * @return: nothing
     */
    private void swap(int[] a, int i, int j){
        int temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }
    public void sortColors(int[] nums) {
        // write your code here
        int pl = 0, pr = nums.length-1;
        int i = 0;
        while(i<=pr){
            if(nums[i] == 0){
                swap(nums,pl,i);
                i++;
                pl++;
            }
            else if(nums[i] == 1){
                i++;
            }
            else{
                swap(nums,pr,i);
                pr--;
            }
        }
    }
}