# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/sort-colors
@Language: Python
@Datetime: 16-07-11 22:38
'''

class Solution:
    """
    @param nums: A list of integer which is 0, 1 or 2 
    @return: nothing
    """
    def sortColors(self, nums):
        # write your code here
        pl = 0
        pr = len(nums)-1
        i = 0
        while i<=pr:
            if nums[i] == 0:
                self.swap(nums,pl,i)
                pl += 1
                i += 1
            elif nums[i] == 1:
                i += 1
            else:
                self.swap(nums, i, pr)
                pr -= 1
        
        
    def swap(self, nums, i, j):
        tmp = nums[i]
        nums[i] = nums[j]
        nums[j] = tmp