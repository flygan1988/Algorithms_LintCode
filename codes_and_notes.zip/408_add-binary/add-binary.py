# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/add-binary
@Language: Python
@Datetime: 16-08-19 16:48
'''

class Solution:
    # @param {string} a a number
    # @param {string} b a number
    # @return {string} the result
    def addBinary(self, a, b):
        # Write your code here
        diff = len(a)-len(b)
        if diff < 0:
            for i in range(-diff):
                a = "0"+a
        else:
            for i in range(diff):
                b = "0"+b
        p = 0
        result = ""
        for i in range(len(a)-1,-1,-1):
            c = int(a[i])+int(b[i])
            tmp = ""
            if c+p == 3:
                p = 1
                tmp = "1"
            elif c+p == 2:
                p = 1
                tmp = "0"
            elif c+p == 1:
                p = 0
                tmp = "1"
            else:
                p = 0
                tmp = "0"
            result = tmp + result
        if p == 1:
            result = "1" + result
        return result