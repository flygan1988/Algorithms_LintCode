/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/add-binary
@Language: Java
@Datetime: 16-06-11 16:34
*/

public class Solution {
    /**
     * @param a a number
     * @param b a number
     * @return the result
     */
    public String addBinary(String a, String b) {
        // Write your code here
        int aa = Integer.parseInt(a,2);
        int bb = Integer.parseInt(b,2);
        int cc = aa + bb;
        return Integer.toBinaryString(cc);
    }
}