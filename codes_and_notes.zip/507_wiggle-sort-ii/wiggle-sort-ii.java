/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/wiggle-sort-ii
@Language: Java
@Datetime: 16-06-23 03:23
*/

public class Solution {
    /**
     * @param nums a list of integer
     * @return void
     */
    public void wiggleSort(int[] nums) {
        // Write your code here
        int[] tmp = new int[nums.length];
        for(int i=0; i<nums.length; i++){
            tmp[i] = nums[i];
        }
        int mid = partition(tmp,0,nums.length-1,nums.length/2);
        int[] ans = new int[nums.length];
        for(int i=0; i<nums.length; i++){
            ans[i] = mid;
        }
        int l, r;
        if (nums.length % 2 == 0) {
            l = nums.length - 2;
            r = 1;
            for (int i = 0; i < nums.length; i++) {
                if (nums[i] < mid) {
                    ans[l] = nums[i];
                    l -= 2;
                } else if (nums[i] > mid) {
                    ans[r] = nums[i];
                    r += 2;
                }
            }
        } else {
            l = 0;
            r = nums.length - 2;
            for (int i = 0; i < nums.length; i++) {
                if (nums[i] < mid) {
                    ans[l] = nums[i];
                    l += 2;
                } else if (nums[i] > mid) {
                    ans[r] = nums[i];
                    r -= 2;
                }
            }
        }
        for (int i = 0; i < nums.length; i++) {
            nums[i] = ans[i];
        }
    }
    public int partition(int[] nums, int start, int end, int rank){
        int left = start;
        int right = end;
        int now = nums[start];
        while(left < right){
            while(left < right && nums[right] >= now){
                right--;
            }
            nums[left] = nums[right];
            while(left < right && nums[left] <= now){
                left++;
            }
            nums[right] = nums[left];
        }
        if(left-start == rank){
            return now;
        }else if(left-start < rank){
            return partition(nums,left+1,end,rank-(left-start+1));
        }else{
            return partition(nums,start,right-1,rank);
        }
    }
}
