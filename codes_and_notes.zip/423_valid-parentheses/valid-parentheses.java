/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/valid-parentheses
@Language: Java
@Datetime: 16-06-21 13:48
*/

public class Solution {
    /**
     * @param s A string
     * @return whether the string is a valid parentheses
     */
    public boolean isValidParentheses(String s) {
        // Write your code here
        Stack<Character> stack = new Stack<>();
        for(int i=0; i<s.length(); i++){
            if(s.charAt(i)=='(' || s.charAt(i)=='[' || s.charAt(i)=='{'){
                stack.push(s.charAt(i));
            }
            if(s.charAt(i)==')' || s.charAt(i)==']' || s.charAt(i)=='}'){
                if(stack.size() == 0) return false;
                if(!match(stack.pop(),s.charAt(i))) return false;
            }
        }
        if(stack.size() != 0) return false;
        return true;
    }
    private boolean match(Character c, Character t){
        if(c == '(' && t == ')'){
            return true;
        }else if(c == '[' && t == ']'){
            return true;
        }else if(c == '{' && t == '}'){
            return true;
        }else{
            return false;
        }
    }
}