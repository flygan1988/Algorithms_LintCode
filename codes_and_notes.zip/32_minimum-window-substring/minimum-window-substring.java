/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/minimum-window-substring
@Language: Java
@Datetime: 16-05-21 02:01
*/

public class Solution {
    /**
     * @param source: A string
     * @param target: A string
     * @return: A string denote the minimum window
     *          Return "" if there is no such a string
     */
    public String minWindow(String source, String target) {
        // write your code
        int i=0, j=0;
        int curMin = Integer.MAX_VALUE;
        String s = "";
        String ans = "";
        for(i=0; i<source.length(); i++){
            while(j<source.length() && !isContain(s,target)){
                s += source.charAt(j);
                j++;
            }
            if(isContain(s,target) && s.length()<curMin){
                curMin = s.length();
                ans = s;
            }
            if(s.length()>1){
                s = s.substring(1,s.length());
            }
            else{
                s = "";
            }
        }
        return ans;
    }
    public boolean isContain(String source, String target){
        if(source == "" || source.length() < target.length()){
            return false;
        }
        HashMap<Character,Integer> map_s = new HashMap<Character,Integer>();
        HashMap<Character,Integer> map_t = new HashMap<Character,Integer>();
        for(int i=0; i<source.length(); i++){
            if(!map_s.containsKey(source.charAt(i))){
                map_s.put(source.charAt(i),1);
            }
            else{
                map_s.put(source.charAt(i),map_s.get(source.charAt(i))+1);
            }
        }
        for(int i=0; i<target.length(); i++){
            if(!map_t.containsKey(target.charAt(i))){
                map_t.put(target.charAt(i),1);
            }
            else{
                map_t.put(target.charAt(i),map_t.get(target.charAt(i))+1);
            }
        }
        for(int j=0; j<target.length(); j++){
            if(!map_s.containsKey(target.charAt(j)) || map_s.get(target.charAt(j))<map_t.get(target.charAt(j))){
                return false;
            }
        }
        return true;
    }
}