# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/minimum-window-substring
@Language: Python
@Datetime: 16-08-07 22:15
'''

class Solution:
    """
    @param source: A string
    @param target: A string
    @return: A string denote the minimum window
             Return "" if there is no such a string
    """
    def minWindow(self, source, target):
        # write your code here
        if not self.isContain(source, target):
            return ""
        s = ""
        ans = ""
        j = 0
        minLen = sys.maxint
        for i in range(len(source)):
            while j < len(source) and not self.isContain(s,target):
                s += source[j]
                j += 1
            if self.isContain(s,target) and len(s) < minLen:
                ans = s
                minLen = len(s)
            s = s[1:j]
        return ans
        
    def isContain(self, source, target):
        map_s = {}
        map_t = {}
        for s in source:
            if s not in map_s:
                map_s[s] = 1
            else:
                map_s[s] += 1
        for t in target:
            if t not in map_t:
                map_t[t] = 1
            else:
                map_t[t] += 1
        for c in map_t:
            if c not in map_s or map_t[c] > map_s[c]:
                return False
        return True