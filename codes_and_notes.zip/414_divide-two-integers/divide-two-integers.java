/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/divide-two-integers
@Language: Java
@Datetime: 16-08-25 22:20
*/

public class Solution {
    /**
     * @param dividend the dividend
     * @param divisor the divisor
     * @return the result
     */
    // public int divide(int dividend, int divisor) {
    //     // Write your code here
    //     if(dividend > Integer.MAX_VALUE || dividend < Integer.MIN_VALUE || divisor == 0 || divisor > Integer.MAX_VALUE || divisor < Integer.MIN_VALUE ){
    //         return Integer.MAX_VALUE;
    //     }
    //     int sign = 1;
    //     if(dividend < 0 && divisor >= 0){
    //         sign = -1;
    //         dividend = -dividend;
    //     }else if(dividend >=0 && divisor < 0){
    //         sign = -1;
    //         divisor = -divisor;
    //     }else if(dividend < 0 && divisor < 0){
    //         dividend = -dividend;
    //         divisor = -divisor;
    //     }
    //     if(dividend < divisor){
    //         return 0;
    //     }
        
    //     int power = 0;
    //     while((1 << power)*divisor <= dividend){
    //         power++;
    //     }
    //     int part = 1<<(power-1);
    //     return (part + divide(dividend-part*divisor, divisor))*sign;
    // }
    public int divide(int dividend, int divisor) {
		if(dividend==Integer.MIN_VALUE && divisor==-1) return Integer.MAX_VALUE;
        if(dividend > 0 && divisor > 0) return divideHelper(-dividend, -divisor);
        else if(dividend > 0) return -divideHelper(-dividend,divisor);
        else if(divisor > 0) return -divideHelper(dividend,-divisor);
        else return divideHelper(dividend, divisor);
    }
    
    private int divideHelper(int dividend, int divisor){
        // base case
        if(divisor < dividend) return 0;
        // get highest digit of divisor
        int cur = 0, res = 0;
        while((divisor << cur) >= dividend && divisor << cur < 0 && cur < 31) cur++;
        res = dividend - (divisor << cur-1);
        if(res > divisor) return 1 << cur-1;
        return (1 << cur-1)+divide(res, divisor);
    }
}