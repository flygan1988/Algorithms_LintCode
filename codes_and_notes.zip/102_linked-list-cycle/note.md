```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/linked-list-cycle
@Language: Markdown
@Datetime: 16-03-28 20:28
```

use two pointer slow and fast.
slow travels every one step but fast travels every two steps.
the two pointer will encounter each other if there if a circle in the list. otherwise, return false.