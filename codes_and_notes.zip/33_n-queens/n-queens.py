# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/n-queens
@Language: Python
@Datetime: 16-07-15 03:41
'''

class Solution:
    """
    Get all distinct N-Queen solutions
    @param n: The number of queens
    @return: All distinct solutions
    """
    def solveNQueens(self, n):
        # write your code here
        ans = []
        if n<=0:
            return ans
        cols = []
        self.helper(ans, cols, n)
        return ans
        
    def isvalid(self, cols, col):
        rows = len(cols)
        for k in range(rows):
            if cols[k] == col:
                return False
            if k-cols[k] == rows-col:
                return False
            if k+cols[k] == rows+col:
                return False
        return True
    def draw(self, cols):
        res = []
        for i in range(len(cols)):
            s = ""
            for j in range(len(cols)):
                if j != cols[i]:
                    s += "."
                else:
                    s += "Q"
            res.append(s)
        return res
        
    def helper(self, ans, cols, n):
        if len(cols) == n:
            ans.append(self.draw(cols))
            return
        for i in range(n):
            if not self.isvalid(cols,i):
                continue
            cols.append(i)
            self.helper(ans, cols, n)
            cols.pop()
