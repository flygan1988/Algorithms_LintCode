/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/n-queens
@Language: Java
@Datetime: 16-04-07 04:07
*/

class Solution {
    /**
     * Get all distinct N-Queen solutions
     * @param n: The number of queens
     * @return: All distinct solutions
     * For example, A string '...Q' shows a queen on forth position
     */
    private ArrayList<String> drawChessBoard(ArrayList<Integer> cols){
        ArrayList<String> result = new ArrayList<String>();
        for(int i=0; i<cols.size(); i++){
            String temp = "";
            for(int j=0; j<cols.size(); j++){
                if(j == cols.get(i)){
                    temp += "Q";
                }
                else{
                    temp += ".";
                }
            }
            result.add(temp);
        }
        return result;
    }
    private boolean isValid(ArrayList<Integer> cols, int col){
        int rows = cols.size();
        for(int i=0; i<rows; i++){
            if(cols.get(i) == col){
                return false;
            }
            if(i-cols.get(i) == rows-col){
                return false;
            }
            if(i+cols.get(i) == rows+col){
                return false;
            }
        }
        return true;
    }
    private void search(ArrayList<ArrayList<String>> result, ArrayList<Integer> cols, int n){
        if(cols.size() == n){
            result.add(drawChessBoard(cols));
            return;
        }
        for(int i=0; i<n; i++){
            if(!isValid(cols,i)){
                continue;
            }
            cols.add(i);
            search(result,cols,n);
            cols.remove(cols.size()-1);
        }
    }
    public ArrayList<ArrayList<String>> solveNQueens(int n) {
        // write your code here
        ArrayList<ArrayList<String>> result = new ArrayList<ArrayList<String>>();
        if(n <= 0){
            return result;
        }
        ArrayList<Integer> cols = new ArrayList<Integer>();
        search(result,cols,n);
        return result;
    }
};