/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/k-closest-numbers-in-sorted-array
@Language: Java
@Datetime: 16-07-03 03:17
*/

class Pair{
    int num;
    int diff;
    Pair(int num, int diff){
        this.num = num;
        this.diff = diff;
    }
}
class MyComparator implements Comparator<Pair>{
    public int compare(Pair p1, Pair p2){
        if(p1.diff != p2.diff){
            return p1.diff - p2.diff;
        }else{
            return p1.num - p2.num;
        }
    }
}
public class Solution {
    /**
     * @param A an integer array
     * @param target an integer
     * @param k a non-negative integer
     * @return an integer array
     */
    public int[] kClosestNumbers(int[] A, int target, int k) {
        // Write your code here
        int[] res = new int[k];
        int left = 0, right = A.length-1;
        while(left < right-1){
            int mid = left + (right-left)/2;
            if(target > A[mid]){
                left = mid;
            }else{
                right = mid;
            }
        }
        int i=0;
        for(i=0; i<k&&left>=0&&right<A.length; i++){
            if(Math.abs(A[left]-target) <= Math.abs(A[right]-target)){
                res[i] = A[left];
                left--;
            }else{
                res[i] = A[right];
                right++;
            }
        }
        if(left == -1){
            for(int j=i; j<k; j++){
                res[j] = A[right];
                right++;
            }
            return res;
        }
        for(int j=i; j<k; j++){
            res[j] = A[left];
            left--;
        }
        return res;
    }
}