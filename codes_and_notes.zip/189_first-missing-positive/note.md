```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/first-missing-positive
@Language: Markdown
@Datetime: 16-07-03 04:24
```

http://bangbingsyb.blogspot.com/2014/11/leetcode-first-missing-positive.html