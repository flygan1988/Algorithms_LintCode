/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/first-missing-positive
@Language: Java
@Datetime: 16-07-03 04:24
*/

public class Solution {
    /**    
     * @param A: an array of integers
     * @return: an integer
     */
    public int firstMissingPositive(int[] A) {
        // write your code here  
        if(A == null || A.length == 0){
            return 1;
        }
        int[] B = new int[A.length];
        for(int i=0; i<A.length; i++){
            if(A[i]<=0 || A[i]>A.length){
                continue;
            }
            B[A[i]-1] = A[i];
        }
        for(int i=0; i<B.length; i++){
            if(B[i] != i+1){
                return i+1;
            }
        }
        return A.length+1;
    }
}