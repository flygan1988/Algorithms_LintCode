/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/lowest-common-ancestor-ii
@Language: Java
@Datetime: 16-06-16 16:04
*/

/**
 * Definition of ParentTreeNode:
 * 
 * class ParentTreeNode {
 *     public ParentTreeNode parent, left, right;
 * }
 */
public class Solution {
    /**
     * @param root: The root of the tree
     * @param A, B: Two node in the tree
     * @return: The lowest common ancestor of A and B
     */
    //solutin1
    /**
    public ParentTreeNode lowestCommonAncestorII(ParentTreeNode root,
                                                 ParentTreeNode A,
                                                 ParentTreeNode B) {
        // Write your code here 
        HashSet<ParentTreeNode> hash = new HashSet<ParentTreeNode>();
        ParentTreeNode p = A;
        ParentTreeNode q = B;
        while(p != null){
            hash.add(p);
            p = p.parent;
        }
        while(!hash.contains(q)){
            q = q.parent;
        }
        return q;
    }**/
    //solution 2:
    public ParentTreeNode lowestCommonAncestorII(ParentTreeNode root, ParentTreeNode node1, ParentTreeNode node2) {
        if (root == null || root == node1 || root == node2) {
            return root;
        }
        
        // Divide
        ParentTreeNode left = lowestCommonAncestorII(root.left, node1, node2);
        ParentTreeNode right = lowestCommonAncestorII(root.right, node1, node2);
        
        // Conquer
        if (left != null && right != null) {
            return root;
        } 
        if (left != null) {
            return left;
        }
        if (right != null) {
            return right;
        }
        return null;
    }
}
