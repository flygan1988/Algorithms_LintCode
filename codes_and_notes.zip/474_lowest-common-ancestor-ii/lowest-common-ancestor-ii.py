# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/lowest-common-ancestor-ii
@Language: Python
@Datetime: 16-07-08 03:44
'''

"""
Definition of ParentTreeNode:
class ParentTreeNode:
    def __init__(self, val):
        self.val = val
        self.parent, self.left, self.right = None, None, None
"""
class Solution:
    """
    @param root: The root of the tree
    @param A and B: Two node in the tree
    @return: The lowest common ancestor of A and B
    """ 
    def lowestCommonAncestorII(self, root, A, B):
        # Write your code here
        return self.helper(root,A,B)
    def helper(self, root, A, B):
        if root is None:
            return None
        if root == A or root == B:
            return root
        left = self.helper(root.left,A,B)
        right = self.helper(root.right,A,B)
        if left is None:
            return right
        if right is None:
            return left
        return root
        
