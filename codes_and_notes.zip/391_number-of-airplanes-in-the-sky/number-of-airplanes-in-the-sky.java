/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/number-of-airplanes-in-the-sky
@Language: Java
@Datetime: 16-05-11 04:37
*/

/**
 * Definition of Interval:
 * public classs Interval {
 *     int start, end;
 *     Interval(int start, int end) {
 *         this.start = start;
 *         this.end = end;
 *     }
 */
class Point{
    int time;
    int flag; // 1:fly, 0:land
    Point(int t, int f){
        this.time = t;
        this.flag = f;
    }
}
class Solution {
    /**
     * @param intervals: An interval array
     * @return: Count of airplanes are in the sky.
     */
    public int countOfAirplanes(List<Interval> airplanes) { 
        // write your code here
        if(airplanes == null || airplanes.size() == 0){
            return 0;
        }
        List<Point> points = new ArrayList<Point>(airplanes.size()*2);
        for(Interval i:airplanes){
            points.add(new Point(i.start,1));
            points.add(new Point(i.end,0));
        }
        Collections.sort(points,new Comparator<Point>(){
            public int compare(Point p1,Point p2){
                if(p1.time == p2.time){
                    return p1.flag - p2.flag;
                }
                else{
                    return p1.time - p2.time;
                }
            }
        });
        int cur = 0;
        int ans = 0;
        for(Point p:points){
            if(p.flag == 1){
                cur++;
            }
            else{
                cur--;
            }
            ans = Math.max(ans,cur);
        }
        return ans;
    }
}