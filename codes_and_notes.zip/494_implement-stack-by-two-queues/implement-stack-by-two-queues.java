/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/implement-stack-by-two-queues
@Language: Java
@Datetime: 16-05-18 04:44
*/

class Stack {
    // Push a new item into the stack
    Queue<Integer> q1 = new LinkedList<>();
    Queue<Integer> q2 = new LinkedList<>();
    public void push(int x) {
        // Write your code here
        q1.offer(x);
    }

    // Pop the top of the stack
    public void pop() {
        // Write your code here
        while(q1.size()>1){
            q2.offer(q1.poll());
        }
        q1.poll();
        while(!q2.isEmpty()){
            q1.offer(q2.poll());
        }
    }

    // Return the top of the stack
    public int top() {
        // Write your code here
        while(q1.size()>1){
            q2.offer(q1.poll());
        }
        int res = q1.poll();
        while(!q2.isEmpty()){
            q1.offer(q2.poll());
        }
        q1.offer(res);
        return res;
    }

    // Check the stack is empty or not.
    public boolean isEmpty() {
        // Write your code here
        if(q1.isEmpty()){
            return true;
        }
        return false;
    }    
}