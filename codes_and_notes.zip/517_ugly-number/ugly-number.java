/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/ugly-number
@Language: Java
@Datetime: 16-08-12 22:45
*/

public class Solution {
    /**
     * @param num an integer
     * @return true if num is an ugly number or false
     */
    public boolean isUgly(int num) {
        // Write your code here
        if(num == 0){
            return false;
        }
        while(num != 1){
            if(num%2 == 0){
                num /= 2;
            }else if(num%3 == 0){
                num /=3;
            }else if(num%5 == 0){
                num /= 5;
            }else{
                return false;
            }
        }
        return true;
    }
}