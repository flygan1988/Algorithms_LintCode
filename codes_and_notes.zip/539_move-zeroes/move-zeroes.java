/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/move-zeroes
@Language: Java
@Datetime: 16-06-18 02:15
*/

public class Solution {
    /**
     * @param nums an integer array
     * @return nothing, do this in-place
     */
    public void moveZeroes(int[] nums) {
        // Write your code here
        if(nums == null || nums.length == 0){
            return;
        }
        int i=0, k=0;
        while(k<nums.length){
            while(i < nums.length && nums[i] != 0){
                i++;
            }
            k = i+1;
            while(k < nums.length && nums[k] == 0){
                k++;
            }
            if(i < nums.length && k < nums.length){
                nums[i] = nums[k];
                nums[k] = 0;
                i++;
                k++; 
            }
        }
    }
}