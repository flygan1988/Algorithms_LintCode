```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/3sum
@Language: Markdown
@Datetime: 16-07-13 04:02
```

1. sort the original array
2. let target = -numbers[numbers.lenth-1,....,1]
3. find a and b that a+b=target in the numbers that are less than -target