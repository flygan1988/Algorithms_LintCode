# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/3sum
@Language: Python
@Datetime: 16-07-13 04:02
'''

class Solution:
    """
    @param numbersbers : Give an array numbersbers of n integer
    @return : Find all unique triplets in the array which gives the sum of zero.
    """
    def threeSum(self, numbers):
        # write your code here
        if not numbers or len(numbers) < 3:
            return []
        ans = []
        numbers.sort()
        for i in range(len(numbers)):
            left = i+1
            right = len(numbers)-1
            while left < right:
                if numbers[left] + numbers[right] == 0 - numbers[i]:
                    tmp = []
                    tmp.append(numbers[i])
                    tmp.append(numbers[left])
                    tmp.append(numbers[right])
                    if tmp not in ans:
                        ans.append(tmp)
                    left += 1
                    right -= 1
                elif numbers[left] + numbers[right] < 0 - numbers[i]:
                    left += 1
                else:
                    right -= 1
        return ans