/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/3sum
@Language: Java
@Datetime: 16-04-03 00:45
*/

public class Solution {
    /**
     * @param numbers : Give an array numbers of n integer
     * @return : Find all unique triplets in the array which gives the sum of zero.
     */
    public ArrayList<ArrayList<Integer>> threeSum(int[] numbers) {
        // write your code here
        ArrayList<ArrayList<Integer>> result = new ArrayList<ArrayList<Integer>>();
        //int target = 0;
        Arrays.sort(numbers);
        for(int i=numbers.length-1; i>0; i--){
            int target = -numbers[i];
            int left = 0, right = i-1;
            while(left < right){
                if(numbers[left] + numbers[right] == target){
                    ArrayList<Integer> temp = new ArrayList<Integer>();
                    temp.add(numbers[left]);
                    temp.add(numbers[right]);
                    temp.add(numbers[i]);
                    if(!result.contains(temp)){
                        result.add(temp);
                    }
                    left++;
                }
                else if(numbers[left] + numbers[right] < target){
                    left++;
                }
                else{
                    right--;
                }
            }
        }
        return result;
    }
}