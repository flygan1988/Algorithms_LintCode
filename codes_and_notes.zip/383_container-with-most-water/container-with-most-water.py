# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/container-with-most-water
@Language: Python
@Datetime: 16-08-05 20:53
'''

class Solution:
    # @param heights: a list of integers
    # @return: an integer
    def maxArea(self, heights):
        # write your code here
        area = 0
        left = 0
        right = len(heights)-1
        while left < right:
            if heights[left] <= heights[right]:
                area = max(area,(right-left)*heights[left])
                left += 1
            else:
                area = max(area,(right-left)*heights[right])
                right -= 1
        return area