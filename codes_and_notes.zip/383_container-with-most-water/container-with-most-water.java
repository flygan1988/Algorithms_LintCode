/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/container-with-most-water
@Language: Java
@Datetime: 16-05-19 03:18
*/

public class Solution {
    /**
     * @param heights: an array of integers
     * @return: an integer
     */
    public int maxArea(int[] heights) {
        // write your code here
        int left = 0;
        int right = heights.length - 1;
        int max = 0;
        while(left < right){
            if(heights[left]<=heights[right]){
                max = Math.max(max,heights[left]*(right-left));
                left++;
            }else{
                max = Math.max(max,heights[right]*(right-left));
                right--;
            }
        }
        return max;
    }
}