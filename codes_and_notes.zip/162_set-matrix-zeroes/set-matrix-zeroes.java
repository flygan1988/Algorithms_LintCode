/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/set-matrix-zeroes
@Language: Java
@Datetime: 16-06-27 22:01
*/

class Point{
    int x;
    int y;
    Point(int x, int y){
        this.x = x;
        this.y = y;
    }
}
public class Solution {
    /**
     * @param matrix: A list of lists of integers
     * @return: Void
     */
    public void setZeroes(int[][] matrix) {
        // write your code here
        if(matrix == null || matrix.length == 0){
            return;
        }
        ArrayList<Point> res = new ArrayList<Point>();
        int m = matrix.length;
        int n = matrix[0].length;
        for(int i=0; i<m; i++){
            for(int j=0; j<n; j++){
                if(matrix[i][j] == 0){
                    res.add(new Point(i,j));
                }
            }
        }
        for(Point p:res){
            fillZeros(matrix,p.x,p.y);
        }
    }
    public void fillZeros(int[][] matrix, int x, int y){
        int m = matrix.length;
        int n = matrix[0].length;
        for(int i=0; i<m; i++){
            matrix[i][y] = 0;
        }
        for(int i=0; i<n; i++){
            matrix[x][i] = 0;
        }
    }
}