# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/house-robber
@Language: Python
@Datetime: 16-08-08 04:06
'''

class Solution:
    # @param A: a list of non-negative integers.
    # return: an integer
    def houseRobber(self, A):
        # write your code here
        if not A or len(A) == 0:
            return 0
        if len(A) == 1:
            return A[0]
        f = [0 for i in range(len(A))]
        f[0] = A[0]
        f[1] = max(A[0],A[1])
        for i in range(2,len(A)):
            f[i] = max(f[i-1],f[i-2]+A[i])
        return f[len(A)-1]