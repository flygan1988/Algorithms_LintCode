/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/implement-trie
@Language: Java
@Datetime: 16-05-16 20:23
*/

/**
 * Your Trie object will be instantiated and called as such:
 * Trie trie = new Trie();
 * trie.insert("lintcode");
 * trie.search("lint"); will return false
 * trie.startsWith("lint"); will return true
 */
class TrieNode {
    // Initialize your data structure here.
    char c;
    HashMap<Character,TrieNode> children = new HashMap<Character,TrieNode>();
    boolean hasWord = false;
    public TrieNode() {
        
    }
    public TrieNode(char c){
        this.c = c;
    }
}

public class Trie {
    private TrieNode root;

    public Trie() {
        root = new TrieNode();
    }

    // Inserts a word into the trie.
    public void insert(String word) {
        char[] wArray = word.toCharArray();
        TrieNode cur = root;
        for(int i=0; i<wArray.length; i++){
            if(cur.children.containsKey(wArray[i])){
                cur = cur.children.get(wArray[i]);
            }
            else{
                cur.children.put(wArray[i],new TrieNode(wArray[i]));
                cur = cur.children.get(wArray[i]);
            }
            if(i == wArray.length-1){
                cur.hasWord = true;
            }
        }
    }

    // Returns if the word is in the trie.
    public boolean search(String word) {
        TrieNode cur = root;
        char[] wArray = word.toCharArray();
        for(int i=0; i<wArray.length; i++){
            char c = wArray[i];
            if(cur.children.containsKey(c)){
                cur = cur.children.get(c);
                continue;
            }
            return false;
        }
        if(cur.hasWord == true){
            return true;
        }
        return false;
    }

    // Returns if there is any word in the trie
    // that starts with the given prefix.
    public boolean startsWith(String prefix) {
        TrieNode cur = root;
        char[] wArray = prefix.toCharArray();
        for(int i=0; i<wArray.length; i++){
            char c = wArray[i];
            if(cur.children.containsKey(c)){
                cur = cur.children.get(c);
                continue;
            }
            else{
                return false;
            }
        }
        return true;
    }
}