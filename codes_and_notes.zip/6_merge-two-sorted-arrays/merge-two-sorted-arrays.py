# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/merge-two-sorted-arrays
@Language: Python
@Datetime: 16-07-13 02:19
'''

class Solution:
    #@param A and B: sorted integer array A and B.
    #@return: A new sorted integer array
    def mergeSortedArray(self, A, B):
        # write your code here
        ans = []
        i = j = 0
        while i<len(A) and j<len(B):
            if A[i] < B[j]:
                ans.append(A[i])
                i += 1
            else:
                ans.append(B[j])
                j += 1
        if i == len(A):
            while j<len(B):
                ans.append(B[j])
                j += 1
        if j == len(B):
            while i<len(A):
                ans.append(A[i])
                i += 1
        return ans