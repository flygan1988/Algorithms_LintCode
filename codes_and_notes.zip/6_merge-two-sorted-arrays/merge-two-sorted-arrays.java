/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/merge-two-sorted-arrays
@Language: Java
@Datetime: 16-03-30 03:53
*/

class Solution {
    /**
     * @param A and B: sorted integer array A and B.
     * @return: A new sorted integer array
     */
    
    public int[] mergeSortedArray(int[] A, int[] B) {
        // Write your code here
        
        int m = A.length;
        int n = B.length;
        int[] C = new int[m+n];
        int indexA = 0, indexB = 0, i = 0;
        while(indexA < m && indexB < n ){
            if(A[indexA] <= B[indexB]){
                C[i] = A[indexA];
                indexA++;
            }else{
                C[i] = B[indexB];
                indexB++;
            }
            i++;
        }
        if(indexA == m){
            while(indexB < n){
                C[i] = B[indexB++];
                i++;
            }
        }else{
            while(indexA < m){
                C[i] = A[indexA++];
                i++;
            }
        }
        return C;
    }
}