# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/reorder-list
@Language: Python
@Datetime: 16-07-10 07:30
'''

"""
Definition of ListNode
class ListNode(object):

    def __init__(self, val, next=None):
        self.val = val
        self.next = next
"""
class Solution:
    """
    @param head: The first node of the linked list.
    @return: nothing
    """
    def reorderList(self, head):
        # write your code here
        if not head or not head.next:
            return head
        dummy = ListNode(0)
        dummy.next = head
        median = self.getMedian(head)
        newHead = self.reverseList(median.next)
        median.next = None
        while head and newHead:
            p = head.next
            q = newHead.next
            newHead.next = p
            head.next = newHead
            head = p
            newHead = q
        return dummy.next
    
    def reverseList(self, head):
        if not head or not head.next:
            return head
            
        dummy = ListNode(0)
        dummy.next = None
        
        while head:
            p = head.next
            head.next = dummy.next
            dummy.next = head
            head = p
        return dummy.next
        
    def getMedian(self, head):
        slow = head
        fast = head.next
        while fast and fast.next:
            slow = slow.next
            fast = fast.next.next
        return slow