/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/reorder-list
@Language: Java
@Datetime: 16-03-28 20:01
*/

/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 */ 
public class Solution {
    /**
     * @param head: The head of linked list.
     * @return: void
     */
    private ListNode reverse(ListNode head){
        ListNode newHead = null;
        while(head != null){
            ListNode t = head.next;
            head.next = newHead;
            newHead = head;
            head = t;
        }
        return newHead;
    }
    private ListNode findMiddle(ListNode head) {
        ListNode slow = head, fast = head.next;
        while (fast != null && fast.next != null) {
            fast = fast.next.next;
            slow = slow.next;
        }
        return slow;
    }
    private void merge(ListNode head1, ListNode head2){
        ListNode dummy = new ListNode(0);
        int index = 0;
        while(head1 != null && head2 != null){
            if(index % 2 == 0){
                dummy.next = head1;
                head1 = head1.next;
            }
            else{
                dummy.next = head2;
                head2 = head2.next;
            }
            dummy = dummy.next;
            index++;
        }
        if(head1 != null){
            dummy.next = head1;
        }else{
            dummy.next = head2;
        }
    }
    public void reorderList(ListNode head) {  
        // write your code here
        if(head == null || head.next == null){
            return;
        }
        ListNode mid = findMiddle(head);
        ListNode newHead = reverse(mid.next);
        mid.next = null;
        merge(head,newHead);
        
    }
}
