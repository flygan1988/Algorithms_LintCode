```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/reorder-list
@Language: Markdown
@Datetime: 16-07-10 07:30
```

first: break the original list at the middle node into two sublists
second: reverse the second sublist which starts from the next node of the middle node
third: merge the two sublists. 