/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/best-time-to-buy-and-sell-stock
@Language: Java
@Datetime: 16-07-07 02:33
*/

public class Solution {
    /**
     * @param prices: Given an integer array
     * @return: Maximum profit
     */
    public int maxProfit(int[] prices) {
        // write your code here
        if(prices == null || prices.length<2){
            return 0;
        }
        int maxProfit = 0;
        int curMin = prices[0];
        for(int i=1; i<prices.length; i++){
            curMin = Math.min(curMin,prices[i]);
            maxProfit = Math.max(maxProfit,prices[i]-curMin);
        }
        return maxProfit;
    }
}