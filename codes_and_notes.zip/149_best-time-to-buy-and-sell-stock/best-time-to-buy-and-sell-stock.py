# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/best-time-to-buy-and-sell-stock
@Language: Python
@Datetime: 16-07-13 02:44
'''

class Solution:
    """
    @param prices: Given an integer array
    @return: Maximum profit
    """
    def maxProfit(self, prices):
        # write your code here
        if not prices or len(prices)<2:
            return 0
        maxProfit = 0
        curMin = prices[0]
        for i in range(1,len(prices)):
            curMin = min(curMin,prices[i])
            maxProfit = max(maxProfit,prices[i]-curMin)
        return maxProfit