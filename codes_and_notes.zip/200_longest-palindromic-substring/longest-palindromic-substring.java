/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/longest-palindromic-substring
@Language: Java
@Datetime: 16-07-02 16:56
*/

public class Solution {
    /**
     * @param s input string
     * @return the longest palindromic substring
     */
    public String longestPalindrome(String s) {
        // Write your code here
        if(s == null || s.length() == 0){
            return s;
        }
        int n = s.length();
        int maxLength = 1, start = 0;
        boolean[][] f = new boolean[n][n];
        for(int i=0; i<n; i++){
            f[i][i] = true;
        }
        for(int i=0; i<n-1; i++){
            if(s.charAt(i) == s.charAt(i+1)){
                start = i;
                maxLength = 2;
                f[i][i+1] = true;
            }
        }
        for(int k=3; k<=n; k++){
            for(int i=0; i<n-k+1; i++){
                int j = i+k-1;
                if(f[i+1][j-1] && s.charAt(i)==s.charAt(j)){
                    f[i][j] = true;
                    if(k > maxLength){
                        maxLength = k;
                        start = i;
                    }
                }
            }
        }
        return s.substring(start,start+maxLength);
    }
}