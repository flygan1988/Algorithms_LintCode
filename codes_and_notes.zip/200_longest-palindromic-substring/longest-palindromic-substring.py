# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/longest-palindromic-substring
@Language: Python
@Datetime: 16-08-08 01:46
'''

class Solution:
    # @param {string} s input string
    # @return {string} the longest palindromic substring
    def longestPalindrome(self, s):
        # Write your code here
        maxLen = 0
        ans = ""
        for i in range(len(s)):
            for j in range(i,len(s)):
                if self.isPalindrome(s,i,j) and j-i+1 > maxLen:
                    maxLen = j-i+1
                    ans = s[i:j+1]
        return ans
        
    def isPalindrome(self, s, start, end):
        left = start
        right = end
        while left < right:
            if s[left] != s[right]:
                return False
            left += 1
            right -= 1
        return True