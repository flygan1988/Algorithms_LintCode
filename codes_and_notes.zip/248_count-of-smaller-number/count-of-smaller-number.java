/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/count-of-smaller-number
@Language: Java
@Datetime: 16-09-01 02:48
*/

public class Solution {
   /**
     * @param A: An integer array
     * @return: The number of element in the array that 
     *          are smaller that the given integer
     */
    public ArrayList<Integer> countOfSmallerNumber(int[] A, int[] queries) {
        // write your code here
        ArrayList<Integer> result = new ArrayList<>();
        Arrays.sort(A);
        for(int i=0; i<queries.length; i++){
            result.add(binarySearch(A, queries[i]));
        }
        return result;
    }
    public int binarySearch(int[] A, int t){
        if(A.length == 0){
            return 0;
        }
        int left = 0;
        int right = A.length-1;
        while(left < right - 1){
            int mid = left + (right-left)/2;
            if(A[mid] >= t){
                right = mid;
            }
            else{
                left = mid;
            }
        }
        if(A[left] >= t) return left;
        if(A[right] == t) return right;
        if(A[right] < t) return right+1;
        return left+1; 
    }
}
