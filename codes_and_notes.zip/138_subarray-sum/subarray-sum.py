# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/subarray-sum
@Language: Python
@Datetime: 16-07-11 20:49
'''

class Solution:
    """
    @param nums: A list of integers
    @return: A list of integers includes the index of the first number 
             and the index of the last number
    """
    def subarraySum(self, nums):
        # write your code here
        preSum = []
        preSum.append(0)
        for i in range(1,len(nums)+1):
            preSum.append(preSum[i-1]+nums[i-1])
        res = []
        for i in range(len(preSum)):
            for j in range(i+1,len(preSum)):
                if preSum[j]-preSum[i] == 0:
                    res.append(i)
                    res.append(j-1)
                    return res
        return res