/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/subarray-sum
@Language: Java
@Datetime: 16-04-01 04:00
*/

public class Solution {
    /**
     * @param nums: A list of integers
     * @return: A list of integers includes the index of the first number 
     *          and the index of the last number
     */
    public ArrayList<Integer> subarraySum(int[] nums) {
        // write your code here
        ArrayList<Integer> list = new ArrayList<Integer>();
        int[] preSum = new int[nums.length+1];
        //compute the sum of first k(k<=nums.length) numbers in array nums
        for(int i=1; i<preSum.length; i++){
            preSum[i] = preSum[i-1] + nums[i-1];
        }
        for(int i=0; i<preSum.length-1; i++){
            for(int j=i+1; j<preSum.length; j++){
                if(preSum[i] == preSum[j]){
                    list.add(i);
                    list.add(j-1);
                    return list;
                }
            }
        }
        return list;
    }
}