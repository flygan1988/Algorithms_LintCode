/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/recover-rotated-sorted-array
@Language: Java
@Datetime: 16-06-18 05:00
*/

public class Solution {
    /**
     * @param nums: The rotated sorted array
     * @return: void
     */
    public void recoverRotatedSortedArray(ArrayList<Integer> nums) {
        // write your code
        for(int i=0; i<nums.size()-1; i++){
            if(nums.get(i) > nums.get(i+1)){
                reverse(nums,0,i);
                reverse(nums,i+1,nums.size()-1);
                reverse(nums,0,nums.size()-1);
                return;
            }
        }
        
    }
    public void reverse(ArrayList<Integer> nums, int start, int end){
        for(int i=start,j=end; i<j; i++,j--){
            int tmp = nums.get(i);
            nums.set(i,nums.get(j));
            nums.set(j,tmp);
        }
    }
}