/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/the-smallest-difference
@Language: Java
@Datetime: 16-05-21 03:49
*/

public class Solution {
    /**
     * @param A, B: Two integer arrays.
     * @return: Their smallest difference.
     */
    public int smallestDifference(int[] A, int[] B) {
        // write your code here
        int i = 0, j = 0;
        int min = Integer.MAX_VALUE;
        Arrays.sort(A);
        Arrays.sort(B);
        for(i=0; i<A.length; i++){
            while(j < B.length && B[j] <= A[i]){
                j++;
            }
            if(j == B.length){
                min = Math.min(min,Math.abs(A[i]-B[j-1]));
                break;
            }
            if(j == 0){
                min = Math.min(min,Math.abs(A[i]-B[j]));
                continue;
            }
            min = Math.min(min,Math.abs(A[i]-B[j-1]));
            min = Math.min(min,Math.abs(A[i]-B[j]));
        }
        return min;
    }
}
