/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/add-two-numbers
@Language: Java
@Datetime: 16-06-11 17:17
*/

/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) {
 *         val = x;
 *         next = null;      
 *     }
 * }
 */
public class Solution {
    /**
     * @param l1: the first list
     * @param l2: the second list
     * @return: the sum list of l1 and l2 
     */
    public ListNode addLists(ListNode l1, ListNode l2) {
        // write your code here
        if(l1 == null || l2 == null){
            return l1==null?l2:l1;
        }
        ListNode dummy = new ListNode(-1);
        ListNode head = dummy;
        ListNode h1 = l1, h2 = l2;
        int a = 0;
        while(h1 != null && h2 != null){
            int value = h1.val + h2.val +a;
            a = value / 10;
            value %= 10;
            head.next = new ListNode(value);
            head = head.next;
            h1 = h1.next;
            h2 = h2.next;
        }
        while(h1 != null){
            int val = h1.val + a;
            head.next = new ListNode(val%10);
            a = val / 10;
            head = head.next;
            h1 = h1.next;
        }
        while(h2 != null){
            int val = h2.val + a;
            head.next = new ListNode(val%10);
            a = val / 10;
            head = head.next;
            h2 = h2.next;
        }
        if(a == 1){
            head.next = new ListNode(1);
        }
        return dummy.next;
    }
}