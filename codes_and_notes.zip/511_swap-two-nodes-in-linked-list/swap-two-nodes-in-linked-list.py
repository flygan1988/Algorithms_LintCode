# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/swap-two-nodes-in-linked-list
@Language: Python
@Datetime: 16-07-11 13:05
'''

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, x):
#         self.val = x
#         self.next = None

class Solution:
    # @param {ListNode} head, a ListNode
    # @oaram {int} v1 an integer
    # @param {int} v2 an integer
    # @return {ListNode} a new head of singly-linked list
    def swapNodes(self, head, v1, v2):
        # Write your code here
        dummy = ListNode(0)
        dummy.next = head
        pre1 = dummy
        pre2 = dummy
        while pre1.next and pre1.next.val != v1:
            pre1 = pre1.next
        while pre2.next and pre2.next.val != v2:
            pre2 = pre2.next
        if pre1.next is None or pre2.next is None or pre1 == pre2:
            return head
        elif pre1.next == pre2:
            pre1.next = pre1.next.next
            pre2.next = pre1.next.next
            pre1.next.next = pre2
        elif pre2.next == pre1:
            pre2.next = pre2.next.next
            pre1.next = pre2.next.next
            pre2.next.next = pre1
        else:
            p1 = pre1.next
            p2 = pre2.next
            pre1.next = pre1.next.next
            pre2.next = pre2.next.next
            p2.next = pre1.next
            pre1.next = p2
            p1.next = pre2.next
            pre2.next = p1
        return dummy.next