/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/swap-two-nodes-in-linked-list
@Language: Java
@Datetime: 16-06-23 21:08
*/

/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) { val = x; }
 * }
 */
public class Solution {
    /**
     * @param head a ListNode
     * @oaram v1 an integer
     * @param v2 an integer
     * @return a new head of singly-linked list
     */
    public ListNode swapNodes(ListNode head, int v1, int v2) {
        // Write your code here
        if(head == null){
            return null;
        }
        ListNode dummy = new ListNode(0);
        dummy.next = head;
        head = dummy;
        ListNode p = null;
        ListNode q = null;
        while(head.next != null){
            if(head.next.val == v1){
                p = head;
            }
            if(head.next.val == v2){
                q = head;
            }
            head = head.next;
        }
        if(p == null || q == null || v1 == v2){
            return dummy.next;
        }
        ListNode pv1 = p.next;
        ListNode qv2 = q.next;
        
        p.next = qv2;
        q.next = pv1;
        
        ListNode tmp = pv1.next;
        pv1.next = qv2.next;
        qv2.next = tmp;
        return dummy.next;
    }
}