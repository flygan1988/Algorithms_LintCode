/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/stack-sorting
@Language: Java
@Datetime: 16-05-22 23:03
*/

public class Solution {
    /**
     * @param stack an integer stack
     * @return void
     */
    public void stackSorting(Stack<Integer> stack) {
        // Write your code here
        if(stack == null || stack.size() == 0){
            return;
        }
        Stack<Integer> s = new Stack<Integer>();
        s.add(stack.pop());
        while(!stack.isEmpty()){
            int tmp = stack.pop();
            if(tmp <= s.peek()){
                s.add(tmp);
            }
            else{
                while(!s.isEmpty() && tmp > s.peek()){
                    stack.add(s.pop());
                }
                s.add(tmp);
            }
        }
        while(!s.isEmpty()){
            stack.add(s.pop());
        }
    }
}