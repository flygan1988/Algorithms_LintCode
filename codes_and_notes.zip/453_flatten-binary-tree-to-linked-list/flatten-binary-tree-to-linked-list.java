/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/flatten-binary-tree-to-linked-list
@Language: Java
@Datetime: 16-06-14 02:46
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @param root: a TreeNode, the root of the binary tree
     * @return: nothing
     */
    //Solution1: time O(n), space O(n)
    /**
    public void flatten(TreeNode root) {
        // write your code here
        ArrayList<TreeNode> list = new ArrayList<TreeNode>();
        preorder(list,root);
        for(int i=0; i<list.size()-1; i++){
            TreeNode node = list.get(i);
            node.left = null;
            node.right = list.get(i+1);
        }
    }
    private void preorder(ArrayList<TreeNode> list, TreeNode root){
        if(root == null) return;
        list.add(root);
        preorder(list,root.left);
        preorder(list,root.right);
    }**/
    public void flatten(TreeNode root) {
        helper(root);
    }
    private TreeNode lastNode(TreeNode root){
        if(root == null) return null;
        if(root.right == null){
            return root;
        }
        return lastNode(root.right);
    }
    private void helper(TreeNode root){
        if(root == null) return;
        helper(root.left);
        TreeNode right = root.right;
        if(root.left != null) {
            root.right = root.left;
        }
        TreeNode last = lastNode(root.left);
        if(last != null){
            last.right = right;
        }
        helper(right);
        root.left = null;
    }
}