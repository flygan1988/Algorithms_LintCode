/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/longest-increasing-continuous-subsequence-ii
@Language: Java
@Datetime: 16-07-06 20:01
*/

public class Solution {
    /**
     * @param A an integer matrix
     * @return  an integer
     */
    int[] dx = {1,-1,0,0};
    int[] dy = {0,0,1,-1};
    int m;
    int n;
    public int longestIncreasingContinuousSubsequenceII(int[][] A) {
        // Write your code here
        if(A == null || A.length == 0){
            return 0;
        }
        m = A.length;
        n = A[0].length;
        int[][] visit = new int[m][n];
        int[][] dp = new int[m][n];
        int ans = 0;
        for(int i=0; i<m; i++){
            for(int j=0; j<n; j++){
                ans = Math.max(ans,search(i,j,A,dp,visit));
            }
        }
        return ans;
    }
    public int search(int x, int y, int[][] A, int[][] dp, int[][] visit){
        if(visit[x][y] != 0){
            return dp[x][y];
        }
        int ans = 1;
        for(int i=0; i<4; i++){
            int xx = x + dx[i];
            int yy = y + dy[i];
            if(xx>=0 && xx<m && yy>=0 && yy<n){
                if(A[x][y] < A[xx][yy]){
                    ans = Math.max(ans,search(xx,yy,A,dp,visit)+1);
                }
            }
        }
        visit[x][y] = 1;
        dp[x][y] = ans;
        return ans;
    }
}