/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/maximum-gap
@Language: Java
@Datetime: 16-07-07 22:52
*/

class Solution {
    /**
     * @param nums: an array of integers
     * @return: the maximum difference
     */
    /*solution 1: count sort and radix sort
    public int maximumGap(int[] nums) {
        // write your code here
        if(nums == null || nums.length < 2){
            return 0;
        }
        nums = radixSort(nums);
        int diff = 0;
        for(int i=1; i<nums.length; i++){
            diff = Math.max(diff,nums[i]-nums[i-1]);
        }
        return diff;
    }
    public int[] countSort(int[] nums, int nd){
        int[] count = new int[10];
        for(int i=0; i<nums.length; i++){
            count[(nums[i]/nd) % 10]++;
        }
        for(int i=1; i<10; i++){
            count[i] += count[i-1];
        }
        int[] output = new int[nums.length];
        for(int j=nums.length-1; j>=0; j--){
            output[count[(nums[j]/nd) % 10]-1] = nums[j];
            count[(nums[j]/nd) % 10]--;
        }
        return output;
    }
    public int[] radixSort(int[] nums){
        int nd = 1;
        int max = maxNum(nums);
        while(max / nd > 0){
            nums = countSort(nums,nd);
            nd = nd * 10;
        }
        return nums;
    }
    **/
    public int maxNum(int[] nums){
        int max = Integer.MIN_VALUE;
        for(int i=0; i<nums.length; i++){
            max = Math.max(max,nums[i]);
        }
        return max;
    }
    public int minNum(int[] nums){
        int min = Integer.MAX_VALUE;
        for(int i=0; i<nums.length; i++){
            min = Math.min(min,nums[i]);
        }
        return min;
    }
    public int maxNumInList(ArrayList<Integer> nums){
        int max = Integer.MIN_VALUE;
        for(int i=0; i<nums.size(); i++){
            max = Math.max(max,nums.get(i));
        }
        return max;
    }
    public int minNumInList(ArrayList<Integer> nums){
        int min = Integer.MAX_VALUE;
        for(int i=0; i<nums.size(); i++){
            min = Math.min(min,nums.get(i));
        }
        return min;
    }
    class Bucket{
        ArrayList<Integer> list;
        Bucket(){
            this.list = new ArrayList<Integer>();
        }
    }
    //solution 2: bucket sort
    public int maximumGap(int[] nums) {
        if(nums == null || nums.length < 2){
            return 0;
        }
        int max = maxNum(nums);
        int min = minNum(nums);
        int n = nums.length;
        Bucket[] buckets = new Bucket[n-1];
        for(int i=0; i<n-1; i++){
            buckets[i] = new Bucket();
        }
        double size = (max - min) / (double)(n-1);
        for(int i=0; i<n; i++){
            if(nums[i] == min || nums[i] == max){
                continue;
            }
            int k = (int)Math.floor((nums[i] - min) / size);
            buckets[k].list.add(nums[i]);
        }
        ArrayList<Bucket> now = new ArrayList<Bucket>();
        for(int i=0; i<n-1; i++){
            if(buckets[i].list.size() != 0){
                now.add(buckets[i]);
            }
        }
        if(now.size() == 0){
            return max-min;
        }
        int maxDistance = Math.max(minNumInList(now.get(0).list)-min,max-maxNumInList(now.get(now.size()-1).list));
        for(int i=1; i<now.size(); i++){
            maxDistance = Math.max(maxDistance,minNumInList(now.get(i).list)-maxNumInList(now.get(i-1).list));
        }
        return maxDistance;
    }
}