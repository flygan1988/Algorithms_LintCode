# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/maximum-gap
@Language: Python
@Datetime: 16-08-11 03:40
'''

from heapq import heappush, heappop
class Solution:
     # @param nums: a list of integers
     # @return: the maximum difference
    def maximumGap(self, nums):
        # write your code here
        if len(nums) < 2:
            return 0
        heap = []
        for i in nums:
            heappush(heap,i)
        maxDiff = -sys.maxint
        prev = heappop(heap)
        while len(heap) != 0:
            now = heappop(heap)
            maxDiff = max(maxDiff,now-prev)
            prev = now
        return maxDiff