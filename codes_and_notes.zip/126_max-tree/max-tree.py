# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/max-tree
@Language: Python
@Datetime: 16-08-12 21:42
'''

"""
Definition of TreeNode:
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left, self.right = None, None
"""
class Solution:
    # @param A: Given an integer array with no duplicates.
    # @return: The root of max tree.
    def maxTree(self, A):
        # write your code here
        if not A or len(A)==0:
            return None
        stack = []
        stack.append(TreeNode(A[0]))
        for i in range(1,len(A)):
            if A[i] < stack[len(stack)-1].val:
                stack.append(TreeNode(A[i]))
            else:
                node1 = stack.pop()
                while len(stack) != 0 and stack[len(stack)-1].val < A[i]:
                    node2 = stack.pop()
                    node2.right = node1
                    node1 = node2
                tmp = TreeNode(A[i])
                tmp.left = node1
                stack.append(tmp)
        root = stack.pop()
        while len(stack) != 0:
            node = stack.pop()
            node.right = root
            root = node
        return root
                    