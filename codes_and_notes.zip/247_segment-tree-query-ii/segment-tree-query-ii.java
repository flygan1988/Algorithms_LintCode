/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/segment-tree-query-ii
@Language: Java
@Datetime: 16-06-30 04:09
*/

/**
 * Definition of SegmentTreeNode:
 * public class SegmentTreeNode {
 *     public int start, end, count;
 *     public SegmentTreeNode left, right;
 *     public SegmentTreeNode(int start, int end, int count) {
 *         this.start = start;
 *         this.end = end;
 *         this.count = count;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution {
    /**
     *@param root, start, end: The root of segment tree and 
     *                         an segment / interval
     *@return: The count number in the interval [start, end]
     */
    public int query(SegmentTreeNode root, int start, int end) {
        // write your code here
        if(start>end || root==null){
            return 0;
        }
        if(start<=root.start && end>=root.end){
            return root.count;
        }
        int leftCount=0, rightCount=0;
        int mid = (root.start+root.end)/2;
        if(start <= mid){
            if(mid <= end){
                leftCount = query(root.left,start,mid);
            }else{
                leftCount = query(root.left,start,end);
            }
        }
        if(mid < end){
            if(start <= mid){
                rightCount = query(root.right,mid+1,end);
            }
            else{
                rightCount = query(root.right,start,end);
            }
        }
        return leftCount+rightCount;
    }
}