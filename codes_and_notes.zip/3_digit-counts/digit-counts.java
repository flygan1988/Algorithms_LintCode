/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/digit-counts
@Language: Java
@Datetime: 16-07-05 22:46
*/

class Solution {
    /*
     * param k : As description.
     * param n : As description.
     * return: An integer denote the count of digit k in 1..n
     */
    public int digitCounts(int k, int n) {
        // write your code here
        int count=0;
        for(int i=0; i<=n; i++){
            count += countDigitInNum(i,k);
        }
        return count;
    }
    public int countDigitInNum(int num, int k){
        int count = 0;
        String str = Integer.toString(num);
        for(int i=0; i<str.length(); i++){
            if(str.charAt(i) == k+'0'){
                count++;
            }
        }
        return count;
    }
};
