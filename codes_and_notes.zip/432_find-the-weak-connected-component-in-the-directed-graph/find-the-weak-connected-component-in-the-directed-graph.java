/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/find-the-weak-connected-component-in-the-directed-graph
@Language: Java
@Datetime: 16-05-10 20:00
*/

/**
 * Definition for Directed graph.
 * class DirectedGraphNode {
 *     int label;
 *     ArrayList<DirectedGraphNode> neighbors;
 *     DirectedGraphNode(int x) { label = x; neighbors = new ArrayList<DirectedGraphNode>(); }
 * };
 */
public class Solution {
    /**
     * @param nodes a array of Directed graph node
     * @return a connected set of a directed graph
     */
    class UnionFind {
        HashMap<Integer,Integer> father = new HashMap<Integer,Integer>();
        UnionFind(ArrayList<DirectedGraphNode> nodes){
            for(DirectedGraphNode node:nodes){
                father.put(node.label,node.label);
            }
        }
        public int find(int x){
            int parent = father.get(x);
            while(parent != father.get(parent)){
                parent = father.get(parent);
            }
            return parent;
        }
        public void union(int x, int y){
            int fa_x = find(x);
            int fa_y = find(y);
            if(fa_x != fa_y){
                father.put(fa_x,fa_y);
            }
        }
    }
    public List<List<Integer>> connectedSet2(ArrayList<DirectedGraphNode> nodes) {
        // Write your code here
        UnionFind uf = new UnionFind(nodes);
        List<List<Integer>> result = new ArrayList<>();
        for(DirectedGraphNode node:nodes){
            for(DirectedGraphNode neighbor:node.neighbors){
                if(uf.find(node.label) != uf.find(neighbor.label)){
                    uf.union(node.label,neighbor.label);
                }
            }
        }
        return print(uf);
        
    }
    private List<List<Integer>> print(UnionFind uf){
        HashMap<Integer,ArrayList<Integer>> hm = new HashMap<Integer,ArrayList<Integer>>();
        List<List<Integer>> result = new ArrayList<>();
        for(int i:uf.father.keySet()){
            int father = uf.find(i);
            if(!hm.containsKey(father)){
                hm.put(father,new ArrayList<Integer>());
            }
            hm.get(father).add(i);
        }
        for(int i:hm.keySet()){
            ArrayList<Integer> item = hm.get(i);
            Collections.sort(item);
            result.add(item);
        }
        return result;
    }
}