# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/find-the-weak-connected-component-in-the-directed-graph
@Language: Python
@Datetime: 16-07-15 21:33
'''

# Definition for a directed graph node
# class DirectedGraphNode:
#     def __init__(self, x):
#         self.label = x
#         self.neighbors = []
class UnionFind:
    
    def __init__(self):
        self.fa = {}
        
    def find(self, x):
        parent = self.fa[x]
        while parent != self.fa[parent]:
            parent = self.fa[parent]
        return parent
    
    def union(self, x, y):
        fa_x = self.find(x)
        fa_y = self.find(y)
        if fa_x != fa_y:
            self.fa[fa_x] = fa_y
            
class Solution:
    # @param {DirectedGraphNode[]} nodes a array of directed graph node
    # @return {int[][]} a connected set of a directed graph
    def connectedSet2(self, nodes):
        # Write your code here
        ans = []
        uf = UnionFind()
        for node in nodes:
            uf.fa[node.label] = node.label
        for node in nodes:
            for neighbor in node.neighbors:
                if uf.find(node.label) != uf.find(neighbor.label):
                    uf.union(node.label, neighbor.label)
        hashmap = {}
        for label in uf.fa:
            father = uf.find(label)
            if father not in hashmap:
                hashmap[father]= []
            hashmap[father].append(label)
        
        for fa in hashmap:
            tmp = hashmap[fa]
            tmp.sort()
            ans.append(tmp)
        return ans 