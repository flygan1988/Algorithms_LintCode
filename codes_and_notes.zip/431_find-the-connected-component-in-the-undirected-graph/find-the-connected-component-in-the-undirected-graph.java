/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/find-the-connected-component-in-the-undirected-graph
@Language: Java
@Datetime: 16-05-10 17:41
*/

/**
 * Definition for Undirected graph.
 * class UndirectedGraphNode {
 *     int label;
 *     ArrayList<UndirectedGraphNode> neighbors;
 *     UndirectedGraphNode(int x) { label = x; neighbors = new ArrayList<UndirectedGraphNode>(); }
 * };
 */
public class Solution {
    /**
     * @param nodes a array of Undirected graph node
     * @return a connected set of a Undirected graph
     */
    public List<List<Integer>> connectedSet(ArrayList<UndirectedGraphNode> nodes) {
        // Write your code here
        List<List<Integer>> result = new ArrayList<>();
        HashMap<UndirectedGraphNode,Boolean> visited = new HashMap<UndirectedGraphNode,Boolean>();
        for(UndirectedGraphNode node:nodes){
            visited.put(node,false);
        }
        for(UndirectedGraphNode now:nodes){
            if(visited.get(now) == false){
                bfs(now, result, visited);
            }
        }
        return result;
    }
    
    public void bfs(UndirectedGraphNode node, List<List<Integer>> result, HashMap<UndirectedGraphNode,Boolean> visited){
        Queue<UndirectedGraphNode> queue = new LinkedList<UndirectedGraphNode>();
        List<Integer> item = new ArrayList<>();
        queue.offer(node);
        visited.put(node,true);
        while(!queue.isEmpty()){
            UndirectedGraphNode now = queue.poll();
            item.add(now.label);
            for(UndirectedGraphNode neighbor:now.neighbors){
                if(visited.get(neighbor) == false){
                    queue.offer(neighbor);
                    visited.put(neighbor,true);
                }
            }
        }
        Collections.sort(item);
        result.add(item);
    }
}