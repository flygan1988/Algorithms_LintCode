# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/find-the-connected-component-in-the-undirected-graph
@Language: Python
@Datetime: 16-07-14 23:00
'''

# Definition for a undirected graph node
# class UndirectedGraphNode:
#     def __init__(self, x):
#         self.label = x
#         self.neighbors = []
class Solution:
    # @param {UndirectedGraphNode[]} nodes a array of undirected graph node
    # @return {int[][]} a connected set of a undirected graph
    def connectedSet(self, nodes):
        # Write your code here
        ans = []
        visit = {}
        for node in nodes:
            visit[node] = False
        for i in range(len(nodes)):
            now = nodes[i]
            if not visit[now]:
                ans.append(self.search(visit, now))
        return ans
            
    def search(self, visit, s):
        queue = []
        tmp = []
        queue.insert(0, s)
        visit[s] = True
        while len(queue) != 0:
            node = queue.pop()
            tmp.append(node.label)
            for n in node.neighbors:
                if not visit[n]:
                    queue.insert(0, n)
                    visit[n] = True
        tmp.sort()
        return tmp
            