/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/n-queens-ii
@Language: Java
@Datetime: 16-06-08 00:04
*/

class Solution {
    /**
     * Calculate the total number of distinct N-Queen solutions.
     * @param n: The number of queens.
     * @return: The total number of distinct solutions.
     */
    public static int count;
    public int totalNQueens(int n) {
        //write your code here
        ArrayList<Integer> list = new ArrayList<Integer>();
        count = 0;
        helper(list,n);
        return count;
    }
    public void helper(ArrayList<Integer> list, int n){
        if(list.size() == n){
            count++;
            return;
        }
        for(int i=1; i<=n; i++){
            if(!isValid(list,i)){
                continue;
            }
            list.add(i);
            helper(list,n);
            list.remove(list.size()-1);
        }
    }
    private boolean isValid(ArrayList<Integer> list, int n){
        for(int i=0; i<list.size(); i++){
            if(list.get(i) == n){
                return false;
            }
            if(list.get(i)-i == n-list.size()){
                return false;
            }
            if(list.get(i)+i == n+list.size()){
                return false;
            }
        }
        return true;
    }
};

