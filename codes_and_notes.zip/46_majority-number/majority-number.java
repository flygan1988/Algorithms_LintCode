/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/majority-number
@Language: Java
@Datetime: 16-06-11 14:31
*/

public class Solution {
    /**
     * @param nums: a list of integers
     * @return: find a  majority number
     */
    public int majorityNumber(ArrayList<Integer> nums) {
        // write your code
        HashMap<Integer,Integer> map = new HashMap<>();
        for(int i=0; i<nums.size(); i++){
            if(!map.containsKey(nums.get(i))){
                map.put(nums.get(i),1);
            }else{
                map.put(nums.get(i),map.get(nums.get(i))+1);
            }
        }
        for(int key:map.keySet()){
            if(map.get(key) > nums.size()/2){
                return key;
            }
        }
        return -1;
    }
}