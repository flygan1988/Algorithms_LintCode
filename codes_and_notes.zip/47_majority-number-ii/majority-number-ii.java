/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/majority-number-ii
@Language: Java
@Datetime: 16-07-02 05:18
*/

public class Solution {
    /**
     * @param nums: A list of integers
     * @return: The majority number that occurs more than 1/3
     */
    public int majorityNumber(ArrayList<Integer> nums) {
        // write your code
        int candidate1 = 0, candidate2 = 0;
        int count1 = 0, count2 = 0;
        for(int i=0; i<nums.size(); i++){
            if(candidate1 == nums.get(i)){
                count1++;
            }else if(candidate2 == nums.get(i)){
                count2++;
            }else if(count1 == 0){
                candidate1 = nums.get(i);
                count1 = 1;
            }else if(count2 == 0){
                candidate2 = nums.get(i);
                count2 = 1;
            }else{
                count1--;
                count2--;
            }
        }
        count1 = 0;
        count2 = 0;
        for(int i=0; i<nums.size(); i++){
            if(candidate1 == nums.get(i)){
                count1++;
            }else if(candidate2 == nums.get(i)){
                count2++;   
            }
        }
        return count1>count2?candidate1:candidate2;
    }
}
