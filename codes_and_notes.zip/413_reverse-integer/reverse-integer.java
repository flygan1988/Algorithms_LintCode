/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/reverse-integer
@Language: Java
@Datetime: 16-06-18 06:53
*/

public class Solution {
    /**
     * @param n the integer to be reversed
     * @return the reversed integer
     */
    public int reverseInteger(int n) {
        // Write your code here
        long x = 0;
        if(n >= 0){
            String str = String.valueOf(n);
            char[] chars = str.toCharArray();
            x = reverseValue(chars);
        }else{
            String str = String.valueOf(-n);
            char[] chars = str.toCharArray();
            x = -reverseValue(chars);
        }
        if(x > Integer.MAX_VALUE || x < Integer.MIN_VALUE){
            return 0;
        }
        return (int)x;
    }
    public long reverseValue(char[] chars){
        long res = 0;
        for(int i=0, j=chars.length-1; i<j; i++,j--){
            Character c = chars[i];
            chars[i] = chars[j];
            chars[j] = c;
        }
        for(int i=0; i<chars.length; i++){
            res = 10*res + (long)(chars[i]-'0');
        }
        return res;
    }
}