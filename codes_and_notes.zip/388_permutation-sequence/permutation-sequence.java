/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/permutation-sequence
@Language: Java
@Datetime: 16-06-04 20:08
*/

class Solution {
    /**
      * @param n: n
      * @param k: the kth permutation
      * @return: return the k-th permutation
      */
    public String getPermutation(int n, int k) {
        ArrayList<String> rst = new ArrayList<String>();
        String s = "";
        permutation(rst,s,n,k);
        return rst.get(k-1);
    }
    public void permutation(ArrayList<String> rst, String s, int n, int k){
        if(s.length() == n){
            if(rst.size() == k){
                return;
            }
            rst.add(new String(s));
            return;
        }
        for(int i=1; i<=n; i++){
            if(s.contains(String.valueOf(i))){
                continue;
            }
            s += String.valueOf(i);
            permutation(rst,s,n,k);
            s = s.substring(0,s.length()-1);
        }
    }
}
