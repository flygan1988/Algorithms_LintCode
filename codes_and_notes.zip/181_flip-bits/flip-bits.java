/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/flip-bits
@Language: Java
@Datetime: 16-06-14 02:56
*/

class Solution {
    /**
     *@param a, b: Two integer
     *return: An integer
     */
    public static int bitSwapRequired(int a, int b) {
        // write your code here
        String sa = Integer.toBinaryString(a);
        String sb = Integer.toBinaryString(b);
        int n = sa.length() - sb.length();
        if(n > 0){
            for(int i=0; i<n; i++){
                sb = '0' + sb;
            }
        }
        if(n < 0){
            for(int i=0; i<-n; i++){
                sa = '0' + sa;
            }
        }
        int count = 0;
        for(int i=0; i<sa.length(); i++){
            if(sa.charAt(i) != sb.charAt(i)){
                count++;
            }
        }
        return count;
    }
};
