/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/length-of-last-word
@Language: Java
@Datetime: 16-06-14 18:46
*/

public class Solution {
    /**
     * @param s A string
     * @return the length of last word
     */
    public int lengthOfLastWord(String s) {
        // Write your code here
        if(s == null || s.length() == 0){
            return 0;
        }
        String[] res = s.split(" ");
        int len = res[res.length-1].length();
        return len;
    }
}