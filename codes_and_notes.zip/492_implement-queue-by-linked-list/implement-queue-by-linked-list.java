/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/implement-queue-by-linked-list
@Language: Java
@Datetime: 16-06-14 04:34
*/

class ListNode{
    int val;
    ListNode next;
    public ListNode(int val){
        this.val = val;
        this.next = null;
    }
} 
public class Queue {
    ListNode dummy;
    ListNode current;
    public Queue() {
        // do initialize if necessary
        dummy = new ListNode(-1);
        current = dummy;
    }

    public void enqueue(int item) {
        // Write your code here
        current.next = new ListNode(item);
        current = current.next;
    }

    public int dequeue() {
        // Write your code here
        ListNode node = dummy.next;
        dummy.next = node.next;
        if(dummy.next == null){
            current = dummy;
        }
        return node.val;
    }
}