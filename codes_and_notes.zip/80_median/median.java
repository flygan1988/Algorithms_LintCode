/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/median
@Language: Java
@Datetime: 16-06-17 06:11
*/

public class Solution {
    /**
     * @param nums: A list of integers.
     * @return: An integer denotes the middle number of the array.
     */
    public int median(int[] nums) {
        // write your code here
        if(nums.length % 2 == 0){
            return findKthSmall(nums,nums.length/2);
        }
        return findKthSmall(nums,nums.length/2+1);
    }
    public int findKthSmall(int[] nums, int k){
        PriorityQueue<Integer> heap = new PriorityQueue<Integer>(k,new Comparator<Integer>(){
            public int compare(Integer i1, Integer i2){
                return i2 - i1;
            }
        });
        for(int i=0; i<k; i++){
            heap.offer(nums[i]);
        }
        for(int j=k; j<nums.length; j++){
            heap.offer(nums[j]);
            if(heap.size() > k){
                heap.poll();
            }
        }
        return heap.poll();
    }
}
