/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/string-permutation-ii
@Language: Java
@Datetime: 16-06-07 21:40
*/

public class Solution {
    /**
     * @param str a string
     * @return all permutations
     */
    public List<String> stringPermutation2(String str) {
        // Write your code here
        String s = "";
        int[] visited = new int[str.length()];
        List<String> res = new ArrayList<>();
        char[] strArray = str.toCharArray();
        Arrays.sort(strArray);
        helper(res,strArray,s,visited);
        return res;
    }
    public void helper(List<String> res, char[] str, String s, int[] visited){
        if(s.length() == str.length){
            res.add(new String(s));
            return;
        }
        for(int i=0; i<str.length; i++){
            if(visited[i]==1 || (i!=0 && str[i-1]==str[i] && visited[i-1]!=1)){
                continue;
            }
            visited[i] = 1;
            s += str[i];
            helper(res,str,s,visited);
            visited[i] = 0;
            s = s.substring(0,s.length()-1);
        }
    }
}