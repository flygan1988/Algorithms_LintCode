/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/product-of-array-exclude-itself
@Language: Java
@Datetime: 16-06-18 04:08
*/

public class Solution {
    /**
     * @param A: Given an integers array A
     * @return: A Long array B and B[i]= A[0] * ... * A[i-1] * A[i+1] * ... * A[n-1]
     */
    public ArrayList<Long> productExcludeItself(ArrayList<Integer> A) {
        // write your code
        ArrayList<Long> result = new ArrayList<Long>();
        if(A == null || A.size() == 0){
            return result;
        }
        for(int i=0; i<A.size(); i++){
            long res = leftResult(A,i) * rightResult(A,i);
            result.add(res);
        }
        return result;
    }
    public long leftResult(ArrayList<Integer> A, int k){
        long res = 1L;
        for(int i=0; i<k; i++){
            res *= A.get(i);
        }
        return res;
    }
    public long rightResult(ArrayList<Integer> A, int k){
        long res = 1L;
        for(int i=k+1; i<A.size(); i++){
            res *= A.get(i);
        }
        return res;
    }
}
