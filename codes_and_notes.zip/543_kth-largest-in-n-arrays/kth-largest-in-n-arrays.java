/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/kth-largest-in-n-arrays
@Language: Java
@Datetime: 16-06-15 05:11
*/

class Point{
    int val;
    int x;
    int y;
    public Point(int val, int x, int y){
        this.val = val;
        this.x = x;
        this.y = y;
    }
}
public class Solution {
    /**
     * @param arrays a list of array
     * @param k an integer
     * @return an integer, K-th largest element in N arrays
     */
    public int KthInArrays(int[][] arrays, int k) {
        // Write your code here
        //sort array in descending order
        for(int i=0; i<arrays.length; i++){
            quickSort(arrays[i],0,arrays[i].length-1);
        }
        PriorityQueue<Point> heap = new PriorityQueue<Point>(1,new Comparator<Point>(){
            public int compare(Point p1, Point p2){
                return p2.val - p1.val;
            }
        });
        for(int i=0; i<arrays.length; i++){
            if(arrays[i].length == 0){
                continue;
            }
            heap.offer(new Point(arrays[i][0],i,0));
        }
        int j = 0;
        while(j < k-1){
            Point p = heap.poll();
            if(p.y+1 < arrays[p.x].length){
                heap.offer(new Point(arrays[p.x][p.y+1],p.x,p.y+1));
            }
            j++;
        }
        return heap.poll().val;
    }
    public void quickSort(int[] a, int start, int end){
        if(start > end) return;
        int index = helper(a,start,end);
        quickSort(a,start,index-1);
        quickSort(a,index+1,end);
    }
    private int helper(int[] a, int start, int end){
        int left = start, right = end;
        int pivot = a[start];
        while(left < right){
            while(a[right]<=pivot && left < right){
                right--;
            }
            a[left] = a[right];
            while(a[left] >= pivot && left < right){
                left++;
            }
            a[right] = a[left];
        }
        a[left] = pivot;
        return left;
    }
}