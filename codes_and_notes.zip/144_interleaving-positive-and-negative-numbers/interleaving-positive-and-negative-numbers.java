/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/interleaving-positive-and-negative-numbers
@Language: Java
@Datetime: 16-08-12 16:14
*/

class Solution {
    /**
     * @param A: An integer array.
     * @return: void
     */
    public void rerange(int[] A) {
        // write your code here
        int len = A.length;
        int count = 0;
        for(int i=0; i<len; i++){
            if(A[i] < 0){
                count++;
            }
        }
        if(count >= len-count){
            operator1(A);
        }else{
            operator2(A);
        }
   }
   public void operator1(int[] A){
       for(int i=0; i<A.length-1; i++){
            if(i%2 == 0 && A[i] > 0){
                for(int j=i+1; j<A.length; j++){
                    if(A[j] < 0){
                        int tmp = A[i];
                        A[i] = A[j];
                        A[j] = tmp;
                        break;
                    }
                }
            }
            if(i%2 == 1 && A[i] < 0){
                for(int j=i+1; j<A.length; j++){
                    if(A[j] > 0){
                        int tmp = A[i];
                        A[i] = A[j];
                        A[j] = tmp;
                        break;
                    }
                }
            }
        }
   }
   public void operator2(int[] A){
       for(int i=0; i<A.length-1; i++){
            if(i%2 == 0 && A[i] < 0){
                for(int j=i+1; j<A.length; j++){
                    if(A[j] > 0){
                        int tmp = A[i];
                        A[i] = A[j];
                        A[j] = tmp;
                        break;
                    }
                }
            }
            if(i%2 == 1 && A[i] > 0){
                for(int j=i+1; j<A.length; j++){
                    if(A[j] < 0){
                        int tmp = A[i];
                        A[i] = A[j];
                        A[j] = tmp;
                        break;
                    }
                }
            }
        }
   }
}