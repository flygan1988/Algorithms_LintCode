/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/max-points-on-a-line
@Language: Java
@Datetime: 16-06-21 04:38
*/

/**
 * Definition for a point.
 * class Point {
 *     int x;
 *     int y;
 *     Point() { x = 0; y = 0; }
 *     Point(int a, int b) { x = a; y = b; }
 * }
 */
class Line{
    int a;
    int b;
    Line(int a, int b){
        this.a = a;
        this.b = b;
    }
}
public class Solution {
    /**
     * @param points an array of point
     * @return an integer
     */
    public int maxPoints(Point[] points) {
        // Write your code here
        if(points == null || points.length == 0){
            return 0;
        }
        int max = 1;
        HashMap<Double,Integer> map = new HashMap<>();
        for(int i=0; i<points.length; i++){
            map.clear();
            int dup = 0;
            map.put((double)Integer.MIN_VALUE, 1);
            for(int j=i+1; j<points.length; j++){
                if(points[j].x == points[i].x && points[j].y == points[i].y){
                    dup++;
                    continue;
                }
                double key = points[j].x - points[i].x == 0?Integer.MAX_VALUE:(double)(points[j].y-points[i].y)/(double)(points[j].x-points[i].x)+0.0; 
                if(map.containsKey(key)){
                    map.put(key,map.get(key)+1);
                }else{
                    map.put(key,2);
                }
            }
            for(int value:map.values()){
                if(value+dup > max){
                    max = value+dup;
                }
            }
        }
        return max;
    }
}