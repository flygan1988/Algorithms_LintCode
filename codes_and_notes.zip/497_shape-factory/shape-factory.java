/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/shape-factory
@Language: Java
@Datetime: 16-06-18 20:13
*/

/**
 * Your object will be instantiated and called as such:
 * ShapeFactory sf = new ShapeFactory();
 * Shape shape = sf.getShape(shapeType);
 * shape.draw();
 */
interface Shape {
    void draw();
}

class Rectangle implements Shape {
    // Write your code here
    //public Rectangle(){};
    public void draw(){
        System.out.println(" ----");
        System.out.println("|    |");
        System.out.println(" ----");
    }
}

class Square implements Shape {
    // Write your code here
    //public Square(){};
    public void draw(){
        System.out.println(" ---- ");
        System.out.println("|    |");
        System.out.println("|    |");
        System.out.println(" ---- ");
    }
}

class Triangle implements Shape {
    // Write your code here
    //public Triangle(){};
    public void draw(){
        System.out.println("  /\\ ");
        System.out.println(" /  \\");
        System.out.println("/____\\");
        //System.out.println("_____");
    }
}

public class ShapeFactory {
    /**
     * @param shapeType a string
     * @return Get object of type Shape
     */
    //public ShapeFactory(){};
    public Shape getShape(String shapeType) {
        // Write your code here
        if(shapeType.equalsIgnoreCase("Square")){
            return new Square();
        }else if(shapeType.equalsIgnoreCase("Rectangle")){
            return new Rectangle();
        }else if(shapeType.equalsIgnoreCase("Triangle")){
            return new Triangle();
        }else{
            return null;
        }
    }
}