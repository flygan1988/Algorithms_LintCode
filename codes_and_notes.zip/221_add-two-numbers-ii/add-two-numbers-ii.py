# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/add-two-numbers-ii
@Language: Python
@Datetime: 16-07-10 15:48
'''

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, x):
#         self.val = x
#         self.next = None

class Solution:
    # @param l1: the first list
    # @param l2: the second list
    # @return: the sum list of l1 and l2 
    def addLists2(self, l1, l2):
        # Write your code here
        dummy = ListNode(0)
        pre = dummy
        l1 = self.reverseList(l1)
        l2 = self.reverseList(l2)
        a = 0
        while l1 and l2:
            s = l1.val + l2.val + a
            a = s/10
            pre.next = ListNode(s % 10)
            pre = pre.next
            l1 = l1.next
            l2 = l2.next
        if not l1:
            while l2:
                s = l2.val + a
                a = s / 10
                pre.next = ListNode(s % 10)
                pre = pre.next
                l2 = l2.next
        if not l2:
            while l1:
                s = l1.val + a
                a = s / 10
                pre.next = ListNode(s % 10)
                pre = pre.next
                l1 = l1.next
        if a == 1:
            pre.next = ListNode(1)
        return self.reverseList(dummy.next)
        
    def reverseList(self, head):
        dummy = ListNode(0)
        while head:
            p = head.next
            head.next = dummy.next
            dummy.next = head
            head = p
        return dummy.next