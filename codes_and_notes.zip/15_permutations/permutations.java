/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/permutations
@Language: Java
@Datetime: 16-04-05 21:10
*/

class Solution {
    /**
     * @param nums: A list of integers.
     * @return: A list of permutations.
     */
    private void helper(ArrayList<ArrayList<Integer>> rst, ArrayList<Integer> list, ArrayList<Integer> nums){
        if(list.size() == nums.size()){
            rst.add(new ArrayList<Integer>(list));
            return;
        }
        for(int i=0; i<nums.size(); i++){
            if(list.contains(nums.get(i))){
                continue;
            }
            list.add(nums.get(i));
            helper(rst,list,nums);
            list.remove(nums.get(i));
        }
    }
    public ArrayList<ArrayList<Integer>> permute(ArrayList<Integer> nums) {
        // write your code here
        ArrayList<ArrayList<Integer>> rst = new ArrayList<ArrayList<Integer>>();
        ArrayList<Integer> list = new ArrayList<Integer>();
        if(nums == null || nums.size() == 0){
            return rst;
        }
        helper(rst,list,nums);
        return rst;
    }
}
