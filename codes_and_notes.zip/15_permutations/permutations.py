# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/permutations
@Language: Python
@Datetime: 16-08-13 18:13
'''

class Solution:
    """
    @param nums: A list of Integers.
    @return: A list of permutations.
    """
    def permute(self, nums):
        # write your code here
        result = []
        if not nums or len(nums) == 0:
            return result
        tList = []
        self.helper(result, tList, nums)
        return result
        
    def helper(self, result, tList, nums):
        if len(tList) == len(nums):
            result.append(list(tList))
        for i in range(len(nums)):
            if nums[i] in tList:
                continue
            tList.append(nums[i])
            self.helper(result, tList, nums)
            tList.remove(nums[i])
