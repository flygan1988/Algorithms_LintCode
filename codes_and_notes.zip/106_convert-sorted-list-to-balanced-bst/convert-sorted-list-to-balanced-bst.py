# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/convert-sorted-list-to-balanced-bst
@Language: Python
@Datetime: 16-07-10 02:53
'''

"""
Definition of ListNode
class ListNode(object):

    def __init__(self, val, next=None):
        self.val = val
        self.next = next

Definition of TreeNode:
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left, self.right = None, None
"""
class Solution:
    """
    @param head: The first node of linked list.
    @return: a tree node
    """
    def sortedListToBST(self, head):
        # write your code here
        if not head:
            return None
        dummy = ListNode(0)
        dummy.next = head
        median = self.getMedianNode(head)
        head = dummy
        while head.next != median:
            head = head.next
        head.next = None
        left = dummy.next
        right = median.next
        root = TreeNode(median.val)
        root.left = self.sortedListToBST(left)
        root.right = self.sortedListToBST(right)
        return root
        
    def getMedianNode(self,head):
        slow = head
        fast = head.next
        while fast and fast.next:
            slow = slow.next
            fast = fast.next.next
        return slow
