/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/convert-sorted-list-to-balanced-bst
@Language: Java
@Datetime: 16-05-31 23:40
*/

/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */ 
public class Solution {
    /**
     * @param head: The first node of linked list.
     * @return: a tree node
     */
    public TreeNode sortedListToBST(ListNode head) {  
        // write your code here
        if(head == null){
            return null;
        }
        return buildBST(head);
    }
    private ListNode findMedian(ListNode head){
        ListNode slow = head;
        ListNode fast = head.next;
        while(fast != null && fast.next != null){
            slow = slow.next;
            fast = fast.next.next;
        }
        return slow;
    }
    private ArrayList<ListNode> splitByMedian(ListNode head){
        ArrayList<ListNode> res = new ArrayList<ListNode>();
        ListNode median = findMedian(head);
        ListNode p = head;
        ListNode q = head.next;
        ListNode head1 = null;
        ListNode head2 = null;
        while(p!=median && q!=median){
            p = q;
            q = q.next;
        }
        if(p==median){
            head2 = q;
        }else{
            p.next = null;
            head1 = head;
            head2 = q.next;
        }
        res.add(head1);
        res.add(head2);
        res.add(median);
        return res;
    }
    private TreeNode buildBST(ListNode head){
        if(head == null){
            return null;
        }
        ArrayList<ListNode> heads = splitByMedian(head);
        ListNode head1 = heads.get(0);
        ListNode head2 = heads.get(1);
        ListNode median = heads.get(2);
        TreeNode root = new TreeNode(median.val);
        TreeNode left = buildBST(head1);
        TreeNode right = buildBST(head2);
        root.left = left;
        root.right = right;
        return root;
    }
}
