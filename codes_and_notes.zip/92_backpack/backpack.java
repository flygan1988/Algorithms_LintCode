/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/backpack
@Language: Java
@Datetime: 16-05-24 02:41
*/

public class Solution {
    /**
     * @param m: An integer m denotes the size of a backpack
     * @param A: Given n items with size A[i]
     * @return: The maximum size
     */
    public int backPack(int m, int[] A) {
        // write your code here
        boolean[][] d = new boolean[A.length][m+1];
        //Initialization
        for(int i=0; i<A.length; i++){
            d[i][0] = true;
        }
        for(int j=1; j<m+1; j++){
            if(A[0] == j){
                d[0][j] = true;
            }
            else{
                d[0][j] = false;
            }
        }
        //Dynamic Programming
        for(int i=1; i<A.length; i++){
            for(int j=1; j<m+1; j++){
                if(j>=A[i]){
                    d[i][j] = d[i-1][j-A[i]] || d[i-1][j];
                }
                else{
                    d[i][j] = d[i-1][j];
                }
                
            }
        }
        //Return reslut;
        for(int j=m; j>0; j--){
            if(d[A.length-1][j] == true){
                return j;
            }
        }
        return 0;
    }
}