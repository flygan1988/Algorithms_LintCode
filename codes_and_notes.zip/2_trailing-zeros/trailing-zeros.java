/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/trailing-zeros
@Language: Java
@Datetime: 16-06-20 23:48
*/

class Solution {
    /*
     * param n: As desciption
     * return: An integer, denote the number of trailing zeros in n!
     */
    public long trailingZeros(long n) {
        // write your code here
        long count = 0;

        while(n > 0) {
            n /= 5;
            count += n;
        }
        return count;
    }
};
