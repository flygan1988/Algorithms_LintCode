/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/maximum-subarray-iii
@Language: Java
@Datetime: 16-08-12 05:14
*/

public class Solution {
    /**
     * @param nums: A list of integers
     * @param k: An integer denote to find k non-overlapping subarrays
     * @return: An integer denote the sum of max k non-overlapping subarrays
     */
    public int maxSubArray(int[] nums, int k) {
        // write your code here
        int n = nums.length;
        if(k > n){
            return 0;
        }
        int[][] f = new int[n+1][k+1];
        for(int i=0; i<=n; i++){
            f[i][0] = 0;
        }
        for(int j=1; j<=k; j++){
            for(int i=j; i<=n; i++){
                f[i][j] = Integer.MIN_VALUE;
                for(int p=i-1; p>=j-1; p--){
                    f[i][j] = Math.max(f[i][j],f[p][j-1]+maxOneSubArray(nums,p,i-1));
                }
            }
        }
        return f[n][k];
    }
    public int maxOneSubArray(int[] nums, int start, int end){
        int max = Integer.MIN_VALUE;
        int minSum = 0;
        int sum = 0;
        for(int i=start; i<=end; i++){
            sum += nums[i];
            max = Math.max(max,sum-minSum);
            minSum = Math.min(minSum, sum);
        }
        return max;
    }
}
