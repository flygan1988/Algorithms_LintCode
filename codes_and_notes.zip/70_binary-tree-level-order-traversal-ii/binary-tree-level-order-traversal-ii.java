/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/binary-tree-level-order-traversal-ii
@Language: Java
@Datetime: 16-03-13 19:30
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
 
 
public class Solution {
    /**
     * @param root: The root of binary tree.
     * @return: buttom-up level order a list of lists of integer
     */
    public ArrayList<ArrayList<Integer>> levelOrderBottom(TreeNode root) {
        // write your code here
        if(root == null){
			return new ArrayList<ArrayList<Integer>>();
		}
		Queue<TreeNode> queue = new LinkedList<TreeNode>();
		Stack<ArrayList<Integer>> slist = new Stack<ArrayList<Integer>>();
		queue.offer(root);
		while(!queue.isEmpty()){
			ArrayList<Integer> list = new ArrayList<Integer>();
			int size = queue.size();
			for(int i=0; i<size; i++){
				TreeNode node = queue.poll();
				list.add(node.val);
				if(node.left != null){
					queue.offer(node.left);
				}
				if(node.right != null){
					queue.offer(node.right);
				}
			}
			slist.push(list);
		}
		return pushBack(slist);
	}
	private ArrayList<ArrayList<Integer>> pushBack(Stack<ArrayList<Integer>> stack){
		ArrayList<ArrayList<Integer>> list = new ArrayList<ArrayList<Integer>>();
		while(!stack.isEmpty()){
			list.add(stack.pop());
		}
		return list;
	}
}
