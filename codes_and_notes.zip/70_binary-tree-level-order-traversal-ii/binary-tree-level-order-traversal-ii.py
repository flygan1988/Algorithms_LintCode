# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/binary-tree-level-order-traversal-ii
@Language: Python
@Datetime: 16-07-08 05:41
'''

"""
Definition of TreeNode:
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left, self.right = None, None
"""


class Solution:
    """
    @param root: The root of binary tree.
    @return: buttom-up level order in a list of lists of integers
    """
    def levelOrderBottom(self, root):
        # write your code here
        
        if root is None:
            return []
        queue = []
        queue.append([root])
        res = []
        while len(queue) != 0:
            tmp = queue.pop()
            res.insert(0,[tmp[i].val for i in range(0,len(tmp))])
            alist = []
            for i in range(0,len(tmp)):
                if tmp[i].left is not None:
                    alist.append(tmp[i].left)
                if tmp[i].right is not None:
                    alist.append(tmp[i].right)
            if len(alist) != 0:
                queue.append(alist)
        return res;       