/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/longest-consecutive-sequence
@Language: Java
@Datetime: 16-07-02 18:58
*/

public class Solution {
    /**
     * @param nums: A list of integers
     * @return an integer
     */
    public int longestConsecutive(int[] num) {
        // write you code here
        if(num == null || num.length == 0){
            return 0;
        }
        Set<Integer> set = new HashSet<>();
        for(int i=0; i<num.length; i++){
            set.add(num[i]);
        }
        int maxLen = 1;
        for(int i=0; i<num.length; i++){
            int curNum = num[i];
            int curLen = 0;
            while(set.contains(curNum)){
                set.remove(curNum);
                curNum++;
                curLen++;
            }
            curNum = num[i] - 1;
            while(set.contains(curNum)){
                set.remove(curNum);
                curNum--;
                curLen++;
            }
            maxLen = Math.max(maxLen,curLen);
        }
        return maxLen;
    }
}