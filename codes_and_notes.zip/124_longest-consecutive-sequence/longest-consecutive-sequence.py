# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/longest-consecutive-sequence
@Language: Python
@Datetime: 16-07-14 21:26
'''

class Solution:
    """
    @param num, a list of integer
    @return an integer
    """
    def longestConsecutive(self, num):
        # write your code here
        a = {}
        for n in num:
            a[n] = True
        
        maxLen = 1
        for i in range(len(num)):
            cur = num[i]
            Len = 0
            while cur in a:
                del a[cur]
                cur += 1
                Len += 1
            cur = num[i]-1
            while cur in a:
                del a[cur]
                cur -= 1
                Len += 1
            maxLen = max(maxLen, Len)
        return maxLen