/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/valid-palindrome
@Language: Java
@Datetime: 16-06-08 04:02
*/

public class Solution {
    /**
     * @param s A string
     * @return Whether the string is a valid palindrome
     */
    public boolean isPalindrome(String s) {
        // Write your code here
        if(s == null || s.length() == 0){
            return true;
        }
        int i = 0, j = s.length()-1;
        while(i<j){
            if(Character.isLetterOrDigit(s.charAt(i)) && Character.isLetterOrDigit(s.charAt(j)) && Character.toUpperCase(s.charAt(i)) == Character.toUpperCase(s.charAt(j))){
                i++;
                j--;
                continue;
            }
            if(!Character.isLetterOrDigit(s.charAt(i))){
                i++;
                continue;
            }
            if(!Character.isLetterOrDigit(s.charAt(j))){
                j--;
                continue;
            }
            if(Character.toUpperCase(s.charAt(i)) != Character.toUpperCase(s.charAt(j))){
                return false;
            }
        }
        return true;
    }
}