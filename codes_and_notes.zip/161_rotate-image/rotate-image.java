/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/rotate-image
@Language: Java
@Datetime: 16-06-30 04:59
*/

public class Solution {
    /**
     * @param matrix: A list of lists of integers
     * @return: Void
     */
    public void rotate(int[][] matrix) {
        // write your code here
        int n = matrix.length;
        for(int i=0; i<n; i++){
            int s = i;
            int e = n-1-i;
            for(int j=s,k=e; j<e; j++,k--){
                int tmp = matrix[s][j];
                matrix[s][j] = matrix[k][s];
                matrix[k][s] = matrix[e][k];
                matrix[e][k] = matrix[j][e];
                matrix[j][e] = tmp;
            }
        }
    }
}