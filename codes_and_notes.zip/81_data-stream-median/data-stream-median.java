/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/data-stream-median
@Language: Java
@Datetime: 16-05-18 01:17
*/

class myComparator implements Comparator<Integer>{
    @Override
    public int compare(Integer left, Integer right){
        return right.compareTo(left);
    }
}
public class Solution {
    /**
     * @param nums: A list of integers.
     * @return: the median of numbers
     */
    PriorityQueue<Integer> maxHeap = new PriorityQueue(1,new myComparator());
    PriorityQueue<Integer> minHeap = new PriorityQueue(1);
    static int median;
    public int[] medianII(int[] nums) {
        // write your code here
        int[] ans = new int[nums.length];
        median = nums[0];
        ans[0] = nums[0];
        for(int i=1; i<nums.length; i++){
            addNumber(nums[i]);
            ans[i] = getMedian();
        }
        return ans;
    }
    public void addNumber(int num){
        if(median <= num){
            minHeap.add(num);
            if(minHeap.size()-maxHeap.size()>1){
                maxHeap.add(median);
                median = minHeap.poll();
            }
        }else{
            maxHeap.add(num);
            if(maxHeap.size()-minHeap.size()==1){
                minHeap.add(median);
                median = maxHeap.poll();
            }
        }
    }
    public int getMedian(){
        return median;
    }
}