/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/longest-substring-without-repeating-characters
@Language: Java
@Datetime: 16-05-21 00:11
*/

public class Solution {
    /**
     * @param s: a string
     * @return: an integer 
     */
    public int lengthOfLongestSubstring(String s) {
        // write your code here
        int i=0, j=0;
        int ans = 0;
        HashSet<Character> hash = new HashSet<Character>();
        for(i=0;i<s.length();i++){
            while(j<s.length() && !hash.contains(s.charAt(j))){
                hash.add(s.charAt(j));
                j++;
            }
            ans = Math.max(ans,j-i);
            hash.remove(s.charAt(i));
        }
        return ans;
    }
}