# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/longest-substring-without-repeating-characters
@Language: Python
@Datetime: 16-08-05 21:21
'''

class Solution:
    # @param s: a string
    # @return: an integer
    def lengthOfLongestSubstring(self, s):
        # write your code here
        if not s or len(s) == 0:
            return 0
        dic = {}
        j = 0
        maxLen = 1
        for i in range(len(s)):
            while j < len(s) and s[j] not in dic:
                dic[s[j]] = True
                j += 1
            maxLen = max(maxLen,j-i)
            del dic[s[i]]
        return maxLen