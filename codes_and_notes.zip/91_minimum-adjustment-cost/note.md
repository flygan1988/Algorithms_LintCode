```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/minimum-adjustment-cost
@Language: Markdown
@Datetime: 16-06-29 19:35
```

state: f[i][v] denotes the minimum cost of changing A[i-1] to v in A[0...i-1] meeting the requirement;
Initialization: f[0][0...v] = 0;
Connection: f[i][j] = min(f[i-1][k] + abs(A[i] - j)), abs(k-j) <= target;