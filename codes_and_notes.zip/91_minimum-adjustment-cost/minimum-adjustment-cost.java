/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/minimum-adjustment-cost
@Language: Java
@Datetime: 16-06-29 19:35
*/

public class Solution {
    /**
     * @param A: An integer array.
     * @param target: An integer.
     */
    public int MinAdjustmentCost(ArrayList<Integer> A, int target) {
        // write your code here
        int[][] f = new int[A.size()][101];
        for(int i=0; i<101; i++){
            f[0][i] = 0;
        }
        for(int i=0; i<f.length; i++){
            for(int j=1; j<101; j++){
                f[i][j] = Integer.MAX_VALUE;
                if(i == 0){
                    f[i][j] = Math.abs(A.get(i)-j);
                }
                else{
                    for(int k=1; k<101; k++){
                        if(Math.abs(k-j)>target) continue;
                        int tmp = f[i-1][k] + Math.abs(A.get(i)-j);
                        f[i][j] = Math.min(f[i][j],tmp);
                    }
                }
            }
        }
        int minCost = Integer.MAX_VALUE;
        for(int i=1; i<101; i++){
            if(f[A.size()-1][i] < minCost){
                minCost = f[A.size()-1][i];
            }
            
        }
        return minCost;
    }
}