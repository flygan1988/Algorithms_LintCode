/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/two-strings-are-anagrams
@Language: Java
@Datetime: 16-06-21 03:12
*/

public class Solution {
    /**
     * @param s: The first string
     * @param b: The second string
     * @return true or false
     */
    public boolean anagram(String s, String t) {
        // write your code here
        if(s.length() !=  t.length()){
            return false;
        }
        int[] c1 = new int[256];
        int[] c2 = new int[256];
        for(int i=0; i<s.length(); i++){
            c1[s.charAt(i)]++;
            c2[t.charAt(i)]++;
        }
        for(int i=0; i<256; i++){
            if(c1[i] != c2[i]){
                return false;
            }
        }
        return true;
    }
};