/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/remove-duplicates-from-unsorted-list
@Language: Java
@Datetime: 16-06-18 06:07
*/

/**
 * Definition for ListNode
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) {
 *         val = x;
 *         next = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @param head: The first node of linked list.
     * @return: head node
     */
    public ListNode removeDuplicates(ListNode head) { 
        // Write your code here
        if(head == null){
            return head;
        }
        HashSet<Integer> hash = new HashSet<>();
        ListNode p = head;
        ListNode q = head.next;
        hash.add(p.val);
        while(q != null){
            if(hash.contains(q.val)){
                p.next = q.next;
                q = q.next;
            }else{
                hash.add(q.val);
                p = q;
                q = q.next;
            }
        }
        return head;
    }  
}