/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/swap-nodes-in-pairs
@Language: Java
@Datetime: 16-06-20 06:13
*/

/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) { val = x; }
 * }
 */
public class Solution {
    /**
     * @param head a ListNode
     * @return a ListNode
     */
    public ListNode swapPairs(ListNode head) {
        // Write your code here
        if(head == null || head.next == null){
            return head;
        }
        ListNode dummy = new ListNode(0);
        dummy.next = head;;
        ListNode p = head;
        ListNode q = p.next;
        head = dummy;
        while(q != null){
            p.next = q.next;
            head.next = q;
            q.next = p;
            head = p;
            p = head.next;
            if(p != null){
                q = p.next;
            }else{
                break;
            }
        }
        return dummy.next;
    }
}