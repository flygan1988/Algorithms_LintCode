# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/swap-nodes-in-pairs
@Language: Python
@Datetime: 16-08-17 20:09
'''

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, x):
#         self.val = x
#         self.next = None

class Solution:
    # @param head, a ListNode
    # @return a ListNode
    def swapPairs(self, head):
        # Write your code here
        if not head or not head.next:
            return head
        dummy = ListNode(0)
        dummy.next = head
        head = dummy
        p = head.next
        q = p.next
        while p is not None and p.next is not None:
            p.next = q.next
            head.next = q
            q.next = p
            head = p
            p = p.next
            if p is not None:
                q = p.next
        return dummy.next