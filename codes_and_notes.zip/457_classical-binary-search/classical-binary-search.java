/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/classical-binary-search
@Language: Java
@Datetime: 16-06-11 15:45
*/

public class Solution {
    /**
     * @param nums: An integer array sorted in ascending order
     * @param target: An integer
     * @return an integer
     */
    public int findPosition(int[] nums, int target) {
        // Write your code here
        if(nums == null || nums.length == 0){
            return -1;
        }
        return binarySearch(nums,target,0,nums.length-1);
    }
    private int binarySearch(int[] nums, int target, int start, int end){
        if(start == end){
            return nums[start]==target?nums[start]:-1;
        }
        int mid = (start + end) / 2;
        if(nums[mid] == target){
            return mid;
        }
        int left = binarySearch(nums,target,start,mid);
        int right = binarySearch(nums,target,mid+1,end);
        if(left == -1 && right ==-1){
            return -1;
        }
        return left>right?left:right;
    }
}