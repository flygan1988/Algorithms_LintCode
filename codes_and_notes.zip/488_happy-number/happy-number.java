/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/happy-number
@Language: Java
@Datetime: 16-06-14 04:09
*/

public class Solution {
    /**
     * @param n an integer
     * @return true if this is a happy number or false
     */
    public boolean isHappy(int n) {
        // Write your code here
        int sum = n;
        HashSet<Integer> hash = new HashSet<>();
        //String s = String.valueOf(n);
        while(sum != 1){
            String s = String.valueOf(sum);
            sum = 0;
            for(int i=0; i<s.length(); i++){
                sum += (s.charAt(i)-'0')*(s.charAt(i)-'0');
            }
            if(hash.contains(sum)) return false;
            hash.add(sum);
        }
        return true;
    }
}