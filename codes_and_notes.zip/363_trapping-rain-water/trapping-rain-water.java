/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/trapping-rain-water
@Language: Java
@Datetime: 16-05-17 05:20
*/

public class Solution {
    /**
     * @param heights: an array of integers
     * @return: a integer
     */
    public int trapRainWater(int[] heights) {
        // write your code here
        int left = 0;
        int right = heights.length-1;
        int res = 0;
        while(left < right){
            if(heights[left] <= heights[right]){
                left++;
                if(heights[left] < heights[left-1]){
                    res += heights[left-1] - heights[left];
                    heights[left] = heights[left-1];
                }
            }
            else{
                right--;
                if(heights[right] < heights[right+1]){
                    res += heights[right+1] - heights[right];
                    heights[right] = heights[right+1];
                }
            }
        }
        return res;
    }
}