# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/trapping-rain-water
@Language: Python
@Datetime: 16-08-04 20:33
'''

class Solution:
    # @param heights: a list of integers
    # @return: a integer
    def trapRainWater(self, heights):
        # write your code here
        left = 0
        right = len(heights)-1
        total = 0
        while left < right:
            if heights[left] <= heights[right]:
                left += 1
                if heights[left] < heights[left-1]:
                    total += heights[left-1] - heights[left]
                    heights[left] = heights[left-1]
            else:
                right -= 1
                if heights[right] < heights[right+1]:
                    total += heights[right+1] - heights[right]
                    heights[right] = heights[right+1]
        return total