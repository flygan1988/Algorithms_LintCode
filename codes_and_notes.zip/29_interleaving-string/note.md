```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/interleaving-string
@Language: Markdown
@Datetime: 16-07-10 01:07
```

Match[i][j]
    =   (s3.lastChar == s1.lastChar) && Match[i-1][j]
      ||(s3.lastChar == s2.lastChar) && Match[i][j-1]
Initialization：
    i=0 && j=0时，Match[0][0] = true;
    i=0， s3[j] = s2[j], Match[0][j] = Match[0][j-1]
           s3[j] != s2[j], Match[0][j] = false;

    j=0， s3[i] = s1[i], Match[i][0] = Match[i-1][0]
           s3[i] != s1[i], Match[i][0] = false;