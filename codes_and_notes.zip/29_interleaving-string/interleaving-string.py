# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/interleaving-string
@Language: Python
@Datetime: 16-07-10 01:07
'''

class Solution:
    """
    @params s1, s2, s3: Three strings as description.
    @return: return True if s3 is formed by the interleaving of
             s1 and s2 or False if not.
    @hint: you can use [[True] * m for i in range (n)] to allocate a n*m matrix.
    """
    def isInterleave(self, s1, s2, s3):
        # write your code here
        m = len(s1)
        n = len(s2)
        if m+n != len(s3):
            return False
        
        f = [[False] * (n+1) for i in range(m+1)]
        
        f[0][0] = True
        for i in range(1,n+1):
            if s2[i-1] == s3[i-1]:
                f[0][i] = f[0][i-1]
            else:
                f[0][i] = False
        
        for i in range(1,m+1):
            if s1[i-1] == s3[i-1]:
                f[i][0] = f[i-1][0]
            else:
                f[i][0] = False
                
        for i in range(1,m+1):
            for j in range(1,n+1):
                f[i][j] = ((s3[i+j-1] == s1[i-1]) and f[i-1][j]) or ((s3[i+j-1] == s2[j-1]) and f[i][j-1])
        return f[m][n]