/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/unique-characters
@Language: Java
@Datetime: 16-07-15 04:36
*/

public class Solution {
    /**
     * @param str: a string
     * @return: a boolean
     */
    public boolean isUnique(String str) {
        // write your code here
        if(str == null || str.length() == 0 || str.length() == 1){
            return true;
        }
        char[] chars = str.toCharArray();
        Arrays.sort(chars);
        for(int i=1; i<chars.length; i++){
            if(chars[i] == chars[i-1]){
                return false;
            }
        }
        return true;
    }
}