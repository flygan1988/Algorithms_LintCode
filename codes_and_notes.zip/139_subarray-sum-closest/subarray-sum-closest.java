/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/subarray-sum-closest
@Language: Java
@Datetime: 16-06-01 03:19
*/

public class Solution {
    /**
     * @param nums: A list of integers
     * @return: A list of integers includes the index of the first number 
     *          and the index of the last number
     */
    /**
     * //solution1: O(n2)
    public int[] subarraySumClosest(int[] nums) {
        // write your code here
        int[] res = new int[2];
        int[] preSum = new int[nums.length+1];
        int min = Integer.MAX_VALUE;
        for(int i=1; i<preSum.length; i++){
            preSum[i] = preSum[i-1] + nums[i-1];
        }
        for(int i=0; i<preSum.length-1; i++){
            for(int j=i+1; j<preSum.length; j++){
                if(Math.abs(preSum[j]-preSum[i])<min){
                    min = Math.abs(preSum[j] - preSum[i]);
                    res[0] = i;
                    res[1] = j-1;
                }
            }
        }
        return res;
    }**/
    //Solution: O(n,logn)
    class Pair{
        int sum;
        int index;
        Pair(int sum, int index){
            this.sum = sum;
            this.index = index;
        }
    }
    public int[] subarraySumClosest(int[] nums) {
        int[] res = new int[2];
        if(nums == null || nums.length == 0){
            return res;
        }
        if(nums.length == 1){
            res[0] = res[1] = 0;
        }
        Pair[] sums = new Pair[nums.length+1];
        sums[0] = new Pair(0,0);
        int prev = 0;
        for(int i=1; i<sums.length; i++){
            sums[i] = new Pair(prev+nums[i-1],i);
            prev = sums[i].sum;
        }
        Arrays.sort(sums,new Comparator<Pair>(){
            public int compare(Pair p1, Pair p2){
                return p1.sum-p2.sum;
            }
        });
        int min = Integer.MAX_VALUE;
        for(int i=1; i<sums.length; i++){
            if(sums[i].sum-sums[i-1].sum<min){
                min = sums[i].sum-sums[i-1].sum;
                res[0] = sums[i].index-1;
                res[1] = sums[i-1].index-1;
                Arrays.sort(res);
                res[0]++;
            }
        }
        return res;
    }
}
