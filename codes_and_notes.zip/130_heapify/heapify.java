/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/heapify
@Language: Java
@Datetime: 16-05-18 04:20
*/

public class Solution {
    /**
     * @param A: Given an integer array
     * @return: void
     */
    public void heapify(int[] A) {
        // write your code here
        int n = A.length;
        for(int i=n/2-1; i>=0; i--){
            helper(A,i);
        }
    }
    public void helper(int[] A, int i){
        int left = 2*i+1;
        int right = 2*i+2;
        int n = A.length;
        int min = i;
        if(left<n && A[left]<A[min]){
            min = left;
        }
        if(right<n && A[right]<A[min]){
            min = right;
        }
        if(min != i){
            int t = A[min];
            A[min] = A[i];
            A[i] = t;
            helper(A,min);
        }
    }
}