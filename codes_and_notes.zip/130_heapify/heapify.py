# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/heapify
@Language: Python
@Datetime: 16-07-14 21:06
'''

class Solution:
    # @param A: Given an integer array
    # @return: void
    def heapify(self, A):
        # write your code here
        n = len(A)
        for i in range(n/2-1,-1,-1):
            self.helper(A,i)
            
    def helper(self, A, i):
        leftChild = 2*i+1
        rightChild = 2*i+2
        n = len(A)
        Min = i
        if leftChild < n and A[leftChild] < A[Min]:
            Min = leftChild
        if rightChild < n and A[rightChild] < A[Min]:
            Min = rightChild
            
        if Min != i:
            tmp = A[Min]
            A[Min] = A[i]
            A[i] = tmp
            self.helper(A,Min)