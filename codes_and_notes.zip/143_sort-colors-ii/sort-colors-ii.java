/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/sort-colors-ii
@Language: Java
@Datetime: 16-07-13 14:53
*/

class Solution {
    /**
     * @param colors: A list of integer
     * @param k: An integer
     * @return: nothing
     */
    public void sortColors2(int[] colors, int k) {
        // write your code here
        
        int index = 0;
        for(int i=0; i<colors.length; i++){
            int pivot = colors[i];
            int min = Integer.MAX_VALUE;
            for(int j=i; j<colors.length; j++){
                if(colors[j] < min){
                    min = colors[j];
                    index = j;
                }
            }
            colors[i] = min;
            colors[index] = pivot;
        }
    }
}