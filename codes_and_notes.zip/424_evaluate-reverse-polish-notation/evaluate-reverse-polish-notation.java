/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/evaluate-reverse-polish-notation
@Language: Java
@Datetime: 16-07-03 05:12
*/

public class Solution {
    /**
     * @param tokens The Reverse Polish Notation
     * @return the value
     */
    public int evalRPN(String[] tokens) {
        // Write your code here
        Stack<Integer> stack = new Stack<>();
        for(int i=0; i<tokens.length; i++){
            if(!(tokens[i].equals("+")||tokens[i].equals("-")||tokens[i].equals("*")||tokens[i].equals("/"))){
                stack.push(Integer.parseInt(tokens[i]));
            }
            else{
                int num2 = stack.pop();
                int num1 = stack.pop();
                int tmp;
                if(tokens[i].equals("+")){
                    tmp = num1 + num2;
                }else if(tokens[i].equals("-")){
                    tmp = num1 - num2;
                }else if(tokens[i].equals("*")){
                    tmp = num1 * num2;
                }else{
                    tmp = num1 / num2;
                }
                stack.push(tmp);
            }
        }
        return stack.pop();
    }
}