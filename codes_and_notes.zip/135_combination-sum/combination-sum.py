# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/combination-sum
@Language: Python
@Datetime: 16-07-15 01:16
'''

class Solution:
    # @param candidates, a list of integers
    # @param target, integer
    # @return a list of lists of integers
    def combinationSum(self, candidates, target):
        # write your code here
        ans = []
        if not candidates or len(candidates) == 0:
            return ans
        path = []
        candidates.sort()
        self.helper(ans, path, candidates, 0, target)
        return ans
        
    def helper(self, ans, path, candidates, pos, target):
        if target < 0:
            return 
        if target == 0:
            ans.append(list(path))
            return
        for i in range(pos,len(candidates)):
            path.append(candidates[i])
            self.helper(ans, path, candidates, i, target-candidates[i])
            path.pop()