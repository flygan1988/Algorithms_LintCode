/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/reverse-words-in-a-string
@Language: Java
@Datetime: 16-05-24 13:41
*/

public class Solution {
    /**
     * @param s : A string
     * @return : A string
     */
    public String reverseWords(String s) {
        // write your code
        String res = "";
        String[] str = s.split(" ");
        for(int i=str.length-1; i>=0; i--){
            res += str[i];
            if(i != 0){
                res += " ";
            }
        }
        return res;
    }
}
