/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/top-k-largest-numbers-ii
@Language: Java
@Datetime: 16-06-23 04:50
*/

public class Solution {
    int k;
    PriorityQueue<Integer> heap;
    public Solution(int k) {
        // initialize your data structure here.
        heap = new PriorityQueue<Integer>(k,new Comparator<Integer>(){
            public int compare(Integer i1, Integer i2){
                return i2-i1;
            }
        });
        this.k = k;
    }

    public void add(int num) {
        // Write your code here
        heap.offer(num);
    }

    public List<Integer> topk() {
        // Write your code here
        List<Integer> res = new ArrayList<Integer>();
        int i=0;
        while(i<k && heap.size()!=0){
            res.add(heap.poll());
            i++;
        }
        for(int k=0; k<res.size(); k++){
            heap.offer(res.get(k));
        }
        return res;
    }
};