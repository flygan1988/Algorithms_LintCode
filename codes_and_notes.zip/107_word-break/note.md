```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/word-break
@Language: Markdown
@Datetime: 16-03-18 04:26
```

state: f[i] represents if the first i characters can be space-separated.
function: f[i] = {f[j] && j+1~i is a word}, where j<i;
initialize: f[0] = true;
result: f[n]. 
maxLength represents the length of the longest word in the dictionary. 