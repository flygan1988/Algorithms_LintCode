/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/zigzag-iterator
@Language: Java
@Datetime: 16-06-21 20:20
*/

public class ZigzagIterator {
    /**
     * @param v1 v2 two 1d vectors
     */
    List<Integer> merge;
    int curr;
    public ZigzagIterator(List<Integer> v1, List<Integer> v2) {
        // initialize your data structure here.
        int i=0;
        curr = 0;
        merge = new ArrayList<Integer>();
        while(i<v1.size() && i<v2.size()){
            merge.add(v1.get(i));
            merge.add(v2.get(i));
            i++;
        }
        if(i == v1.size()){
            for(int j=i; j<v2.size(); j++){
                merge.add(v2.get(j));
            }
        }
        if(i == v2.size()){
            for(int j=i; j<v1.size(); j++){
                merge.add(v1.get(j));
            }
        }
    }

    public int next() {
        // Write your code here
        return merge.get(curr++);
    }

    public boolean hasNext() {
        // Write your code here  
        return curr<merge.size()?true:false;
    }
}

/**
 * Your ZigzagIterator object will be instantiated and called as such:
 * ZigzagIterator solution = new ZigzagIterator(v1, v2);
 * while (solution.hasNext()) result.add(solution.next());
 * Output result
 */