```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/spiral-matrix
@Language: Markdown
@Datetime: 16-06-23 23:50
```

1. increase columns
2. increase rows
3. decrease columns
4. decrease rows
