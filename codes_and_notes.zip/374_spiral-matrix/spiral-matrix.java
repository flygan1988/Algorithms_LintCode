/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/spiral-matrix
@Language: Java
@Datetime: 16-06-23 23:50
*/

public class Solution {
    /**
     * @param matrix a matrix of m x n elements
     * @return an integer list
     */
    public List<Integer> spiralOrder(int[][] matrix) {
        // Write your code here
        List<Integer> result = new ArrayList<>();
        if(matrix.length == 0){
            return result;
        }
        int m = matrix.length;
        int n = matrix[0].length;
        int i=0, j=0;
        boolean[][] visited = new boolean[matrix.length][matrix[0].length];
        while(i<m && j<n && !visited[i][j]){
            result.add(matrix[i][j]);
            visited[i][j] = true;
            while(++j<n && !visited[i][j]){
                result.add(matrix[i][j]);
                visited[i][j] = true;
            }
            j--;
            while(++i<m && !visited[i][j]){
                result.add(matrix[i][j]);
                visited[i][j] = true;
            }
            i--;
            while(--j>=0 && !visited[i][j]){
                result.add(matrix[i][j]);
                visited[i][j] = true;
            }
            j++;
            while(--i>=0 && !visited[i][j]){
                result.add(matrix[i][j]);
                visited[i][j] = true;
            }
            i++;
            j++;
        }
        return result;
    }
}