/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/longest-increasing-subsequence
@Language: Java
@Datetime: 16-03-17 02:01
*/

public class Solution {
    /**
     * @param nums: The integer array
     * @return: The length of LIS (longest increasing subsequence)
     */
    public int longestIncreasingSubsequence(int[] A) {
        // write your code here
        int n = A.length;
        int[] f = new int[n];
        if(n == 0){
            return 0;
        }
        //Initialize 
        for(int i=0; i<n; i++){
            f[i] = 1;
        }
        //Dynamic programming
        for(int i=1; i<n; i++){
            for(int j=0; j<i; j++){
                if(A[i] >= A[j] && f[j]+1 > f[i]){
                    f[i] = f[j] + 1;
                }
            }
            
        }
        return maxValue(f,n);
    }
    private int maxValue(int[] array, int end){
        int max = array[0];
        for(int i=1; i<end; i++){
            if(array[i] > max){
                max = array[i];
            }
        }
        return max;
    }
}
