# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/longest-increasing-subsequence
@Language: Python
@Datetime: 16-07-09 15:45
'''

class Solution:
    """
    @param nums: The integer array
    @return: The length of LIS (longest increasing subsequence)
    """
    def longestIncreasingSubsequence(self, nums):
        # write your code here
        if nums is None or len(nums) == 0:
            return 0
        n = len(nums)
        f = [1 for i in range(0,n)]
        for i in range(1,n):
            for j in range(0,i):
                if nums[i] >= nums[j]:
                    f[i] = max(f[i],f[j]+1)
        maxLen = 0
        for i in range(0,n):
            maxLen = max(maxLen,f[i])
        return maxLen
