/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/binary-tree-zigzag-level-order-traversal
@Language: Java
@Datetime: 16-03-15 06:07
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
 
 
public class Solution {
    /**
     * @param root: The root of binary tree.
     * @return: A list of lists of integer include 
     *          the zigzag level order traversal of its nodes' values 
     */
    public ArrayList<ArrayList<Integer>> zigzagLevelOrder(TreeNode root) {
        // write your code here
        ArrayList<ArrayList<Integer>> result = new ArrayList<ArrayList<Integer>>();
		if(root == null){
			return result;
		}
		Stack<TreeNode> stack = new Stack<TreeNode>();
		stack.push(root);
		boolean flag = false;
		while(!stack.isEmpty()){
			ArrayList<Integer> list = new ArrayList<Integer>();
			Stack<TreeNode> Tstack = new Stack<TreeNode>();
			while(!stack.isEmpty()){
				TreeNode node = stack.pop();
				list.add(node.val);
				if(!flag){
					if(node.left != null) Tstack.push(node.left);
					if(node.right != null) Tstack.push(node.right);
				}else{
					if(node.right != null) Tstack.push(node.right);
					if(node.left != null) Tstack.push(node.left);
				}
			}
			stack = Tstack;
			flag = !flag;
			result.add(list);
		}
		return result;
    }
}