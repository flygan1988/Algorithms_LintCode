```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/binary-tree-zigzag-level-order-traversal
@Language: Markdown
@Datetime: 16-03-15 06:07
```

The first stack is used for storing the current level nodes;
The second stack is used for storing the next level nodes;
if flag is false, traverse from left to right; otherwise form right to left.