/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/find-minimum-in-rotated-sorted-array-ii
@Language: Java
@Datetime: 16-07-03 04:49
*/

public class Solution {
    /**
     * @param num: a rotated sorted array
     * @return: the minimum number in the array
     */
    public int findMin(int[] num) {
        // write your code here
        int left = 0, right = num.length-1;
        while(left < right-1){
            int mid = left + (right-left)/2;
            if(num[mid] > num[right]){
                left = mid;
            }else if(num[mid] < num[right]){
                right = mid;
            }else{
                right--;
            }
        }
        return num[left] <= num[right]?num[left]:num[right];
    }
}