/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/implement-stack
@Language: Java
@Datetime: 16-06-14 05:28
*/

class ListNode{
    int val;
    ListNode next;
    public ListNode(int val){
        this.val = val;
        this.next = null;
    }
} 
class Stack {
    // Push a new item into the stack
    ListNode dummy = new ListNode(-1);
    public void push(int x) {
        // Write your code here
        ListNode node = new ListNode(x);
        node.next = dummy.next;
        dummy.next = node;
    }

    // Pop the top of the stack
    public void pop() {
        // Write your code here
        if(!isEmpty()){
            dummy.next = dummy.next.next;
        }
    }

    // Return the top of the stack
    public int top() {
        // Write your code here
        if(!isEmpty()){
            return dummy.next.val;
        }
        return -1;
    }

    // Check the stack is empty or not.
    public boolean isEmpty() {
        // Write your code here
        if(dummy.next == null){
            return true;
        }
        return false;
    }    
}