/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/binary-tree-inorder-traversal
@Language: Java
@Datetime: 16-06-11 17:43
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @param root: The root of binary tree.
     * @return: Inorder in ArrayList which contains node values.
     */
    //Solution1: recursion
    /**
    public ArrayList<Integer> inorderTraversal(TreeNode root) {
        // write your code here
        ArrayList<Integer> res = new ArrayList<Integer>();
        helper(res,root);
        return res;
    }
    private void helper(ArrayList<Integer> res, TreeNode root){
        if(root == null){
            return;
        }
        helper(res,root.left);
        res.add(root.val);
        helper(res,root.right);
    }**/
    //Solution2: unrecursion
    public ArrayList<Integer> inorderTraversal(TreeNode root){
        ArrayList<Integer> res = new ArrayList<Integer>();
        if(root == null){
            return res;
        }
        Stack<TreeNode> stack = new Stack<>();
        pushLeft(stack,root);
        while(!stack.isEmpty()){
            TreeNode tmp = stack.pop();
            if(tmp.right != null){
                pushLeft(stack,tmp.right);
            }
            res.add(tmp.val);
        }
        return res;
    }
    private void pushLeft(Stack<TreeNode> stack, TreeNode root){
        while(root != null){
            stack.push(root);
            root = root.left;
        }
    }
}