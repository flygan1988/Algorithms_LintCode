/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/insert-interval
@Language: Java
@Datetime: 16-06-14 06:11
*/

/**
 * Definition of Interval:
 * public classs Interval {
 *     int start, end;
 *     Interval(int start, int end) {
 *         this.start = start;
 *         this.end = end;
 *     }
 */

class Solution {
    /**
     * Insert newInterval into intervals.
     * @param intervals: Sorted interval list.
     * @param newInterval: A new interval.
     * @return: A new sorted interval list.
     */
    public ArrayList<Interval> insert(ArrayList<Interval> intervals, Interval newInterval) {
        ArrayList<Interval> result = new ArrayList<Interval>();
        // write your code here
        intervals.add(newInterval);
        Collections.sort(intervals,new Comparator<Interval>(){
            public int compare(Interval i1, Interval i2){
                if(i1.start != i2.start){
                    return i1.start-i2.start;
                }else{
                    return i1.end-i2.end;
                }
            }
        });
        Interval tmp = intervals.get(0);
        for(int i=1; i<intervals.size(); i++){
            if(tmp.end>=intervals.get(i).start){
                tmp = merge(tmp,intervals.get(i));
            }
            else{
                result.add(tmp);
                tmp = intervals.get(i);
            }
        }
        result.add(tmp);
        return result;
    }
    
    private Interval merge(Interval i1, Interval i2){
        if(i1.end >= i2.end){
            return new Interval(i1.start,i1.end);
        }
        return new Interval(i1.start,i2.end);
    }
}