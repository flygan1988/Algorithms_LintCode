/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/remove-nth-node-from-end-of-list
@Language: Java
@Datetime: 16-05-31 21:32
*/

/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 */ 
public class Solution {
    /**
     * @param head: The first node of linked list.
     * @param n: An integer.
     * @return: The head of linked list.
     */
    ListNode removeNthFromEnd(ListNode head, int n) {
        // write your code here
        ListNode dummy = new ListNode(0);
        dummy.next = head;
        head = dummy;
        while(head != null){
            ListNode nextNode = head.next;
            ListNode p = head.next;
            int i = 0;
            while(i<=n && p!=null){
                p = p.next;
                i++;
            }
            if(i==n && p == null){
                head.next = nextNode.next;
                break;
            }
            else{
                head = head.next;
            }
        }
        return dummy.next;
    }
}
