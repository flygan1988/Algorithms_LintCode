/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/spiral-matrix-ii
@Language: Java
@Datetime: 16-06-24 00:03
*/

public class Solution {
    /**
     * @param n an integer
     * @return a square matrix
     */
    public int[][] generateMatrix(int n) {
        // Write your code here
        int[][] result = new int[n][n];
        if(n == 0){
            return result;
        }
        int i=0,j=0;
        boolean[][] visited = new boolean[n][n];
        int k = 1;
        while(i<n && j<n && !visited[i][j]){
            if(!visited[i][j]){
                result[i][j] = k++;
                visited[i][j] = true;
            }
            while(++j<n && !visited[i][j]){
                result[i][j] = k++;
                visited[i][j] = true;
            }
            j--;
            while(++i<n && !visited[i][j]){
                result[i][j] = k++;
                visited[i][j] = true;
            }
            i--;
            while(--j>=0 && !visited[i][j]){
                result[i][j] = k++;
                visited[i][j] = true;
            }
            j++;
            while(--i>=0 && !visited[i][j]){
                result[i][j] = k++;
                visited[i][j] = true;
            }
            i++;
            j++;
        }
        return result;
    }
}