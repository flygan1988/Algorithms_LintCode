/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/sliding-window-median
@Language: Java
@Datetime: 16-07-02 02:12
*/

public class Solution {
    /**
     * @param nums: A list of integers.
     * @return: The median of the element inside the window at each moving.
     */
    public ArrayList<Integer> medianSlidingWindow(int[] nums, int k) {
        // write your code here
        ArrayList<Integer> res = new ArrayList<Integer>();
        if(nums == null || nums.length == 0 || k<=0){
            return res;
        }
        int[] tmp = new int[k];
        for(int i=0; i<k; i++){
            tmp[i] = nums[i];
        }
        Arrays.sort(tmp);
        int pos = 0;
        for(int i=k; i<nums.length; i++){
            res.add(tmp[(k-1)/2]);
            for(int j=0; j<k; j++){
                if(tmp[j] == nums[i-k]){
                    pos = j;
                    tmp[pos] = nums[i];
                    break;
                }
            }
            while(pos>0 && tmp[pos]<tmp[pos-1]){
                int t = tmp[pos]; tmp[pos] = tmp[pos-1]; tmp[pos-1] = t;
                pos -= 1;
            }
            while(pos+1<k && tmp[pos]>tmp[pos+1]){
                int t = tmp[pos]; tmp[pos] = tmp[pos+1]; tmp[pos+1] = t;
                pos += 1;
            }
        }
        res.add(tmp[(k-1)/2]);
        return res;
    }
}
