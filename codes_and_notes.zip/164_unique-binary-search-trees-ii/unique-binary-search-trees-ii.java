/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/unique-binary-search-trees-ii
@Language: Java
@Datetime: 16-06-23 04:32
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @paramn n: An integer
     * @return: A list of root
     */
    public List<TreeNode> generateTrees(int n) {
        // write your code here
        if(n == 0){
            List<TreeNode> res = new ArrayList<TreeNode>();
            res.add(null);
            return res;
        }
        return helper(1,n);
    }
    public List<TreeNode> helper(int start, int end){
        List<TreeNode> result = new ArrayList<TreeNode>();
        if(start > end){
            result.add(null);
            return result;
        }
        for(int i=start; i<=end; i++){
            List<TreeNode> ls = helper(start,i-1);
            List<TreeNode> rs = helper(i+1,end);
            for(TreeNode l:ls){
                for(TreeNode r:rs){
                    TreeNode curr = new TreeNode(i);
                    curr.left = l;
                    curr.right = r;
                    result.add(curr);
                }
            }
        }
        return result;
    }
}