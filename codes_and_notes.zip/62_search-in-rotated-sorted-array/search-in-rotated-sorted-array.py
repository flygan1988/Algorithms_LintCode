# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/search-in-rotated-sorted-array
@Language: Python
@Datetime: 16-07-08 01:45
'''

class Solution:
    """
    @param A : a list of integers
    @param target : an integer to be searched
    @return : an integer
    """
    def search(self, A, target):
        # write your code here
        if A == None or len(A) == 0:
            return -1
        minIndex = self.findMin(A)
        if minIndex == 0:
            return self.bsearch(A,0,len(A)-1,target)
        if self.bsearch(A,0,minIndex-1,target) == -1:
            return self.bsearch(A,minIndex,len(A)-1,target)
        return self.bsearch(A,0,minIndex-1,target)
            
    def findMin(self, num):
        # write your code here
        if num == None or len(num) == 0:
            return -1
        left = 0
        right = len(num)-1
        while left < right - 1:
            mid = (left + right) / 2
            if num[mid] > num[right]:
                left = mid
            else:
                right = mid
        if num[left] < num[right]:
            return left
        return right
    
    def bsearch(self, num, start, end, target):
        # write your code here
        if num == None or len(num) == 0:
            return -1
        left = start
        right = end
        while left < right - 1:
            mid = (left + right) / 2
            if num[mid] > target:
                right = mid
            elif num[mid] < target:
                left = mid
            else:
                return mid
        if num[left] == target:
            return left
        if num[right] == target:
            return right
        return -1