/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/search-in-rotated-sorted-array
@Language: Java
@Datetime: 16-05-27 19:45
*/

public class Solution {
    /** 
     *@param A : an integer rotated sorted array
     *@param target :  an integer to be searched
     *return : an integer
     */
    public int search(int[] A, int target) {
        // write your code here
        if(A.length == 0){
            return -1;
        }
        int minIndex = findMin(A);
        int left = helper(A,0,minIndex-1,target);
        int right = helper(A,minIndex,A.length-1,target);
        if(left != -1){
            return left;
        }
        if(right != -1){
            return right;
        }
        return -1;
    }
    private int helper(int[] A, int l, int r, int target){
        if(r < l){
            return -1;
        }
        int left = l, right = r;
        while(left<right-1){
            int mid = (left+right)/2;
            if(A[mid] == target){
                return mid;
            }else if(A[mid]<target){
                left = mid;
            }else{
                right = mid;
            }
        }
        if(A[left] == target){
            return left;
        }
        if(A[right] == target){
            return right;
        }
        return -1;
    }
    private int findMin(int[] num){
        int left = 0, right = num.length-1;
        while(left<right-1){
            int mid = (left+right)/2;
            if(num[mid]>num[right]){
                left = mid;
            }else{
                right = mid;
            }
        }
        if(num[left]<num[right]){
            return left;
        }
        return right;
    }
}
