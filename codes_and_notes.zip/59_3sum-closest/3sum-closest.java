/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/3sum-closest
@Language: Java
@Datetime: 16-04-03 01:32
*/

public class Solution {
    /**
     * @param numbers: Give an array numbers of n integer
     * @param target : An integer
     * @return : return the sum of the three integers, the sum closest target.
     */
    public int threeSumClosest(int[] numbers ,int target) {
        // write your code here
        int min = Integer.MAX_VALUE;
        Arrays.sort(numbers);
        for(int i=numbers.length-1; i>1; i--){
            int left = 0;
            int right = i-1;
            while(left < right){
                int sum = numbers[left]+numbers[right]+numbers[i];
                if(sum == target){
                    return sum;
                }
                else if(sum < target){
                    left++;
                }
                else{
                    right--;
                }
                min = Math.abs(sum-target) < Math.abs(min-target)?sum:min;
            }
        }
        return min;
    }
}
