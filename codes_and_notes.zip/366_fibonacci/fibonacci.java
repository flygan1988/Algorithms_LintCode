/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/fibonacci
@Language: Java
@Datetime: 16-06-11 15:23
*/

class Solution {
    /**
     * @param n: an integer
     * @return an integer f(n)
     */
    public int fibonacci(int n) {
        // write your code here
        if(n == 1){
            return 0;
        }
        int[] arr = new int[n];
        arr[0] = 0;
        arr[1] = 1;
        for(int i=2; i<n; i++){
            arr[i] = arr[i-1] + arr[i-2];
        }
        return arr[n-1];
    }
}

