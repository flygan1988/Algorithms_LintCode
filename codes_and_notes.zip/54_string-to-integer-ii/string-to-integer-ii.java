/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/string-to-integer-ii
@Language: Java
@Datetime: 16-06-09 05:32
*/

public class Solution {
    /**
     * @param str: A string
     * @return An integer
     */
    public int atoi(String str) {
        // write your code here
        if(str.length() == 0 || str == null){
            return 0;
        }
        str = str.trim();
        long ans = 0;
        int sign = 1;
        int index = 0;
        if(str.charAt(index) == '+'){
            index++;
        }else if(str.charAt(index) == '-'){
            sign = -1;
            index++;
        }
        for(; index<str.length(); index++){
            if(!Character.isDigit(str.charAt(index))){
                break;
            }
            ans = ans*10 + (str.charAt(index)-'0');
            if(ans > Integer.MAX_VALUE){
                break;
            }
        }
        if(sign * ans >= Integer.MAX_VALUE){
            return Integer.MAX_VALUE;
        }
        if(sign * ans <= Integer.MIN_VALUE){
            return Integer.MIN_VALUE;
        }
        return (int)ans*sign;
    }
}