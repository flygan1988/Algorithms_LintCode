/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/largest-number
@Language: Java
@Datetime: 16-07-02 20:16
*/

class NumComparator implements Comparator<String>{
    @Override
    public int compare(String s1, String s2){
        return (s2+s1).compareTo(s1+s2);
    }
}
public class Solution {
    /**
     *@param num: A list of non negative integers
     *@return: A string
     */
    public String largestNumber(int[] num) {
        // write your code here
        //String res = "";
        if(num == null || num.length == 0){
            return "";
        }
        String[] strs = new String[num.length];
        StringBuilder sb = new StringBuilder();
        for(int i=0; i<num.length; i++){
            strs[i] = String.valueOf(num[i]);
        }
        Arrays.sort(strs,new NumComparator());
        for(int i=0; i<strs.length; i++){
            sb.append(strs[i]);
        }
        String result = sb.toString();
        int i = 0;
        while(i < result.length() && result.charAt(i) == '0'){
            i++;
        }
        if(i == result.length()) return "0";
        return result.substring(i,result.length());
    }
}