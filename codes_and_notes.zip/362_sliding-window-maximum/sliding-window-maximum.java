/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/sliding-window-maximum
@Language: Java
@Datetime: 16-05-17 20:51
*/

public class Solution {
    /**
     * @param nums: A list of integers.
     * @return: The maximum number inside the window at each moving.
     */
    public ArrayList<Integer> maxSlidingWindow(int[] nums, int k) {
        // write your code here
        int n = nums.length;
        ArrayList<Integer> res = new ArrayList<Integer>();
        Deque<Integer> deque = new ArrayDeque<Integer>();
        int i = 0;
        for(int now:nums){
            i++;
            while(!deque.isEmpty() && now > deque.peekLast()){
                deque.pollLast();
            }
            deque.offer(now);
            if(i > k && deque.peekFirst() == nums[i-k-1]){
                deque.pollFirst();
            }
            if(i >= k){
                res.add(deque.peekFirst());
            }
        }
        return res;
    }
}
