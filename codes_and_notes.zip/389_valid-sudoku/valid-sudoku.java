/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/valid-sudoku
@Language: Java
@Datetime: 16-06-08 23:53
*/

class Solution {
    /**
      * @param board: the board
        @return: wether the Sudoku is valid
      */
    public boolean isValidSudoku(char[][] board) {
        boolean[] visited = new boolean[9];
        //valid rows
        for(int i=0; i<9; i++){
            Arrays.fill(visited,false);
            for(int j=0; j<9; j++){
                if(!helper(visited,board[i][j])){
                    return false;
                }
            }
        }
        //valid cols
        for(int i=0; i<9; i++){
            Arrays.fill(visited,false);
            for(int j=0; j<9; j++){
                if(!helper(visited,board[j][i])){
                    return false;
                }
            }
        }
        //valid submatrix
        for(int i=0; i<9; i+=3){
            for(int j=0; j<9; j+=3){
                Arrays.fill(visited,false);
                for(int k=0; k<9; k++){
                    if(!helper(visited,board[i+k/3][j+k%3])){
                        return false;
                    }
                }
            }
        }
        return true;
    }
    private boolean helper(boolean[] visited, char c){
        if(c == '.'){
            return true;
        }
        int num = c - '0';
        if(num < 1 || num >9 || visited[num-1]){
            return false;
        }
        visited[num-1] = true;
        return true;
    }
};