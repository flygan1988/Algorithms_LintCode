/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/maximum-subarray-difference
@Language: Java
@Datetime: 16-04-04 01:36
*/

public class Solution {
    /**
     * @param nums: A list of integers
     * @return: An integer indicate the value of maximum difference between two
     *          Subarrays
     */
    private int maxSubArray(int[] a, int start, int end){
        if(start == end){
            return a[start];
        }
        int max = Integer.MIN_VALUE;
        int sum = 0, minSum = 0;
        for(int i=start; i<=end; i++){
            sum += a[i];
            max = Math.max(max,sum-minSum);
            minSum = Math.min(sum,minSum);
        }
        return max;
    }
    private int minSubArray(int[] a, int start, int end){
        if(start == end){
            return a[start];
        }
        int min = Integer.MAX_VALUE;
        int sum = 0, maxSum = 0;
        for(int i=start; i<=end; i++){
            sum += a[i];
            min = Math.min(min,sum-maxSum);
            maxSum = Math.max(sum,maxSum);
        }
        return min;
    }
    public int maxDiffSubArrays(int[] nums) {
        // write your code here
        int largest = Integer.MIN_VALUE;
        for(int i=0; i<nums.length-1; i++){
            int min1 = minSubArray(nums,0,i), max1 = maxSubArray(nums,0,i);
            int min2 = minSubArray(nums,i+1,nums.length-1), max2 = maxSubArray(nums,i+1,nums.length-1);
            int temp = Math.max(Math.abs(min1-max2),Math.abs(max1-min2));
            largest = Math.max(largest,temp);
        }
        return largest;
    }
}

