# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/maximum-subarray-difference
@Language: Python
@Datetime: 16-07-13 23:54
'''

class Pair:
    def __init__(self, Min, Max):
        self.Min = Min
        self.Max = Max
        
class Solution:
    """
    @param nums: A list of integers
    @return: An integer indicate the value of maximum difference between two
             Subarrays
    """
    def preSums(self, nums):
        preSums = []
        Sum = 0
        maxSum = 0
        minSum = 0
        Max = -sys.maxint
        Min = sys.maxint
        for i in range(0,len(nums)):
            Sum += nums[i]
            Min = min(Min, Sum-maxSum)
            Max = max(Max, Sum-minSum)
            maxSum = max(maxSum,Sum)
            minSum = min(minSum,Sum)
            preSums.append(Pair(Min,Max))
        return preSums
        
    def postSums(self, nums):
        postSums = []
        Sum = 0
        maxSum = 0
        minSum = 0
        Max = -sys.maxint
        Min = sys.maxint
        for i in range(len(nums)-1,-1,-1):
            Sum += nums[i]
            Min = min(Min, Sum-maxSum)
            Max = max(Max, Sum-minSum)
            maxSum = max(maxSum,Sum)
            minSum = min(minSum,Sum)
            postSums.insert(0,Pair(Min,Max))
        return postSums
            
    def maxDiffSubArrays(self, nums):
        # write your code here
        
        pre = self.preSums(nums)
        post = self.postSums(nums)
        
        maxDiff = -sys.maxint
        for i in range(len(nums)-1):
            max1 = max(abs(pre[i].Min-post[i+1].Max), abs(pre[i].Max-post[i+1].Min))
            maxDiff = max(maxDiff,max1)
        return maxDiff
            
            
        