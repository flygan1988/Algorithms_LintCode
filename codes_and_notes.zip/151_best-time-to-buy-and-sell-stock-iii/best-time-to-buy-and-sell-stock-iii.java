/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/best-time-to-buy-and-sell-stock-iii
@Language: Java
@Datetime: 16-07-07 01:57
*/

class Solution {
    /**
     * @param prices: Given an integer array
     * @return: Maximum profit
     */
    public int maxProfit(int[] prices) {
        // write your code here
        if(prices.length < 2){
            return 0;
        }
        int n = prices.length;
        int[] preProfit = new int[n];
        int[] postProfit = new int[n];
        int curMin = prices[0];
        for(int i=1; i<n; i++){
            curMin = Math.min(curMin,prices[i]);
            preProfit[i] = Math.max(preProfit[i],prices[i]-curMin);
        }
        
        int curMax = prices[n-1];
        for(int j=n-2; j>=0; j--){
            curMax = Math.max(curMax,prices[j]);
            postProfit[j] = Math.max(postProfit[j+1],curMax-prices[j]);
        }
        
        int maxProfit = 0;
        for(int k=0; k<n; k++){
            maxProfit = Math.max(maxProfit,preProfit[k]+postProfit[k]);
        }
        return maxProfit;
    }
};