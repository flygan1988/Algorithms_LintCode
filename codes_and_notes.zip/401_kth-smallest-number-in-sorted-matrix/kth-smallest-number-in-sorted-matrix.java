/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/kth-smallest-number-in-sorted-matrix
@Language: Java
@Datetime: 16-05-25 04:47
*/

class Item{
    int x,y;
    int value;
    public Item(int x, int y, int value){
        this.x = x;
        this.y = y;
        this.value = value;
    }
}
class MyComparator implements Comparator<Item>{
    public int compare(Item t1, Item t2){
        return t1.value-t2.value;
    }
}
public class Solution {
    /**
     * @param matrix: a matrix of integers
     * @param k: an integer
     * @return: the kth smallest number in the matrix
     */
    public int kthSmallest(int[][] matrix, int k) {
        // write your code here
        int n = matrix.length, m = matrix[0].length;
        boolean[][] visited = new boolean[n][m];
        PriorityQueue<Item> q = new PriorityQueue<Item>(1,new MyComparator());
        q.offer(new Item(0,0,matrix[0][0]));
        visited[0][0] = true;
        int i = 1;
        while(i<k){
            Item now = q.poll();
            int x = now.x, y = now.y;
            if(x<n-1 && !visited[x+1][y]){
                q.offer(new Item(x+1,y,matrix[x+1][y]));
                visited[x+1][y] = true;
            }
            if(y<m-1 && !visited[x][y+1]){
                q.offer(new Item(x,y+1,matrix[x][y+1]));
                visited[x][y+1] = true;
            }
            i++;
        }
        return q.poll().value;
    }
}