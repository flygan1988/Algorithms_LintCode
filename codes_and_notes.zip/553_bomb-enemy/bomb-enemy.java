/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/bomb-enemy
@Language: Java
@Datetime: 16-08-25 19:26
*/


public class Solution {
    /**
     * @param grid Given a 2D grid, each cell is either 'W', 'E' or '0'
     * @return an integer, the maximum enemies you can kill using one bomb
     */
     public int maxKilledEnemies(char[][] grid) {
        // Write your code here
        if(grid == null || grid.length == 0 || grid[0].length == 0){
            return 0;
        }
        int m = grid.length;
        int n = grid[0].length;
        int rowhits = 0;
        int answer = 0;
        int[] colhits = new int[n];
        for(int i=0; i<m; i++){
            for(int j=0; j<n; j++){
                if(j == 0 || grid[i][j-1] == 'W'){
                    rowhits = 0;
                    for(int k=j; k<n&&grid[i][k]!='W'; k++){
                        if(grid[i][k] == 'E'){
                            rowhits++;
                        }
                    }
                }
                if(i == 0 || grid[i-1][j] == 'W'){
                    colhits[j] = 0;
                    for(int k=i; k<m&&grid[k][j]!='W'; k++){
                        if(grid[k][j] == 'E'){
                            colhits[j]++;
                        }
                    }
                }
                if(grid[i][j] == '0'){
                    answer = Math.max(answer, rowhits+colhits[j]);
                }
            }
        }
        return answer;
     }
    //Solution1: Naive solution
    // public int maxKilledEnemies(char[][] grid) {
    //     // Write your code here
    //     if(grid == null || grid.length == 0 || grid[0].length == 0){
    //         return 0;
    //     }
    //     int m = grid.length;
    //     int n = grid[0].length;
    //     int max = 0;
    //     for(int i=0; i<m; i++){
    //         for(int j=0; j<n; j++){
    //             if(grid[i][j] != '0'){
    //                 continue;
    //             }
    //             int countCol = 0;
    //             int k = j;
    //             while(k >= 0 && grid[i][k] != 'W'){
    //                 if(grid[i][k] == 'E'){
    //                   countCol++; 
    //                 }
    //                 k--;
    //             }
    //             k = j;
    //             while(k < n && grid[i][k] != 'W'){
    //                 if(grid[i][k] == 'E'){
    //                   countCol++; 
    //                 }
    //                 k++;
    //             }
    //             int countRow = 0;
    //             int p = i;
    //             while(p >= 0 && grid[p][j] != 'W'){
    //                 if(grid[p][j] == 'E'){
    //                   countRow++; 
    //                 }
    //                 p--;
    //             }
    //             p = i;
    //             while(p < m && grid[p][j] != 'W'){
    //                 if(grid[p][j] == 'E'){
    //                   countRow++; 
    //                 }
    //                 p++;
    //             }
    //             max = Math.max(max,countCol+countRow);
    //         }
    //     }
    //     return max;
    // }
}