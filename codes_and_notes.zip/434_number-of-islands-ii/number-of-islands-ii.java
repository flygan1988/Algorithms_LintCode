/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/number-of-islands-ii
@Language: Java
@Datetime: 16-05-15 22:50
*/

/**
 * Definition for a point.
 * class Point {
 *     int x;
 *     int y;
 *     Point() { x = 0; y = 0; }
 *     Point(int a, int b) { x = a; y = b; }
 * }
 */
class UnionFind{
    HashMap<Integer,Integer> father = new HashMap<Integer,Integer>();
    
    public int find(int x){
        int parent = father.get(x);
        while(parent != father.get(parent)){
            parent = father.get(parent);
        }
        int temp = -1;
        int fa = x;
        while(parent != father.get(fa)){
            temp = father.get(fa);
            father.put(fa,parent);
            fa = temp;
        }
        return parent;
    }
    public void union(int x, int y){
        int fa_x = find(x);
        int fa_y = find(y);
        if(fa_x != fa_y){
            father.put(fa_x,fa_y);
        }
    }
}
public class Solution {
    /**
     * @param n an integer
     * @param m an integer
     * @param operators an array of point
     * @return an integer array
     */
    public List<Integer> numIslands2(int n, int m, Point[] operators) {
        // Write your code here
        UnionFind uf = new UnionFind();
        ArrayList<Integer> result = new ArrayList<Integer>();
        if(operators == null || operators.length == 0){
            return result;
        }
        int[][] a = new int[n][m];
        for(int i=0; i<m*n; i++){
            a[i/m][i%m] = 0;
            uf.father.put(i,i);
        }
        int count = 0;
        
        for(int i=0; i<operators.length; i++){
            int x = operators[i].x;
            int y = operators[i].y;
            int id = x*m + y;
            a[x][y] = 1;
            count++;
            if(y>=1 && a[x][y-1]==1 && uf.find(id-1)!=uf.find(id)){
                uf.union(id-1,id);
                count--;
            }
            if(y<m-1 && a[x][y+1]==1 && uf.find(id)!=uf.find(id+1)){
                uf.union(id,id+1);
                count--;
            }
            if(x>=1 && a[x-1][y]==1 && uf.find(id)!=uf.find(id-m)){
                uf.union(id,id-m);
                count--;
            }
            if(x<n-1 && a[x+1][y]==1 && uf.find(id)!=uf.find(id+m)){
                uf.union(id,id+m);
                count--;
            }
            result.add(count);
        }
        return result;
    }
}