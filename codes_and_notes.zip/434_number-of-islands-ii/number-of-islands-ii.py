# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/number-of-islands-ii
@Language: Python
@Datetime: 16-07-30 05:03
'''

# Definition for a point.
# class Point:
#     def __init__(self, a=0, b=0):
#         self.x = a
#         self.y = b
class UnionFind:
    def __init__(self):
        self.father = {}
    def find(self, x):
        parent = self.father[x]
        while parent != self.father[parent]:
            parent = self.father[parent]
        temp = -1
        fa = x
        while parent != self.father[fa]:
            temp = self.father[fa]
            self.father[fa] = parent
            fa = temp
        return parent
        
    def union(self, x, y):
        fa_x = self.find(x)
        fa_y = self.find(y)
        if fa_x != fa_y:
            self.father[fa_x] = fa_y
        
class Solution:
    # @param {int} n an integer
    # @param {int} m an integer
    # @param {Pint[]} operators an array of point
    # @return {int[]} an integer array
    def numIslands2(self, n, m, operators):
        # Write your code here
        uf = UnionFind()
        A = [[0 for i in range(m)] for j in range(n)]
        for i in range(n*m):
            uf.father[i] = i
        count = 0
        result = []
        for pair in operators:
            x = pair.x
            y = pair.y
            A[x][y] = 1
            id = x*m+y
            count += 1
            if y>=1 and A[x][y-1]==1 and uf.find(id) != uf.find(id-1):
                uf.union(id,id-1)
                count -= 1
            if y<m-1 and A[x][y+1]==1 and uf.find(id) != uf.find(id+1):
                uf.union(id,id+1)
                count -= 1
            if x>=1 and A[x-1][y]==1 and uf.find(id) != uf.find(id-m):
                uf.union(id,id-m)
                count -= 1
            if x<n-1 and A[x+1][y]==1 and uf.find(id) != uf.find(id+m):
                uf.union(id,id+m)
                count -= 1
            result.append(count)
        return result