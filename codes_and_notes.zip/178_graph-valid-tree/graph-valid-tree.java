/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/graph-valid-tree
@Language: Java
@Datetime: 16-05-14 06:41
*/

class UnionFind{
    HashMap<Integer,Integer> father = new HashMap<Integer,Integer>();
    public int find(int x){
        int parent = father.get(x);
        while(parent != father.get(parent)){
            parent = father.get(parent);
        }
        return parent;
    }
    public void union(int x, int y){
        int fa_x = find(x);
        int fa_y = find(y);
        if(fa_x != fa_y){
            father.put(fa_x,fa_y);
        }
    }
}
public class Solution {
    /**
     * @param n an integer
     * @param edges a list of undirected edges
     * @return true if it's a valid tree, or false
     */
    public boolean validTree(int n, int[][] edges) {
        // Write your code here
        if(n-1 != edges.length){
            return false;
        }
        UnionFind uf = new UnionFind();
        for(int i=0; i<n; i++){
            uf.father.put(i,i);
        }
        for(int i=0; i<edges.length; i++){
            if(uf.find(edges[i][0]) == uf.find(edges[i][1])){
                return false;
            }
            else{
                uf.union(edges[i][0],edges[i][1]);
            }
        }
        return true;
    }
}