/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/partition-array
@Language: Java
@Datetime: 16-08-12 14:57
*/

public class Solution {
	/** 
     *@param nums: The integer array you should partition
     *@param k: As description
     *return: The index after partition
     */
    public int partitionArray(int[] nums, int k) {
	    //write your code here
	    int left = 0;
	    int right = nums.length-1;
	    while(left < right){
	        while(nums[left] < k && left < right){
	            left++;
	        }
	        while(nums[right] >= k && left < right){
	            right--;
	        }
	        int temp = nums[left];
	        nums[left] = nums[right];
	        nums[right] = temp;
	    }
	    if(right == nums.length-1){
	        return nums.length;
	    }
	    return left;
    }
}