# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/partition-array
@Language: Python
@Datetime: 16-07-12 15:32
'''

class Solution:
    """
    @param nums: The integer array you should partition
    @param k: As description
    @return: The index after partition
    """
    def partitionArray(self, nums, k):
        # write your code here
        # you should partition the nums by k
        # and return the partition index as description
        left = 0
        right = len(nums)-1
        while left < right:
            while left < right and nums[left] < k:
                left += 1
            while left < right and nums[right] >= k:
                right -= 1
            self.swap(nums, left, right)
            
        if right == len(nums)-1:
            return len(nums)
        else:
            return left
            
    def swap(self, nums, i, j):
        tmp = nums[i]
        nums[i] = nums[j]
        nums[j] = tmp