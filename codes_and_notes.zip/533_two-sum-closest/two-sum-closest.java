/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/two-sum-closest
@Language: Java
@Datetime: 16-06-01 20:22
*/

public class Solution {
    /**
     * @param nums an integer array
     * @param target an integer
     * @return the difference between the sum and the target
     */
    public int twoSumCloset(int[] nums, int target) {
        // Write your code here
        Arrays.sort(nums);
        int left = 0; 
        int right = nums.length-1;
        int ans = Integer.MAX_VALUE;
        while(left < right){
            if(nums[left]+nums[right]>target){
                ans = Math.min(ans,nums[left]+nums[right]-target);
                right--;
            }else if(nums[left]+nums[right]<target){
                ans = Math.min(ans,target-(nums[left]+nums[right]));
                left++;
            }else{
                return 0;
            }
        }
        return ans;
    }
}