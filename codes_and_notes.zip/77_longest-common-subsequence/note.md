```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/longest-common-subsequence
@Language: Markdown
@Datetime: 16-07-10 00:32
```

state: f[i][j] represents the length of LCS of the first i characters in Aand the first j characters in B.
function: f[i][j] = f[i-1][j-1] + 1 if A[i-1] == B[j-1];
or = max{f[i-1][j], f[i][j-1]} if A[i-1] != B[j-1]
initialize: f[i][0] = 0  f[0][j] = 0;
result: f[m][n]