/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/scramble-string
@Language: Java
@Datetime: 16-07-07 03:55
*/

public class Solution {
    /**
     * @param s1 A string
     * @param s2 Another string
     * @return whether s2 is a scrambled string of s1
     */
    public boolean isScramble(String s1, String s2) {
        // Write your code here
        int len1 = s1.length();
        int len2 = s2.length();
        if(len1 != len2){
            return false;
        }
        return helper(s1,s2);
    }
    public boolean helper(String s1,String s2){
        
        if(s1.length() == 1){
            return s1.equals(s2);
        }
        int len = s1.length();
        for(int i=1; i<len; i++){
            if(helper(s1.substring(0,i),s2.substring(0,i)) && helper(s1.substring(i,len),s2.substring(i,len))){
                return true;
            }
            if(helper(s1.substring(0,i),s2.substring(len-i,len)) && helper(s1.substring(i,len),s2.substring(0,len-i))){
                return true;
            }
        }
        return false;
    }
}