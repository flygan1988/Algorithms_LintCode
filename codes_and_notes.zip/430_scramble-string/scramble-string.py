# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/scramble-string
@Language: Python
@Datetime: 16-08-10 21:55
'''

class Solution:
    # @param {string} s1 A string
    # @param {string} s2 Another string
    # @return {boolean} whether s2 is a scrambled string of s1
    def isScramble(self, s1, s2):
        # Write your code here
        if len(s1) != len(s2):
            return False
        return self.helper(s1,s2)
        
    def helper(self, s1, s2):
        if len(s1) == 1:
            return s1 == s2
        n = len(s1)
        for i in range(1,n):
            if self.helper(s1[0:i],s2[0:i]) and self.helper(s1[i:],s2[i:]):
                return True
            if self.helper(s1[0:i],s2[n-i:]) and self.helper(s1[i:],s2[0:n-i]):
                return True
        return False
            