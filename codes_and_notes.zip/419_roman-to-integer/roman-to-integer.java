/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/roman-to-integer
@Language: Java
@Datetime: 16-06-09 04:17
*/

public class Solution {
    /**
     * @param s Roman representation
     * @return an integer
     */
    public int romanToInt(String s) {
        // Write your code here
        HashMap<Character,Integer> map = new HashMap<Character,Integer>();
        map.put('I',1);
        map.put('V',5);
        map.put('X',10);
        map.put('L',50);
        map.put('C',100);
        map.put('D',500);
        map.put('M',1000);
        int ans = 0;
        if(s.length() == 0 || s == null){
            return 0;
        }
        int[] temp = new int[s.length()];
        for(int i=0; i<s.length(); i++){
            temp[i] = map.get(s.charAt(i));
        }
        //Calculation
        for(int i=temp.length-1; i>=0; i--){
            if(i < temp.length-1 && temp[i] < temp[i+1]){
                ans -= temp[i];
            }else{
                ans += temp[i];
            }
        }
        return ans;
    }
}