/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/plus-one
@Language: Java
@Datetime: 16-05-24 04:35
*/

public class Solution {
    /**
     * @param digits a number represented as an array of digits
     * @return the result
     */
    public int[] plusOne(int[] digits) {
        // Write your code here
        long num = 0;
        for(int i=0; i<digits.length; i++){
            num += digits[i] * (long)Math.pow(10,digits.length-i-1);
        }
        num += 1;
        int len = String.valueOf(num).length();
        int[] res = new int[len];
        for(int i=0; i<len; i++){
            res[i] = (int)(num / (long)Math.pow(10,len-i-1));
            num -= res[i] * (long)Math.pow(10,len-i-1);
        }
        return res;
    }
}