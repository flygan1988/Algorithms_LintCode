```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/insert-node-in-a-binary-search-tree
@Language: Markdown
@Datetime: 16-07-08 05:15
```

use current variable to find the insertion position.
use currRoot variable to find the root of insertion node