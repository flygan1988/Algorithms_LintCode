/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/insert-node-in-a-binary-search-tree
@Language: Java
@Datetime: 16-03-15 04:30
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @param root: The root of the binary search tree.
     * @param node: insert this node into the binary search tree
     * @return: The root of the new binary search tree.
     */
    public TreeNode insertNode(TreeNode root, TreeNode node) {
        // write your code here
        if(root == null){
			root = node;
			return root;
		}
		TreeNode current = root;
		TreeNode currRoot = null;
		while(current != null){
			currRoot = current;
			if(node.val <= current.val){
				current = current.left;
			}else{
				current = current.right;
			}
		}
		if(node.val <= currRoot.val){
			currRoot.left = node;
		}else{
			currRoot.right = node;
		}
		return root;
    }
}