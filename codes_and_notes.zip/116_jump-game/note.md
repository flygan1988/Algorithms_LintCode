```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/jump-game
@Language: Markdown
@Datetime: 16-07-09 04:47
```

f[i] = true only if f[j] = true (j<i) and it can jump to position j from i;
f[0] = true;
return f[n-1];