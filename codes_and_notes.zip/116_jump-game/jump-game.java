/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/jump-game
@Language: Java
@Datetime: 16-07-09 04:47
*/

public class Solution {
    /**
     * @param A: A list of integers
     * @return: The boolean answer
     */
    public boolean canJump(int[] A) {
        // wirte your code here
        int n = A.length;
        boolean[] f = new boolean[n];
        f[0] = true;

        for(int i=1; i<n; i++){
            for(int j=0; j<i; j++){
                f[i] = f[j] && (i-j <= A[j]);
                if(f[i]){
                    break;
                }
            }
        }
        return f[n-1];
    }
}
