/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/matrix-zigzag-traversal
@Language: Java
@Datetime: 16-06-18 01:07
*/

public class Solution {
    /**
     * @param matrix: a matrix of integers
     * @return: an array of integers
     */ 
    public int[] printZMatrix(int[][] matrix) {
        // write your code here
        
        int m = matrix.length, n = matrix[0].length;
        int[] result = new int[m*n];
        int index = 0;
        for(int i=0; i<=m+n-2; i++){
            if(i % 2 == 0){
                for(int x=i; x>=0; x--){
                    if(x < m && i-x < n){
                        result[index++] = matrix[x][i-x]; 
                    }
                }
            }else{
                for(int x=0; x<=i; x++){
                    if(x < m && i-x < n){
                        result[index++] = matrix[x][i-x];
                    }
                }
            }
        }
        return result;
    }
}