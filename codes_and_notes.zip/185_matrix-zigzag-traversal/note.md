```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/matrix-zigzag-traversal
@Language: Markdown
@Datetime: 16-06-18 01:07
```

Index rule:
(0,0)
(0,1) (1,0)
(2,0) (1,1) (0,2)
(0,3) (1,2) (2,1)
(2,2) (1,3)
(2,3)