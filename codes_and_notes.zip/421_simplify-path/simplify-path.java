/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/simplify-path
@Language: Java
@Datetime: 16-06-28 03:37
*/

public class Solution {
    /**
     * @param path the original path
     * @return the simplified path
     */
    public String simplifyPath(String path) {
        // Write your code here
        String result = "/";
        String[] element = path.split("/");
        ArrayList<String> paths = new ArrayList<String>();
        for(int i=0; i<element.length; i++){
            if(element[i].equals("..")){
                if(paths.size() > 0){
                    paths.remove(paths.size()-1);
                }
            }
            else if(!element[i].equals(".") && !element[i].equals("")){
                paths.add(element[i]);
            }
        }
        for(String s:paths){
            result += s + "/";
        }
        if(result.length() > 1){
            result = result.substring(0,result.length()-1);
        }
        return result;
    }
}