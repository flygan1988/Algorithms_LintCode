# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/minimum-subarray
@Language: Python
@Datetime: 16-07-13 02:15
'''

class Solution:
    """
    @param nums: a list of integers
    @return: A integer denote the sum of minimum subarray
    """
    def minSubArray(self, nums):
        # write your code here
        Sum = 0
        maxSum = 0
        MinSum = sys.maxint
        for i in range(len(nums)):
            Sum += nums[i]
            MinSum = min(MinSum, Sum-maxSum)
            maxSum = max(maxSum, Sum)
            
        return MinSum
