# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/string-permutation
@Language: Python
@Datetime: 16-07-15 04:16
'''

class Solution:
    # @param {string} A a string
    # @param {string} B a string
    # @return {boolean} a boolean
    def stringPermutation(self, A, B):
        # Write your code here
        if len(A) != len(B):
            return False
        dic = {}
        for i in range(len(A)):
            if A[i] not in dic:
                dic[A[i]] = 1
            else:
                dic[A[i]] += 1
        for i in range(len(B)):
            if B[i] not in dic:
                return False
            if dic[B[i]] == 1:
                del dic[B[i]]
            else:
                dic[B[i]] -= 1
        return True