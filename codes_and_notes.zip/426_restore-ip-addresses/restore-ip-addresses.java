/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/restore-ip-addresses
@Language: Java
@Datetime: 16-06-30 14:42
*/

public class Solution {
    /**
     * @param s the IP string
     * @return All possible valid IP addresses
     */
    public ArrayList<String> restoreIpAddresses(String s) {
        // Write your code here
        ArrayList<String> result = new ArrayList<String>();
        ArrayList<String> list = new ArrayList<String>();
        if(s.length()<4 || s.length()>12){
            return result;
        }
        helper(s,result,list,0);
        return result;
    }
    public void helper(String s, ArrayList<String> result, ArrayList<String> list, int start){
        if(list.size() == 4){
            if(start != s.length()){
                return;
            }
            StringBuilder sb = new StringBuilder();
            for(int i=0; i<4; i++){
                sb.append(list.get(i));
                sb.append(".");
            }
            sb.deleteCharAt(sb.length()-1);
            result.add(sb.toString());
            return;
        }
        for(int i=start; i<=s.length()-1 && i<=start+3; i++){
            String tmp = s.substring(start,i+1);
            if(valid(tmp)){
                list.add(tmp);
                helper(s,result,list,i+1);
                list.remove(list.size()-1);
            }
        }
    }
    public boolean valid(String s){
        if(s.charAt(0) == '0'){
            return s.equals("0");
        }
        return Integer.valueOf(s)>=0 && Integer.valueOf(s)<=255;
    }
}