/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/space-replacement
@Language: Java
@Datetime: 16-06-20 05:35
*/

public class Solution {
    /**
     * @param string: An array of Char
     * @param length: The true length of the string
     * @return: The true length of new string
     */
    public int replaceBlank(char[] string, int length) {
        // Write your code here
        if(string == null || string.length == 0){
            return 0;
        }
        for(int i=0; i<length; i++){
            if(string[i] == ' '){
                string[i] = '%';
                for(int j=length-1; j>i; j--){
                    string[j+2] = string[j];
                }
                string[i+1] = '2';
                string[i+2] = '0';
                length += 2;
            }
        }
        return length;
    }
}