/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/permutation-index
@Language: Java
@Datetime: 16-08-18 00:48
*/

public class Solution {
    /**
     * @param A an integer array
     * @return a long integer
     */
    public long permutationIndex(int[] A) {
        // Write your code here
        if(A == null || A.length == 0){
            return 0;
        }
        int n = A.length;
        long fact = 1;
        for(int i=1; i<n; i++){
            fact *= i;
        }
        int initial = n-1;
        long res = 0;
        for(int i=0; i<n; i++){
            int count = 0;
            for(int j=i; j<n; j++){
                if(A[i] >= A[j]){
                    count++;
                }
            }
            res += (count-1)*fact;
            if(initial != 0){
                fact /= initial;
                initial--;
            }
        }
        res += 1;
        return res;
    }
}