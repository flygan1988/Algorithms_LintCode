```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/permutation-index
@Language: Markdown
@Datetime: 16-08-18 00:48
```

http://www.cnblogs.com/EdwardLiu/p/5104310.html