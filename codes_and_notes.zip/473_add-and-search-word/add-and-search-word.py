# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/add-and-search-word
@Language: Python
@Datetime: 16-07-28 00:38
'''

class TrieNode:
    
    def __init__(self, c):
        self.c = c
        self.isEnd = False
        self.children = {}

class WordDictionary:
    # initialize your data structure here.
    def __init__(self):
        # Write your code here
        self.root = TrieNode(None)
    

    # @param {string} word
    # @return {void}
    # Adds a word into the data structure.
    def addWord(self, word):
        # Write your code here
        p = self.root
        for c in word:
            if c not in p.children:
                p.children[c] = TrieNode(c)
            p = p.children[c]
        p.isEnd = True

    # @param {string} word
    # @return {boolean}
    # Returns if the word is in the data structure. A word could
    # contain the dot character '.' to represent any one letter.
    def search(self, word):
        # Write your code here
        return self.find(word, 0, self.root)
    
    def find(self, word, index, start):
        if index == len(word):
            if start.isEnd:
                return True
            return False
        if word[index] in start.children:
            return self.find(word, index+1, start.children[word[index]])
        elif word[index] == ".":
            result = False
            for key in start.children:
                if index == len(word)-1 and start.children[key].isEnd:
                    return True
                result = self.find(word, index+1, start.children[key]);
                if result: 
                    return True
            return result
        else:
            return False
                

# Your WordDictionary object will be instantiated and called as such:
# wordDictionary = WordDictionary()
# wordDictionary.addWord("word")
# wordDictionary.search("pattern")