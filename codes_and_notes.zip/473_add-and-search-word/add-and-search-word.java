/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/add-and-search-word
@Language: Java
@Datetime: 16-07-01 16:29
*/

class TrieTreeNode{
    boolean isEnd = false;
    char c;
    HashMap<Character,TrieTreeNode> hash = new HashMap<Character,TrieTreeNode>();
    TrieTreeNode(){
    }
    TrieTreeNode(char c){
        this.c = c;
    }
}

public class WordDictionary {
    TrieTreeNode root = new TrieTreeNode();
    // Adds a word into the data structure.
    public void addWord(String word) {
        // Write your code here
        TrieTreeNode cur = root;
        for(int i=0; i<word.length(); i++){
            char c = word.charAt(i);
            if(!cur.hash.containsKey(c)){
                cur.hash.put(c,new TrieTreeNode(c));
            }
            cur = cur.hash.get(c);
        }
        cur.isEnd = true;
    }

    // Returns if the word is in the data structure. A word could
    // contain the dot character '.' to represent any one letter.
    public boolean search(String word) {
        // Write your code here
        return find(word,0,root);
    }
    public boolean find(String word, int index, TrieTreeNode start){
        if(index == word.length()){
            if(start.isEnd){
                return true;
            }
            return false;
        }
        char c = word.charAt(index);
        if(start.hash.containsKey(c)){
            return find(word,index+1,start.hash.get(c));
        }
        else if(c == '.'){
            boolean result = false;
            for(Map.Entry<Character,TrieTreeNode> child:start.hash.entrySet()){
                if(index == word.length()-1 && child.getValue().isEnd){
                    return true;
                }
                if(find(word,index+1,child.getValue())){
                    result = true;
                }
            }
            return result;
        }
        else{
            return false;
        }
    }
}

// Your WordDictionary object will be instantiated and called as such:
// WordDictionary wordDictionary = new WordDictionary();
// wordDictionary.addWord("word");
// wordDictionary.search("pattern");