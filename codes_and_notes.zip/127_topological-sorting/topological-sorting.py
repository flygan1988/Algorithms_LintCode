# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/topological-sorting
@Language: Python
@Datetime: 16-07-15 01:50
'''

# Definition for a Directed graph node
# class DirectedGraphNode:
#     def __init__(self, x):
#         self.label = x
#         self.neighbors = []

class Solution:
    """
    @param graph: A list of Directed graph node
    @return: A list of graph nodes in topological order.
    """
    def topSort(self, graph):
        # write your code here
        ans = []
        if not graph or len(graph) == 0:
            return ans
        dic = {}
        queue = []
        for node in graph:
            dic[node] = 0
        for node in graph:
            for neighbor in node.neighbors:
                dic[neighbor] += 1
        for node in graph:
            if dic[node] == 0:
                #ans.append(node)
                queue.insert(0,node)
        while len(queue) != 0:
            now = queue.pop()
            ans.append(now)
            for node in now.neighbors:
                dic[node] -= 1
                if dic[node] == 0:
                    queue.insert(0,node)
                    
        return ans