/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/topological-sorting
@Language: Java
@Datetime: 16-08-13 18:03
*/

/**
 * Definition for Directed graph.
 * class DirectedGraphNode {
 *     int label;
 *     ArrayList<DirectedGraphNode> neighbors;
 *     DirectedGraphNode(int x) { label = x; neighbors = new ArrayList<DirectedGraphNode>(); }
 * };
 */
public class Solution {
    /**
     * @param graph: A list of Directed graph node
     * @return: Any topological order for the given graph.
     */    
    public ArrayList<DirectedGraphNode> topSort(ArrayList<DirectedGraphNode> graph) {
        // write your code here
        ArrayList<DirectedGraphNode> result = new ArrayList<DirectedGraphNode>();
        HashMap<DirectedGraphNode,Integer> map = new HashMap<DirectedGraphNode,Integer>();
        //find all the nodes which have entrance, use a hash map to record the number of entrances of each node.
        for(DirectedGraphNode node:graph){
            for(DirectedGraphNode neighbor:node.neighbors){
                if(map.containsKey(neighbor)){
                    map.put(neighbor,map.get(neighbor)+1);
                }
                else{
                    map.put(neighbor,1);
                }
            }
        }
        //find the nodes which have no entrance and put them in the queue and the result set
        Queue<DirectedGraphNode> queue = new LinkedList<DirectedGraphNode>();
        for(DirectedGraphNode n:graph){
            if(!map.containsKey(n)){
                queue.offer(n);
                //result.add(n);
            }
        }
        //traverse the queue and put all the nodes whose number of entrances is equal to 0
        while(!queue.isEmpty()){
            DirectedGraphNode temp = queue.poll();
            for(DirectedGraphNode i:temp.neighbors){
                map.put(i,map.get(i)-1);
                if(map.get(i) == 0){
                    queue.offer(i);
                }
            }
            result.add(temp);
        }
        return result;
    }
}