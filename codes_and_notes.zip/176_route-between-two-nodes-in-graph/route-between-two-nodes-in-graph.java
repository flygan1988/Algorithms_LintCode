/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/route-between-two-nodes-in-graph
@Language: Java
@Datetime: 16-06-29 05:54
*/

/**
 * Definition for Directed graph.
 * class DirectedGraphNode {
 *     int label;
 *     ArrayList<DirectedGraphNode> neighbors;
 *     DirectedGraphNode(int x) {
 *         label = x;
 *         neighbors = new ArrayList<DirectedGraphNode>();
 *     }
 * };
 */
public class Solution {
   /**
     * @param graph: A list of Directed graph node
     * @param s: the starting Directed graph node
     * @param t: the terminal Directed graph node
     * @return: a boolean value
     */
    public boolean hasRoute(ArrayList<DirectedGraphNode> graph, 
                            DirectedGraphNode s, DirectedGraphNode t) {
        // write your code here
        HashSet<DirectedGraphNode> visited = new HashSet<DirectedGraphNode>();
        return dfs(graph,s,t,visited);
    }
    public boolean dfs(ArrayList<DirectedGraphNode> graph, DirectedGraphNode s, DirectedGraphNode t, HashSet<DirectedGraphNode> visited){
        if(s == t){
            return true;
        }
        visited.add(s);
        for(DirectedGraphNode node:s.neighbors){
            if(visited.contains(node)){
                continue;
            }
            if(dfs(graph,node,t,visited)){
                return true;
            }
        }
        return false;
    }
}