/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/implement-queue-by-linked-list-ii
@Language: Java
@Datetime: 16-06-14 05:21
*/

class ListNode{
    int val;
    ListNode pre;
    ListNode next;
    public ListNode(int val){
        this.val = val;
        this.pre = null;
        this.next = null;
    }
} 
public class Dequeue {
    ListNode dummy;
    ListNode curr;
    public Dequeue() {
        // do initialize if necessary
        dummy = new ListNode(-1);
        curr = dummy;
    }

    public void push_front(int item) {
        // Write your code here
        ListNode node = new ListNode(item);
        node.next = dummy.next;
        node.pre = dummy;
        dummy.next = node;
        if(node.next != null){
            node.next.pre = node; 
        }else{
            curr = node;
        }
    }

    public void push_back(int item) {
        // Write your code here
        ListNode node = new ListNode(item);
        curr.next = node;
        node.pre = curr;
        curr = node;
    }

    public int pop_front() {
        // Write your code here
        ListNode node = dummy.next;
        dummy.next = node.next;
        if(dummy.next == null){
            curr = dummy;
        }else{
            dummy.next.pre = dummy;
        } 
        return node.val;
    }

    public int pop_back() {
        // Write your code here
        ListNode node = curr;
        node.pre.next = null;
        curr = node.pre;
        return node.val;
    }
}