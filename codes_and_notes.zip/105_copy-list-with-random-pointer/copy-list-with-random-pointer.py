# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/copy-list-with-random-pointer
@Language: Python
@Datetime: 16-07-10 03:35
'''

# Definition for singly-linked list with a random pointer.
# class RandomListNode:
#     def __init__(self, x):
#         self.label = x
#         self.next = None
#         self.random = None
class Solution:
    # @param head: A RandomListNode
    # @return: A RandomListNode
    def copyRandomList(self, head):
        # write your code here
        if not head:
            return head
        dic = {}
        dummy = RandomListNode(0)
        pre = dummy
        while head:
            if head in dic:
                newNode = dic[head]
            else:
                newNode = RandomListNode(head.label)
                dic[head] = newNode
            pre.next = newNode
            if head.random:
                if head.random in dic:
                    newNode.random = dic[head.random]
                else:
                    newNode.random = RandomListNode(head.random.label)
                    dic[head.random] = newNode.random
            head = head.next
            pre = pre.next
        return dummy.next