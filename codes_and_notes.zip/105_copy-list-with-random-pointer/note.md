```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/copy-list-with-random-pointer
@Language: Markdown
@Datetime: 16-07-10 03:35
```

use hash map <RandomListNode RandomListNode>, key is the original node, value is new instance copied from the original node.