# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/sqrtx
@Language: Python
@Datetime: 16-08-17 20:27
'''

class Solution:
    """
    @param x: An integer
    @return: The sqrt of x
    """
    def sqrt(self, x):
        # write your code here
        left = 1
        right = x
        while left < right-1:
            mid = (left+right)/2
            if mid*mid == x:
                return mid
            elif mid*mid < x:
                left = mid
            else:
                right = mid
        if right*right > x:
            return left
        return right