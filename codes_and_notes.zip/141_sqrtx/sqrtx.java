/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/sqrtx
@Language: Java
@Datetime: 16-06-20 05:54
*/

class Solution {
    /**
     * @param x: An integer
     * @return: The sqrt of x
     */
    public int sqrt(int x) {
        // write your code here
        if(x == 1){
            return 1;
        }
        long left = 1;
        long right = x/2;
        while(left < right-1){
            long mid = left + (right - left) / 2;
            if(mid*mid <= x){
                left = mid;
            }else{
                right = mid;
            }
        }
        if(left*left <= x && right * right > x){
            return (int)left;
        }
        return (int)right;
    }
}