# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/edit-distance
@Language: Python
@Datetime: 16-07-09 16:30
'''

class Solution: 
    # @param word1 & word2: Two string.
    # @return: The minimum number of steps.
    def minDistance(self, word1, word2):
        # write your code here
        
        m = len(word1)
        n = len(word2)
        
        f = [[0 for i in range(0,n+1)] for j in range(0,m+1)]
        
        for i in range(1,n+1):
            f[0][i] = i
        for i in range(1,m+1):
            f[i][0] = i
            
        for i in range(1,m+1):
            for j in range(1,n+1):
                if word1[i-1] == word2[j-1]:
                    f[i][j] = f[i-1][j-1]
                else:
                    f[i][j] = min(min(f[i][j-1],f[i-1][j-1]),f[i-1][j])+1
        return f[m][n]
        