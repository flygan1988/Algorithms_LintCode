/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/powx-n
@Language: Java
@Datetime: 16-06-21 19:17
*/

public class Solution {
    /**
     * @param x the base number
     * @param n the power number
     * @return the result
     */
    /**
    public double myPow(double x, int n) {
        // Write your code here
        if(n == 0){
            return 1.0;
        }
        else if(n > 0){
            if(n % 2 == 0){
                return myPow(x,n/2) * myPow(x,n/2);
            }
            else{
                return x * myPow(x,n/2) * myPow(x,n/2);
            }
        }
        else{
            return 1.0 / myPow(x,-n);
        }
    }*/
    public double myPow(double x, int n) {
        // Write your code here
        if(n == 0){
            return 1.0;
        }
        else if(n > 0){
            return x * myPow(x,n-1);
        }
        else{
            return 1.0 / myPow(x,-n);
        }
    }
}