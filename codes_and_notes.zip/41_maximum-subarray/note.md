```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/maximum-subarray
@Language: Markdown
@Datetime: 16-08-12 04:13
```

compute the sum of the first n(n<=nums.length) numbers.
find the minSum in nums. 
then sum-minSum is max sum of the subarray.