# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/maximum-subarray
@Language: Python
@Datetime: 16-08-08 01:04
'''

class Solution:
    """
    @param nums: A list of integers
    @return: An integer denote the sum of maximum subarray
    """
    def maxSubArray(self, nums):
        # write your code here
        Sum = 0
        minSum = 0
        maxSum = -sys.maxint
        for i in range(len(nums)):
            Sum += nums[i]
            maxSum = max(maxSum,Sum-minSum)
            minSum = min(minSum,Sum)
        return maxSum