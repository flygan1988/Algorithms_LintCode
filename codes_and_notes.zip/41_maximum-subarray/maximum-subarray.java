/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/maximum-subarray
@Language: Java
@Datetime: 16-08-12 04:13
*/

public class Solution {
    /**
     * @param nums: A list of integers
     * @return: A integer indicate the sum of max subarray
     */
    /***
    private int findMin(int[] A, int start, int end){
        if(start == end){
            return A[start];
        }
        int min = Integer.MAX_VALUE;
        for(int i=start; i<end; i++){
            if(A[i] < min){
                min = A[i];
            }
        }
        return min;
    }
    public int maxSubArray(int[] nums) {
        // write your code
        int[] preSum = new int[nums.length+1];
        int max = Integer.MIN_VALUE;
        for(int i=0; i<nums.length; i++){
            preSum[i+1] = nums[i] + preSum[i];
        }
        for(int j=1; j<preSum.length; j++){
            if((preSum[j] - findMin(preSum,0,j)) > max){
                max = preSum[j] - findMin(preSum,0,j);
            } 
        }
        return max;
    }
}**/
/**Solution 2:
    public int maxSubArray(int[] nums) {
        int max = Integer.MIN_VALUE;
        int sum = 0, minSum = 0;
        for(int i=0; i<nums.length; i++){
            sum += nums[i];
            max = Math.max(max,sum-minSum);
            minSum = Math.min(minSum,sum);
        }
        return max;
    }
**/
//Solution 3: Dynamic Programming
    public int maxSubArray(int[] nums) {
        int n = nums.length;
        int[] local = new int[n];
        int[] global = new int[n];
        local[0] = nums[0];
        global[0] = nums[0];
        for(int i=1; i<n; i++){
            local[i] = Math.max(local[i-1]+nums[i],nums[i]);
            global[i] = Math.max(global[i-1],local[i]);
        }
        return global[n-1];
    }
}