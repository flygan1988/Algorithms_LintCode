/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/sort-integers-ii
@Language: Java
@Datetime: 16-06-20 05:10
*/

public class Solution {
    /**
     * @param A an integer array
     * @return void
     */
    public void sortIntegers2(int[] A) {
        // Write your code here
        helper(A,0,A.length-1);
    }
    public void helper(int[] A, int start, int end){
        if(start > end) return;
        int index = partition(A,start,end);
        helper(A,start,index-1);
        helper(A,index+1,end);
    }
    public int partition(int[] A, int start, int end){
        int left = start, right = end;
        int pivot = A[start];
        while(left < right){
            while(A[right] >= pivot && left < right){
                right--;
            }
            A[left] = A[right];
            while(A[left] <= pivot && left < right){
                left++;
            }
            A[right] = A[left];
        }
        A[left] = pivot;
        return left;
    }
}