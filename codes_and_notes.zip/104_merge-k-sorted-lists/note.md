```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/merge-k-sorted-lists
@Language: Markdown
@Datetime: 16-07-10 06:28
```

Divide and Conque
