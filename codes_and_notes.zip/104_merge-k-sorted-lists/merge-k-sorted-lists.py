# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/merge-k-sorted-lists
@Language: Python
@Datetime: 16-07-10 06:28
'''

"""
Definition of ListNode
class ListNode(object):

    def __init__(self, val, next=None):
        self.val = val
        self.next = next
"""
class Solution:
    """
    @param lists: a list of ListNode
    @return: The head of one sorted list.
    """
    def mergeKLists(self, lists):
        # write your code here
        if not lists:
            return None
        return self.mergeHelper(lists,0,len(lists)-1)
        
    def mergeTwoList(self, head1, head2):
        dummy = ListNode(0)
        pre = dummy
        while head1 and head2:
            if head1.val < head2.val:
                pre.next = head1
                head1 = head1.next
            else:
                pre.next = head2
                head2 = head2.next
            pre = pre.next
        if not head1:
            pre.next = head2
        if not head2:
            pre.next = head1
        return dummy.next
        
    def mergeHelper(self, lists, start, end):
        if start == end:
            return lists[start]
        mid = (start + end) / 2
        left = self.mergeHelper(lists,start,mid)
        right = self.mergeHelper(lists,mid+1,end)
        return self.mergeTwoList(left,right)
