/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/merge-k-sorted-lists
@Language: Java
@Datetime: 16-03-29 04:52
*/

/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 */ 
public class Solution {
    /**
     * @param lists: a list of ListNode
     * @return: The head of one sorted list.
     */
    private ListNode mergeTwoLists(ListNode head1, ListNode head2){
        ListNode dummy = new ListNode(0);
        ListNode newHead = dummy;
        while(head1 != null && head2 != null){
            if(head1.val < head2.val){
                newHead.next = head1;
                head1 = head1.next;
            }else{
                newHead.next = head2;
                head2 = head2.next;
            }
            newHead = newHead.next;
        }
        if(head1 == null){
            newHead.next = head2;
        }else{
            newHead.next = head1;
        }
        return dummy.next;
    }
    private ListNode mergeHelper(List<ListNode> lists, int start, int end){
        if(start == end){
            return lists.get(start);
        }
        int mid = start + (end - start) / 2;
        ListNode L1 = mergeHelper(lists,start,mid);
        ListNode L2 = mergeHelper(lists,mid+1,end);
        return mergeTwoLists(L1,L2);
    }
    public ListNode mergeKLists(List<ListNode> lists) {  
        // write your code here
        if(lists.size() == 0){
            return null;
        }
        return mergeHelper(lists,0,lists.size()-1);
    }
}
