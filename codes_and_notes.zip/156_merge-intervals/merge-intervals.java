/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/merge-intervals
@Language: Java
@Datetime: 16-06-18 01:27
*/

/**
 * Definition of Interval:
 * public class Interval {
 *     int start, end;
 *     Interval(int start, int end) {
 *         this.start = start;
 *         this.end = end;
 *     }
 */

class Solution {
    /**
     * @param intervals, a collection of intervals
     * @return: A new sorted interval list.
     */
    public List<Interval> merge(List<Interval> intervals) {
        // write your code here
        List<Interval> res = new ArrayList<>();
        if(intervals == null || intervals.size() == 0){
            return res;
        }
        Collections.sort(intervals,new Comparator<Interval>(){
            public int compare(Interval i1, Interval i2){
                if(i1.start != i2.start){
                    return i1.start - i2.start;
                }else{
                    return i1.end - i2.end;
                }
            }
        });
        Interval tmp = intervals.get(0);
        for(int i=1; i<intervals.size(); i++){
            if(tmp.end < intervals.get(i).start){
                res.add(tmp);
                tmp = intervals.get(i);
            }else{
                tmp = new Interval(tmp.start,Math.max(tmp.end,intervals.get(i).end));
            }
        }
        res.add(tmp);
        return res;
    }

}