/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/triangle-count
@Language: Java
@Datetime: 16-07-15 18:49
*/

public class Solution {
    /**
     * @param S: A list of integers
     * @return: An integer
     */
    public int triangleCount(int S[]) {
        // write your code here
        if(S == null || S.length < 3){
            return 0;
        }
        Arrays.sort(S);
        int ans = 0;
        int left = 0;
        int right = S.length-1;
        while(right > 1){
            while(left < right-1){
                int tmp = left + 1;
                while(tmp < right){
                    if(S[left]+S[tmp]>S[right]){
                        ans++;
                    }
                    tmp++;
                }
                left++;
            }
            right--;
            left = 0;
        }
        return ans;
    }
}
