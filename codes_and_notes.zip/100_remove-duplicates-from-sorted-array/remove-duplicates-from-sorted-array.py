# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/remove-duplicates-from-sorted-array
@Language: Python
@Datetime: 16-08-17 22:21
'''

class Solution:
    """
    @param A: a list of integers
    @return an integer
    """
    def removeDuplicates(self, A):
        # write your code here
        i = 0
        j = 1
        while j < len(A):
            if A[i] == A[j]:
                j += 1
            else:
                i += 1
                A[i] = A[j]
                j += 1
        return i+1
          