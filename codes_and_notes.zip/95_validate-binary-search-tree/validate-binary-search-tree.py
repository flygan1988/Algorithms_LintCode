# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/validate-binary-search-tree
@Language: Python
@Datetime: 16-07-08 21:50
'''

"""
Definition of TreeNode:
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left, self.right = None, None
"""
class Solution:
    """
    @param root: The root of binary tree.
    @return: True if the binary tree is BST, or false
    """  
    def isValidBST(self, root):
        # write your code here
        if root is None:
            return True
        if root.left is not None and self.findMax(root.left).val >= root.val:
            return False
        if root.right is not None and self.findMin(root.right).val <= root.val:
            return False
        return self.isValidBST(root.left) and self.isValidBST(root.right)
    
    def findMin(self, root):
        if root.left is None:
            return root
        return self.findMin(root.left)
        
    def findMax(self, root):
        if root.right is None:
            return root
        return self.findMax(root.right)