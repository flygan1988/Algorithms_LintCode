# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/count-and-say
@Language: Python
@Datetime: 16-08-18 15:24
'''

class Solution:
    # @param {int} n the nth
    # @return {string} the nth sequence
    def countAndSay(self, n):
        # Write your code here
        oldstr = "1"
        while n > 1:
            tmp = ""
            i = 0
            while i < len(oldstr):
                count = 1
                j = i+1
                while j < len(oldstr) and oldstr[j] == oldstr[i]:
                    count += 1
                    j += 1
                tmp += (str(count)+oldstr[i])
                i = j
            oldstr = tmp
            n -= 1
        return oldstr