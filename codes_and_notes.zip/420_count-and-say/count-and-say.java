/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/count-and-say
@Language: Java
@Datetime: 16-06-17 05:45
*/

public class Solution {
    /**
     * @param n the nth
     * @return the nth sequence
     */
    public String countAndSay(int n) {
        // Write your code here
        String oldString = "1";
        while(--n > 0){
            char[] oldArray = oldString.toCharArray();
            StringBuilder sb = new StringBuilder();
            for(int i=0; i<oldArray.length; i++){
                int count = 1;
                while(i+1 < oldArray.length && oldArray[i] == oldArray[i+1]){
                    count++;
                    i++;
                }
                sb.append(String.valueOf(count)+String.valueOf(oldArray[i]));
            }
            oldString = sb.toString();
        }
        return oldString;
    }
}