/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/cosine-similarity
@Language: Java
@Datetime: 16-06-12 20:15
*/

class Solution {
    /**
     * @param A: An integer array.
     * @param B: An integer array.
     * @return: Cosine similarity.
     */
    public double cosineSimilarity(int[] A, int[] B) {
        // write your code here
        if(A == null || A.length == 0){
            return 2.0000;
        }
        int ab = 0, a = 0, b = 0;
        for(int i=0; i<A.length; i++){
            ab += A[i]*B[i];
            a += A[i]*A[i];
            b += B[i]*B[i];
        }
        if(a==0 || b==0){
            return 2.0000;
        }
        double _a = Math.sqrt(a);
        double _b = Math.sqrt(b);
        return ab / (_a*_b); 
    }
}
