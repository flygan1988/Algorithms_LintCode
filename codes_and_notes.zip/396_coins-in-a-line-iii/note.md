```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/coins-in-a-line-iii
@Language: Markdown
@Datetime: 16-08-10 22:34
```

State

dp[i][j] represent the max value it can get from i to j
sum[i][j] represent the sum value from i to j
Function

Each time when taken coins, we have two choice:
takes values[i]
takes values[j]
dp[i][j] = Math.max(values[i]+(sum[j+1]-sum[i])-dp[i+1][j],values[j]+(sum[j+1]-sum[i])-dp[i][j-1]);

Since values[i]+sum[i+1][j] or values[j]+sum[i][j-1] equals to sum[i][j]
So the equation can be 