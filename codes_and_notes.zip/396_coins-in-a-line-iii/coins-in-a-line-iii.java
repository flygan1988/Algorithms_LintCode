/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/coins-in-a-line-iii
@Language: Java
@Datetime: 16-07-07 15:24
*/

public class Solution {
    /**
     * @param values: an array of integers
     * @return: a boolean which equals to true if the first player will win
     */
    public boolean firstWillWin(int[] values) {
        // write your code here
        if(values.length < 2) return true;
        
        int n = values.length;
        int[][] dp = new int[n][n];
        int[] sum = new int[n+1];
        for(int i=0; i<n; i++){
            //dp[i][i] = values[i];
            sum[i+1] = sum[i] + values[i];
        }
        for(int i=n-1; i>=0; i--){
            for(int j=i; j<n; j++){
                if(i == j){
                    dp[i][j] = values[i];
                }else{
                    dp[i][j] = Math.max(values[i]+(sum[j+1]-sum[i])-dp[i+1][j],values[j]+(sum[j+1]-sum[i])-dp[i][j-1]);
                }
            }
        }
        if(dp[0][n-1] > sum[n]/2){
            return true;
        }
        return false;
    }
}