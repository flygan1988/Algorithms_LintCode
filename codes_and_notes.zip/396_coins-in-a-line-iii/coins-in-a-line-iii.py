# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/coins-in-a-line-iii
@Language: Python
@Datetime: 16-08-10 22:34
'''

class Solution:
    # @param values: a list of integers
    # @return: a boolean which equals to True if the first player will win
    def firstWillWin(self, values):
        # write your code here
        n = len(values)
        if n <= 1:
            return True
        sums = [0 for i in range(n+1)]
        dp = [[0 for i in range(n)] for j in range(n)]
        for i in range(n):
            dp[i][i] = values[i]
            sums[i+1] = sums[i] + values[i]
        for i in range(n-1,-1,-1):
            for j in range(i+1,n):
                dp[i][j] = max(values[i]+sums[j+1]-sums[i]-dp[i+1][j],values[j]+sums[j+1]-sums[i]-dp[i][j-1])
        if dp[0][n-1] > sums[n] / 2:
            return True
        return False
