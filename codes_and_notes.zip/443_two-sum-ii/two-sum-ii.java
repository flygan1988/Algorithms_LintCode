/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/two-sum-ii
@Language: Java
@Datetime: 16-05-19 04:09
*/

public class Solution {
    /**
     * @param nums: an array of integer
     * @param target: an integer
     * @return: an integer
     */
    public int twoSum2(int[] nums, int target) {
        // Write your code here
        if(nums == null || nums.length < 2){
            return 0;
        }
        int left = 0;
        int right = nums.length-1;
        int ans = 0;
        Arrays.sort(nums);
        while(left<right){
            if(nums[left]+nums[right]<=target){
                left++;
            }
            else{
                ans += right-left;
                right--;
            }
        }
        return ans;
    }
}