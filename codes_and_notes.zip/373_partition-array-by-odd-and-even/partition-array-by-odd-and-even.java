/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/partition-array-by-odd-and-even
@Language: Java
@Datetime: 16-06-18 03:38
*/

public class Solution {
    /**
     * @param nums: an array of integers
     * @return: nothing
     */
    public void partitionArray(int[] nums) {
        // write your code here;
        if(nums == null || nums.length == 0){
            return;
        }
        int left = 0, right = nums.length-1;
        while(left < right){
            while(left < right && nums[left] % 2 != 0){
                left++;
            }
            while(left < right && nums[right] % 2 == 0){
                right--;
            }
            swap(nums,left,right);
        }
    }
    private void swap(int[] nums, int i, int j){
        int tmp = nums[i];
        nums[i] = nums[j];
        nums[j] = tmp;
    }
}