# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/partition-array-by-odd-and-even
@Language: Python
@Datetime: 16-08-18 01:16
'''

class Solution:
    # @param nums: a list of integers
    # @return: nothing
    def partitionArray(self, nums):
        # write your code here
        left = 0
        right = len(nums)-1
        while left < right:
            while left < right and nums[left] % 2 == 1:
                left += 1
            while left < right and nums[right] % 2 == 0:
                right -= 1
            tmp = nums[left]
            nums[left] = nums[right]
            nums[right] = tmp
        
