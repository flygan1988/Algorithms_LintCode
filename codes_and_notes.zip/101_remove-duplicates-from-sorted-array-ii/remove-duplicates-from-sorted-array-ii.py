# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/remove-duplicates-from-sorted-array-ii
@Language: Python
@Datetime: 16-08-17 22:33
'''

class Solution:
    """
    @param A: a list of integers
    @return an integer
    """
    def removeDuplicates(self, A):
        # write your code here
        if not A or len(A) == 0:
            return 0
        end = 1
        for j in range(2,len(A)):
            if A[end-1] != A[j]:
                end += 1
                A[end] = A[j]
        return end + 1
        
          