/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/rehashing
@Language: Java
@Datetime: 16-06-03 04:15
*/

/**
 * Definition for ListNode
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) {
 *         val = x;
 *         next = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @param hashTable: A list of The first node of linked list
     * @return: A list of The first node of linked list which have twice size
     */    
    public ListNode[] rehashing(ListNode[] hashTable) {
        // write your code here
        int size = hashTable.length;
        int len = 2*size;
        ListNode[] newHash = new ListNode[len];
        for(int i=0; i<size; i++){
            if(hashTable[i] != null){
                ListNode node = hashTable[i];
                while(node != null){
                    int value = node.val;
                    int pos = 0;
                    if(value<0){
                        pos = (value%len+len)%len;
                    }else{
                        pos = value%len;
                    }
                    //newHash[pos] == null?newHash[pos]=new ListNode(value):newHash[pos].next=new ListNode(value);
                    if(newHash[pos] == null){
                        newHash[pos] = new ListNode(value);
                    }else{
                        ListNode tmp = newHash[pos];
                        while(tmp.next != null){
                            tmp = tmp.next;
                        }
                        tmp.next = new ListNode(value);
                    }
                    node = node.next;
                }
            }
        }
        return newHash;
    }
};
