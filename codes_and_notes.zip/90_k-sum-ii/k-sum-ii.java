/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/k-sum-ii
@Language: Java
@Datetime: 16-06-21 20:04
*/

public class Solution {
    /**
     * @param A: an integer array.
     * @param k: a positive integer (k <= length(A))
     * @param target: a integer
     * @return a list of lists of integer 
     */ 
    public ArrayList<ArrayList<Integer>> kSumII(int[] A, int k, int target) {
        // write your code here
        ArrayList<ArrayList<Integer>> res = new ArrayList<ArrayList<Integer>>();
        ArrayList<Integer> list = new ArrayList<Integer>();
        search(A,res,list,0,k,target);
        return res;
    }
    private boolean listSum(ArrayList<Integer> list, int target){
        int sum = 0;
        for(int i=0; i<list.size(); i++){
            sum += list.get(i);
        }
        if(sum == target){
            return true;
        }
        return false;
    }
    private void search(int[] A, ArrayList<ArrayList<Integer>> res, ArrayList<Integer> list, int pos, int k, int target){
        if(list.size() == k){
            if(listSum(list,target)){
                res.add(new ArrayList<Integer>(list));
            }
            return;
        }
        for(int i=pos; i<A.length; i++){
            list.add(A[i]);
            search(A,res,list,i+1,k,target);
            list.remove(list.size()-1);
        }
    }
}