# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/search-in-a-big-sorted-array
@Language: Python
@Datetime: 16-07-08 01:05
'''

"""
Definition of ArrayReader:
class ArrayReader:
    def get(self, index):
        # this would return the number on the given index
        # return -1 if index is less than zero.
"""
class Solution:
    # @param {ArrayReader} reader: An instance of ArrayReader 
    # @param {int} target an integer
    # @return {int} an integer
    def searchBigSortedArray(self, reader, target):
        # write your code here
        left = 0
        right = target
        while left < right-1:
            mid = left + (right-left)/2
            if reader.get(mid) >= target:
                right = mid
            else:
                left = mid
                right += target
        if reader.get(left) == target:
            return left
        if reader.get(right) == target:
            return right
        return -1