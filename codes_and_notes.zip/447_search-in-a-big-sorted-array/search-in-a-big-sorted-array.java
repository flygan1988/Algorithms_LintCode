/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/search-in-a-big-sorted-array
@Language: Java
@Datetime: 16-05-27 03:26
*/

/**
 * Definition of ArrayReader:
 * 
 * class ArrayReader {
 *      // get the number at index, return -1 if index is less than zero.
 *      public int get(int index);
 * }
 */
public class Solution {
    /**
     * @param reader: An instance of ArrayReader.
     * @param target: An integer
     * @return : An integer which is the index of the target number
     */
    public int searchBigSortedArray(ArrayReader reader, int target) {
        // write your code here
        int left=0, right=target;
        while(left<right-1){
            int mid = left+(right-left)/2;
            if(reader.get(mid)>=target){
                right = mid;
            }else{
                left = mid;
                right += target;
            }
        }
        if(reader.get(left)==target){
            return left;
        }
        if(reader.get(right)==target){
            return right;
        }
        return -1;
    }
}