/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/binary-representation
@Language: Java
@Datetime: 16-07-04 19:56
*/

public class Solution {
    /**
     *@param n: Given a decimal number that is passed in as a string
     *@return: A string
     */
    public String binaryRepresentation(String n) {
        // write your code here
        if(n.indexOf('.') == -1){
            return parseInteger(n);
        }
        String[] str = n.split("\\.");
        String floatPart = parseFloat(str[1]);
        if(floatPart.equals("ERROR")){
            return "ERROR";
        }
        if(floatPart.equals("")){
            return parseInteger(str[0]);
        }
        return parseInteger(str[0])+"."+floatPart;
        
    }
    public String parseInteger(String s){
        String result = "";
        int n = Integer.parseInt(s);
        if(s.equals("0") || s.equals("")){
            return "0";
        }
        while(n != 0){
            result = Integer.toString(n%2) + result;
            n /= 2;
        }
        return result;
    }
    public String parseFloat(String s){
        HashSet<Double> set = new HashSet<Double>();
        double d = Double.parseDouble("0." + s);
        String result = "";
        while(d > 0){
            if(result.length() > 32 || set.contains(d)){
                return "ERROR";
            }
            set.add(d);
            d = d * 2;
            if(d >= 1){
                d -= 1;
                result = result + "1";
            }else{
                result = result + "0";
            }
        }
        return result;
    }
}