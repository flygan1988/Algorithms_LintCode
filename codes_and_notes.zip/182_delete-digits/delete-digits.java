/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/delete-digits
@Language: Java
@Datetime: 16-07-05 01:59
*/

public class Solution {
    /**
     *@param A: A positive integer which has N digits, A is a string.
     *@param k: Remove k digits.
     *@return: A string
     */
    public String DeleteDigits(String A, int k) {
        // write your code here
        Stack<Character> stack = new Stack<Character>();
        StringBuffer result = new StringBuffer();
        if(A == null || A.length() == 0 || A.length() < k){
            return "";
        }
        int len = A.length();
        for(int i=0; i<len; i++){
            char c = A.charAt(i);
            while(!stack.isEmpty() && len-i-1>=len-k-stack.size() && c<stack.peek()){
                stack.pop();
            }
            if(stack.size() < len-k){
                stack.push(c);
            }
        }
        while(!stack.isEmpty()){
            result.insert(0,stack.pop());
        }
        while(result.length() > 0 && result.charAt(0) == '0'){
            result.deleteCharAt(0);
        }
        return result.toString();
    }
}