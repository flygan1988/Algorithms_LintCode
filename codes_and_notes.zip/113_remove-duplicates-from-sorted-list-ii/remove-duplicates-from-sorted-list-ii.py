# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/remove-duplicates-from-sorted-list-ii
@Language: Python
@Datetime: 16-07-10 02:17
'''

"""
Definition of ListNode
class ListNode(object):

    def __init__(self, val, next=None):
        self.val = val
        self.next = next
"""
class Solution:
    """
    @param head: A ListNode
    @return: A ListNode
    """
    def deleteDuplicates(self, head):
        # write your code here
        if not head or not head.next:
            return head
        dummy = ListNode(0)
        dummy.next = head
        pre = dummy
        
        while head.next is not None:
            while head.next is not None and head.val != head.next.val:
                pre = head
                head = head.next
            if head.next is None:
                return dummy.next
            while head.next is not None and head.val == head.next.val:
                head = head.next
            pre.next = head.next
            if pre.next is None:
                return dummy.next
            if pre.next.next is not None and pre.next.val != pre.next.next.val:
                pre = pre.next
            head = pre.next
        return dummy.next