/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/hash-function
@Language: Java
@Datetime: 16-06-01 04:19
*/

class Solution {
    /**
     * @param key: A String you should hash
     * @param HASH_SIZE: An integer
     * @return an integer
     */
    public int hashCode(char[] key,int HASH_SIZE) {
        // write your code here
        int len = key.length;
        long sum = 0;
        for(int i=0; i<len; i++){
            sum = 33*sum + key[i];
            sum = sum % HASH_SIZE;
        }
        return (int)sum;
    }
};