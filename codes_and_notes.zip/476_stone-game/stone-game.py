# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/stone-game
@Language: Python
@Datetime: 16-08-10 15:20
'''

class Solution:
    # @param {int[]} A an integer array
    # @return {int} an integer
    def stoneGame(self, A):
        # Write your code here
        n = len(A)
        if n == 0:
            return 0
        sums = [0 for i in range(n+1)]
        dp = [[sys.maxint for i in range(n)] for j in range(n)]
        for i in range(n):
            dp[i][i] = 0
            sums[i+1] = sums[i] + A[i]
        return self.search(0,n-1,dp,sums)
    
    def search(self, start, end, dp, sums):
        if dp[start][end] != sys.maxint:
            return dp[start][end]
        minValue = sys.maxint
        for i in range(start,end):
            left = self.search(start, i, dp, sums)
            right = self.search(i+1, end, dp, sums)
            Sum = sums[end+1] - sums[start]
            minValue = min(minValue, left+right+Sum)
        dp[start][end] = minValue
        return dp[start][end]
                