```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/stone-game
@Language: Markdown
@Datetime: 16-08-10 15:20
```

http://chuansong.me/n/1987334