/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/stone-game
@Language: Java
@Datetime: 16-07-07 03:07
*/

public class Solution {
    /**
     * @param A an integer array
     * @return an integer
     */
    public int stoneGame(int[] A) {
        // Write your code here
        if(A == null || A.length == 0){
            return 0;
        }
        int n = A.length;
        int[][] dp = new int[n][n];
        int[] sum = new int[n+1];
        for(int i=0; i<n; i++){
            for(int j=i; j<n; j++){
                dp[i][j] = Integer.MAX_VALUE;
            }
        }
        for(int i=0; i<n; i++){
            dp[i][i] = 0;
            sum[i+1] = sum[i] + A[i];
        }
        
        return search(A,0,n-1,dp,sum);
    }
    public int search(int[] A, int start, int end, int[][] dp, int[] sum){
        if(dp[start][end] != Integer.MAX_VALUE){
            return dp[start][end];
        }
        int min = Integer.MAX_VALUE;
        for(int i=start; i<end; i++){
            int left = search(A,start,i,dp,sum);
            int right = search(A,i+1,end,dp,sum);
            int now = sum[end+1] - sum[start];
            min = Math.min(min,left+right+now);
        }
        dp[start][end] = min;
        return min;
    }
}