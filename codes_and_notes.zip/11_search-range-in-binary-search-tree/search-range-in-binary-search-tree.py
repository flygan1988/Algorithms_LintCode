# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/search-range-in-binary-search-tree
@Language: Python
@Datetime: 16-07-08 06:12
'''

"""
Definition of TreeNode:
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left, self.right = None, None
"""
class Solution:
    """
    @param root: The root of the binary search tree.
    @param k1 and k2: range k1 to k2.
    @return: Return all keys that k1<=key<=k2 in ascending order.
    """     
    def searchRange(self, root, k1, k2):
        # write your code here
        res = []
        if root is None:
            return res
        stack = []
        while root is not None or len(stack) != 0:
            if root is not None:
                stack.append(root)
                root = root.left
            else:
                node = stack.pop()
                if node.val>=k1 and node.val<=k2:
                    res.append(node.val)
                if node.right is not None:
                    root = node.right
            
        return res