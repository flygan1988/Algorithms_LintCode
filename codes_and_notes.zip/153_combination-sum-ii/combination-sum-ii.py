# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/combination-sum-ii
@Language: Python
@Datetime: 16-08-13 20:07
'''

class Solution:    
    """
    @param candidates: Given the candidate numbers
    @param target: Given the target number
    @return: All the combinations that sum to target
    """
    def combinationSum2(self, candidates, target): 
        # write your code here
        result = []
        path = []
        candidates.sort()
        self.helper(result, path, candidates, 0, target)
        return result
        
    def helper(self, result, path, candidates, pos, target):
        if target < 0:
            return 
        if target == 0:
            if path not in result:
                result.append(list(path))
            return 
        for i in range(pos,len(candidates)):
            if candidates[i] > target:
                break
            path.append(candidates[i])
            self.helper(result, path, candidates, i+1, target-candidates[i])
            path.pop()