/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/combination-sum-ii
@Language: Java
@Datetime: 16-07-05 21:14
*/

public class Solution {
    /**
     * @param num: Given the candidate numbers
     * @param target: Given the target number
     * @return: All the combinations that sum to target
     */
    public List<List<Integer>> combinationSum2(int[] num, int target) {
        // write your code here
        List<List<Integer>> res = new ArrayList<List<Integer>>();
        if(num == null || num.length == 0){
            return res;
        }
        List<Integer> list = new ArrayList<Integer>();
        Arrays.sort(num);
        helper(res,list,num,0,target);
        return res;
    }
    public void helper(List<List<Integer>> res, List<Integer> list, int[] num, int start, int target){
        if(sumList(list) >= target){
            if(sumList(list) == target && !res.contains(list)){
                res.add(new ArrayList<Integer>(list));
            }
            return;
        }
        for(int i=start; i<num.length; i++){
            list.add(num[i]);
            helper(res,list,num,i+1,target);
            list.remove(list.size()-1);
        }
    }
    public int sumList(List<Integer> list){
        int sum = 0; 
        for(int i=0; i<list.size(); i++){
            sum += list.get(i);
        }
        return sum;
    }
}