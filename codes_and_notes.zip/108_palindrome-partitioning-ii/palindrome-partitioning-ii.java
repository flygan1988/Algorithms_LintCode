/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/palindrome-partitioning-ii
@Language: Java
@Datetime: 16-03-18 05:34
*/

public class Solution {
    /**
     * @param s a string
     * @return an integer
     */
     
    private boolean isPalindrome(String s, int start, int end){
        for(int i=start, j=end; i<j; i++, j--){
            if(s.charAt(i) != s.charAt(j)){
                return false;
            }
        }
        return true;
    }
    
    public int minCut(String s) {
        // write your code here
        int n = s.length();
        //Initialization 
        int[] f = new int[n+1];
        for(int i=0; i<=n; i++){
            f[i] = i;
        }
        //Dynamic programming
        for(int i=1; i<=n; i++){
            for(int j=0; j<i; j++){
                if(f[j] < f[i] && isPalindrome(s,j,i-1)){
                    f[i] = f[j] + 1;
                }
            }
        }
        return f[n] - 1;
    }
};