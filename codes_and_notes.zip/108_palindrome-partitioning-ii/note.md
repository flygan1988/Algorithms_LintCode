```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/palindrome-partitioning-ii
@Language: Markdown
@Datetime: 16-03-18 05:34
```

state: f[i] represents the least number of palindromes produced by the first i charaters.
function: f[i] = min{f[j] + 1}, where j<i && substring from j+1 to i is a palindrome.
initialize: f[i] = i (f[0] = 0)
result: f[n] -1;