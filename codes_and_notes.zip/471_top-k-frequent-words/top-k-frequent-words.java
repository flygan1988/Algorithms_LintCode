/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/top-k-frequent-words
@Language: Java
@Datetime: 16-05-22 18:18
*/

class Pair{
    String word;
    int count;
    public Pair(String word, int count){
        this.word = word;
        this.count = count;
    }
}
class MyComparator implements Comparator<Pair>{
    public int compare(Pair p1, Pair p2){
        if(p1.count != p2.count){
            return p1.count - p2.count;
        }
        else{
            return p2.word.compareTo(p1.word);
        }
    }
}
public class Solution {
    /**
     * @param words an array of string
     * @param k an integer
     * @return an array of string
     */
    public String[] topKFrequentWords(String[] words, int k) {
        // Write your code here
        String[] res = new String[k];
        if(words == null || words.length == 0 || k <= 0){
            return res;
        }
        HashMap<String,Integer> map = new HashMap<String,Integer>();
        for(int i=0; i<words.length; i++){
            if(!map.containsKey(words[i])){
                map.put(words[i],1);
            }
            else{
                map.put(words[i],map.get(words[i])+1);
            }
        }
        PriorityQueue<Pair> q = new PriorityQueue<>(k,new MyComparator());
        for(String key:map.keySet()){
            if(q.size()<k){
                q.offer(new Pair(key,map.get(key)));
            }
            else{
                Pair p = q.peek();
                if(map.get(key) > p.count || (map.get(key) == p.count && key.compareTo(p.word) < 0)){
                    q.poll();
                    q.offer(new Pair(key,map.get(key)));
                }
            }
        }
        int index = 0;
        while(!q.isEmpty()){
            res[index++] = q.poll().word;
        }
        inverse(res);
        return res;
    }
    public void inverse(String[] words){
        for(int i=0; i<words.length/2; i++){
            String tmp = words[i];
            words[i] = words[words.length-1-i];
            words[words.length-1-i] = tmp;
        }
    }
}