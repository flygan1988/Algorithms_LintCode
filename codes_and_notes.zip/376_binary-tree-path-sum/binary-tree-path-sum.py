# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/binary-tree-path-sum
@Language: Python
@Datetime: 16-07-08 03:25
'''

"""
Definition of TreeNode:
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left, self.right = None, None
"""
class Solution:
    # @param {TreeNode} root the root of binary tree
    # @param {int} target an integer
    # @return {int[][]} all valid paths
    def binaryTreePathSum(self, root, target):
        # Write your code here
        res = []
        path = []
        self.helper(root,res,path,target)
        return res
        
    def helper(self,root,res,path,target):
        if root is None:
            return
        path.append(root.val)
        if root.left is None and root.right is None and self.isEqualTar(path,target):
            res.append(path[:])
        self.helper(root.left,res,path,target)
        self.helper(root.right,res,path,target)
        path.pop()
        
    def isEqualTar(self,path,target):
        sum = 0
        for i in range(0,len(path)):
            sum += path[i]
        if sum == target:
            return True
        return False