/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/binary-tree-path-sum
@Language: Java
@Datetime: 16-05-15 17:08
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @param root the root of binary tree
     * @param target an integer
     * @return all valid paths
     */
    public List<List<Integer>> binaryTreePathSum(TreeNode root, int target) {
        // Write your code here
        List<List<Integer>> result = new ArrayList<List<Integer>>();
        List<Integer> buffer = new ArrayList<Integer>();
        if(root == null){
            return result;
        }
        //List<Integer> items = new ArrayList<>();
        dfs(root,buffer,result,target);
        return result;
    }
    public void dfs(TreeNode node, List<Integer> buffer, List<List<Integer>> result, int sum){
        if(node == null){
            return;
        }
        buffer.add(node.val);
        List<Integer> temp = new ArrayList<Integer>();
        if(isEqual(buffer,sum) && node.left == null && node.right == null){
            for(int item:buffer){
                temp.add(item);
            }
            result.add(temp);
        }
        
        dfs(node.left,buffer,result,sum);
        dfs(node.right,buffer,result,sum);
        buffer.remove(buffer.size()-1);
    }
    public boolean isEqual(List<Integer> buffer, int target){
        int sum = 0;
        for(int i:buffer){
            sum += i;
        }
        if(sum == target){
            return true;
        }
        return false;
    }
}