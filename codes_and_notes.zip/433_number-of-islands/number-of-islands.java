/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/number-of-islands
@Language: Java
@Datetime: 16-05-14 02:52
*/

class UnionFind{
    HashMap<Integer,Integer> father = new HashMap<Integer,Integer>();
    
    public int find(int x){
        int parent = father.get(x);
        while(parent != father.get(parent)){
            parent = father.get(parent);
        }
        return parent;
    }
    public void union(int x, int y){
        int fa_x = find(x);
        int fa_y = find(y);
        if(fa_x != fa_y){
            father.put(fa_x,fa_y);
        }
    }
}
public class Solution {
    /**
     * @param grid a boolean 2D matrix
     * @return an integer
     */
    public int numIslands(boolean[][] grid) {
        // Write your code here
        if(grid.length == 0 || grid == null){
            return 0;
        }
        int m = grid.length;
        int n = grid[0].length;
        UnionFind uf = new UnionFind();
        for(int i=0; i<m*n; i++){
            if(grid[i/n][i%n] == true){
                uf.father.put(i,i);
            }
        }
        for(int key:uf.father.keySet()){
            if(key/n==(key+1)/n && uf.father.containsKey(key+1)){
                uf.union(key,key+1);
            }
            if(key/n==(key-1)/n && uf.father.containsKey(key-1)){
                uf.union(key,key-1);
            }
            if(uf.father.containsKey(key+n)){
                uf.union(key,key+n);
            }
            if(uf.father.containsKey(key-n)){
                uf.union(key,key-n);
            }
        }
        return print(uf);
    }
    public int print(UnionFind uf){
        HashSet<Integer> hs = new HashSet<Integer>();
        for(int i:uf.father.keySet()){
            int fa = uf.find(i);
            if(!hs.contains(fa)){
                hs.add(fa);
            }
        }
        return hs.size();
    }
}