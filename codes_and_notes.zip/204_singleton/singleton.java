/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/singleton
@Language: Java
@Datetime: 16-08-17 20:40
*/

class Solution {
    /**
     * @return: The same instance of this class every time
     */
    private static Solution s = null;
    private Solution(){
        
    }
    public static Solution getInstance() {
        // write your code here
        if(s == null){
            s = new Solution();
        }
        return s;
    }
};