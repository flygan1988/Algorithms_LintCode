# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/unique-paths
@Language: Python
@Datetime: 16-07-08 23:01
'''

class Solution:
    """
    @param n and m: positive integer(1 <= n , m <= 100)
    @return an integer
    """ 
    def uniquePaths(self, m, n):
        # write your code here
        dp = [[0 for j in range(0,n)] for i in range(0,m)]
        for i in range(0,m):
            for j in range(0,n):
                if i ==0 or j == 0:
                    dp[i][j] = 1
                else:
                    dp[i][j] = dp[i-1][j] + dp[i][j-1]
        return dp[m-1][n-1]
        