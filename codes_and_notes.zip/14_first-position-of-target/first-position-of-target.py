# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/first-position-of-target
@Language: Python
@Datetime: 16-07-08 00:47
'''

class Solution:
    # @param nums: The integer array
    # @param target: Target number to find
    # @return the first position of target in nums, position start from 0 
    def binarySearch(self, nums, target):
        # write your code here
        if len(nums) == 0:
            return -1
        left = 0
        right = len(nums)-1
        while left < right-1:
            mid = (left + right)/2
            if nums[mid] >= target:
                right = mid
            else:
                left = mid
        if nums[left] != target and nums[right] != target:
            return -1
        if nums[left] != target:
            return right
        return left