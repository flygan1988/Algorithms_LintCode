/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/merge-k-sorted-arrays
@Language: Java
@Datetime: 16-06-03 01:43
*/

class Point{
    int value;
    int arrayNo;
    int index;
    public Point(int value, int arrayNo, int index){
        this.value = value;
        this.arrayNo = arrayNo;
        this.index = index;
    }
}
public class Solution {
    /**
     * @param arrays k sorted integer arrays
     * @return a sorted array
     */
    public List<Integer> mergekSortedArrays(int[][] arrays) {
        // Write your code here
        List<Integer> res = new ArrayList<>();
        int k = arrays.length;
        PriorityQueue<Point> heap = new PriorityQueue<Point>(1,new Comparator<Point>(){
           public int compare(Point p1, Point p2){
               return p1.value-p2.value;
           } 
        });
        for(int i=0; i<k; i++){
            if(arrays[i].length != 0){
                int value = arrays[i][0];
                heap.offer(new Point(value,i,0));
            }
        }
        while(!heap.isEmpty()){
            Point p = heap.poll();
            res.add(p.value);
            if(p.index+1 < arrays[p.arrayNo].length){
                int val = arrays[p.arrayNo][p.index+1];
                heap.offer(new Point(val,p.arrayNo,p.index+1));
            }
        }
        return res;
    }
}