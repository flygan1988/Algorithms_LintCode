/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/search-in-rotated-sorted-array-ii
@Language: Java
@Datetime: 16-06-30 15:04
*/

public class Solution {
    /** 
     * param A : an integer ratated sorted array and duplicates are allowed
     * param target :  an integer to be search
     * return : a boolean 
     */
    public boolean search(int[] A, int target) {
        // write your code here
        if(A == null || A.length == 0){
            return false;
        }
        int minIndex = findMin(A);
        boolean left = binarySearch(A,0,minIndex-1,target);
        boolean right = binarySearch(A,minIndex,A.length-1,target);
        return left || right;
    }
    public boolean binarySearch(int[] A, int l, int r, int target){
        if(l > r){
            return false;
        }
        int left = l, right = r;
        while(left < right-1){
            int mid = (left+right)/2;
            if(A[mid] == target){
                return true;
            }else if(A[mid]<target){
                left = mid;
            }else{
                right = mid;
            }
        }
        if(A[left] == target || A[right] == target){
            return true;
        }
        return false;
    }
    public int findMin(int[] A){
        int left=0, right=A.length-1;
        while(left < right-1){
            int mid = (left+right)/2;
            if(A[mid]<=A[right]){
                right = mid;
            }else{
                left = mid;
            }
        }
        if(A[left]<A[right]){
            return left;
        }
        return right;
    }
}
