/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/decode-ways
@Language: Java
@Datetime: 16-08-26 01:31
*/

public class Solution {
    /**
     * @param s a string,  encoded message
     * @return an integer, the number of ways decoding
     */
    public int numDecodings(String s) {
        // Write your code here
        if(s == null || s.length() == 0 || s.charAt(0) == '0'){
            return 0;
        }
        int[] f = new int[s.length()+1];
        f[0] = 1;
        f[1] = 1;
        for(int i=2; i<f.length; i++){
            int cur = Integer.parseInt(s.substring(i-2,i));
            if(s.charAt(i-1) == '0'){
                if(cur < 1 || cur > 26){
                    return 0;
                }
                f[i] = f[i-2];
            }
            else{
                f[i] = f[i-1];
                if(s.charAt(i-2) != '0' && cur <= 26){
                    f[i] += f[i-2];
                }
            }
        }
        return f[s.length()];
    }
}