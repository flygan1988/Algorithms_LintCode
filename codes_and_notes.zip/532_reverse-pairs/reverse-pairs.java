/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/reverse-pairs
@Language: Java
@Datetime: 16-06-30 05:03
*/

public class Solution {
    /**
     * @param A an array
     * @return total of reverse pairs
     */
    public long reversePairs(int[] A) {
        // Write your code here
        long count = 0;
        for(int i=0; i<A.length; i++){
            for(int j=i+1; j<A.length; j++){
                if(A[j] < A[i]){
                    count++;
                }
            }
        }
        return count;
    }
}