# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/intersection-of-two-arrays
@Language: Python
@Datetime: 16-07-11 20:41
'''

class Solution:
    # @param {int[]} nums1 an integer array
    # @param {int[]} nums2 an integer array
    # @return {int[]} an integer array
    def intersection(self, nums1, nums2):
        # Write your code here
        res = []
        dic = {}
        for i in range(len(nums1)):
            dic[nums1[i]] = None
        for i in range(len(nums2)):
            if nums2[i] in dic:
                res.append(nums2[i])
                del dic[nums2[i]]
        return res