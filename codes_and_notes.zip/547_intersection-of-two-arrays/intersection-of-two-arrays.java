/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/intersection-of-two-arrays
@Language: Java
@Datetime: 16-06-01 20:42
*/

public class Solution {
    /**
     * @param nums1 an integer array
     * @param nums2 an integer array
     * @return an integer array
     */
    public int[] intersection(int[] nums1, int[] nums2) {
        // Write your code here
        Arrays.sort(nums1);
        Arrays.sort(nums2);
        HashSet<Integer> res = new HashSet<Integer>();
        int i=0, j=0;
        while(i<nums1.length && j<nums2.length){
            if(nums1[i] == nums2[j] && !res.contains(nums1[i])){
                res.add(nums1[i]);
                i++;
                j++;
            }else if(nums1[i]<nums2[j]){
                i++;
            }else{
                j++;
            }
        }
        int[] resArray = new int[res.size()];
        int k = 0;
        for(int key:res){
            resArray[k++] = key;
        }
        return resArray;
    }
}