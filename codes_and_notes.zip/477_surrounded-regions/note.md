```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/surrounded-regions
@Language: Markdown
@Datetime: 16-06-23 21:51
```

search the element on the edges which is 'O', applying BFS search on this element to change all the element to 'Y' in the BFS path.
Then traverse the board to change Y back to O, and O to X.