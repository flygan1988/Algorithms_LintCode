/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/surrounded-regions
@Language: Java
@Datetime: 16-06-23 21:51
*/

class Point{
    int x;
    int y;
    Point(int x, int y){
        this.x = x;
        this.y = y;
    }
}
public class Solution {
    /**
     * @param board a 2D board containing 'X' and 'O'
     * @return void
     */
    public void surroundedRegions(char[][] board) {
        // Write your code here
        int m = board.length;
        if(m == 0) return;
        int n = board[0].length;
        for(int i=0; i<n; i++){
            if(board[0][i] == 'O'){
                BFS(board,0,i);
            }
            if(board[m-1][i] == 'O'){
                BFS(board,m-1,i);
            }
        }
        for(int i=1; i<m; i++){
            if(board[i][0] == 'O'){
                BFS(board,i,0);
            }
            if(board[i][n-1] == 'O'){
                BFS(board,i,n-1);
            }
        }
        //replace
        for(int i=0; i<m; i++){
            for(int j=0; j<n; j++){
                if(board[i][j] == 'O'){
                    board[i][j] = 'X';
                }else if(board[i][j] == 'Y'){
                    board[i][j] = 'O';
                }
            }
        }
    }
    public void BFS(char[][] board, int x, int y){
        int[] dx = {-1,1,0,0};
        int[] dy = {0,0,-1,1};
        Queue<Point> queue = new LinkedList<Point>();
        queue.offer(new Point(x,y));
        while(!queue.isEmpty()){
            Point p = queue.poll();
            board[p.x][p.y] = 'Y';
            for(int i=0; i<4; i++){
                int xx = p.x + dx[i];
                int yy = p.y + dy[i];
                if(xx>=0 && xx<board.length && yy>=0 && yy<board[0].length && board[xx][yy]=='O'){
                    board[xx][yy] ='Y';
                    queue.offer(new Point(xx,yy));
                }
            }
        }
    }
}