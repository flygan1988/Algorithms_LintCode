/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/search-for-a-range
@Language: Java
@Datetime: 16-05-27 20:01
*/

public class Solution {
    /** 
     *@param A : an integer sorted array
     *@param target :  an integer to be inserted
     *return : a list of length 2, [index1, index2]
     */
    public int[] searchRange(int[] A, int target) {
        // write your code here
        int[] res = new int[2];
        res[0] = -1;
        res[1] = -1;
        if(A == null || A.length == 0){
            return res;
        }
        int firstPos = findFirstPosition(A,target);
        int lastPos = findLastPosition(A,target);
        res[0] = firstPos;
        res[1] = lastPos;
        return res;
    }
    private int findFirstPosition(int[] A, int target){
        int left = 0, right = A.length-1;
        while(left < right-1){
            int mid = (left+right)/2;
            if(A[mid] >= target){
                right = mid;
            }else{
                left = mid;
            }
        }
        if(A[left] == target){
            return left;
        }
        if(A[right] == target){
            return right;
        }
        return -1;
    }
    private int findLastPosition(int[] A, int target){
        int left = 0, right = A.length-1;
        while(left < right-1){
            int mid = (left+right)/2;
            if(A[mid] <= target){
                left = mid;
            }else{
                right = mid;
            }
        }
        if(A[right] == target){
            return right;
        }
        if(A[left] == target){
            return left;
        }
        return -1;
    }
}
