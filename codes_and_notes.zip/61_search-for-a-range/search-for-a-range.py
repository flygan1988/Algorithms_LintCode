# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/search-for-a-range
@Language: Python
@Datetime: 16-07-08 01:54
'''

class Solution:
    """
    @param A : a list of integers
    @param target : an integer to be searched
    @return : a list of length 2, [index1, index2]
    """
    def searchRange(self, A, target):
        # write your code here
        firstPos = self.binarySearch(A,target)
        if firstPos == -1:
            return [-1,-1]
        list = []
        list.append(firstPos)
        while firstPos+1<len(A) and A[firstPos+1]==target:
            firstPos += 1
        list.append(firstPos)
        return list
    
    def binarySearch(self, nums, target):
        # write your code here
        if len(nums) == 0:
            return -1
        left = 0
        right = len(nums)-1
        while left < right-1:
            mid = (left + right)/2
            if nums[mid] >= target:
                right = mid
            else:
                left = mid
        if nums[left] != target and nums[right] != target:
            return -1
        if nums[left] != target:
            return right
        return left