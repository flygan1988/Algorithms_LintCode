/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/jump-game-ii
@Language: Java
@Datetime: 16-03-16 22:51
*/

public class Solution {
    /**
     * @param A: A list of lists of integers
     * @return: An integer
     */
    public int jump(int[] A) {
        // write your code here
        int n = A.length;
        int[] f = new int[n];
        //int min = Integer.MAX_VALUE;
        f[0] = 0;
        for(int i=1; i<n; i++){
            f[i] = Integer.MAX_VALUE;
            for(int j=0; j<i; j++){
                if(f[j] != Integer.MAX_VALUE && i-j <= A[j]){
                    f[i] = f[j] + 1;
                    break;
                }
            }
        }
        return f[n-1];
    }
}
