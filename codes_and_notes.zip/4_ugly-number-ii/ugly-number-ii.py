# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/ugly-number-ii
@Language: Python
@Datetime: 16-07-14 02:51
'''

class Solution:
    """
    @param {int} n an integer.
    @return {int} the nth prime number as description.
    """
    def nthUglyNumber(self, n):
        # write your code here
        ans = []
        ans.append(1)
        cur = 2
        p1 = p2 = p3 = 0
        while len(ans) < n:
            while ans[p1] * 2 < cur:
                p1 += 1
            min1 = ans[p1]*2
            while ans[p2] * 3 < cur:
                p2 += 1
            min2 = ans[p2] * 3
            while ans[p3] * 5 < cur:
                p3 += 1
            min3 = ans[p3] * 5
            
            next = min(min(min1,min2),min3)
            cur = next + 1
            ans.append(next)
        return ans[n-1]
