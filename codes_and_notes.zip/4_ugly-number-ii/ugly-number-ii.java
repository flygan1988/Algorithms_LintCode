/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/ugly-number-ii
@Language: Java
@Datetime: 16-06-04 02:41
*/

class Solution {
    /**
     * @param n an integer
     * @return the nth prime number as description.
     */
    public int nthUglyNumber(int n) {
        List<Integer> uglys = new ArrayList<Integer>();
        uglys.add(1);
        int cur = 2;
        int p1= 0,p2 = 0,p3 = 0;
        int min1, min2, min3;
        while (uglys.size() < n) {
            while (uglys.get(p1) * 2 < cur)
                p1++;
            min1 = uglys.get(p1) * 2;

            while (uglys.get(p2) * 3 < cur)
                p2++;
            min2 = uglys.get(p2) * 3;

            while (uglys.get(p3) * 5 < cur)
                p3++;
            min3 = uglys.get(p3) * 5;

            int next = min1<min2? min1 : min2;
            next = next < min3 ? next : min3;

            cur = next + 1;
            uglys.add(next);
        }

        return uglys.get(n-1);
    }
    /***
    public int nthUglyNumber(int n) {
        // Write your code here
        PriorityQueue<Integer> heap = new PriorityQueue<Integer>(1,new Comparator<Integer>(){
            public int compare(Integer i1, Integer i2){
                return i2-i1;
            }
        });
        int i = 1;
        while(heap.size()<n){
            if(isUglyNum(i)){
                heap.offer(i);
            }
            i++;
        }
        return heap.poll();
    }
    public boolean isUglyNum(int number){
        if(number==1){
            return true;
        }
        if(number%2==0){
            return isUglyNum(number/2);
        }
        if(number%3==0){
            return isUglyNum(number/3);
        }
        if(number%5==0){
            return isUglyNum(number/5);
        }
        return false;
    }**/
};
