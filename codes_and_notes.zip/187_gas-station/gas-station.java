/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/gas-station
@Language: Java
@Datetime: 16-07-04 20:30
*/

public class Solution {
    /**
     * @param gas: an array of integers
     * @param cost: an array of integers
     * @return: an integer
     */
    public int canCompleteCircuit(int[] gas, int[] cost) {
        // write your code here
        if(gas == null || cost == null || gas.length == 0 || cost.length == 0 || sum(gas) < sum(cost)){
            return -1;
        }
        int total = 0;
        int stationIndex = 0;
        for(int i=0; i<gas.length; i++){
            if(gas[i] + total < cost[i]){
                stationIndex = i+1;
                total = 0;
            }else{
                total += gas[i] - cost[i];
            }
        }
        return stationIndex;
    }
    public int sum(int[] A){
        int sum = 0;
        for(int i=0; i<A.length; i++){
            sum += A[i];
        }
        return sum;
    }
}