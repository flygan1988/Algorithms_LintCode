/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/single-number-iii
@Language: Java
@Datetime: 16-06-24 05:25
*/

public class Solution {
    /**
     * @param A : An integer array
     * @return : Two integers
     */
    public List<Integer> singleNumberIII(int[] A) {
        // write your code here
        List<Integer> result = new ArrayList<Integer>();
        int xor_res = 0;
        for(int i=0; i<A.length; i++){
            xor_res ^= A[i];
        }
        int k = 0;
        for(; k<32; k++){
            if((xor_res >> k & 1) == 1){
                break;
            }
        }
        int num1 = 0, num2 = 0;
        for(int i=0; i<A.length; i++){
            if((A[i] >> k & 1) == 1){
                num1 ^= A[i];
            }else{
                num2 ^= A[i];
            }
        }
        result.add(num1);
        result.add(num2);
        return result;
    }
}