/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/search-a-2d-matrix
@Language: Java
@Datetime: 16-05-27 02:36
*/

public class Solution {
    /**
     * @param matrix, a list of lists of integers
     * @param target, an integer
     * @return a boolean, indicate whether matrix contains target
     */
    public boolean searchMatrix(int[][] matrix, int target) {
        // write your code here
        if(matrix==null || matrix.length==0 || matrix[0].length==0){
            return false;
        }
        int m=matrix.length, n=matrix[0].length;
        int left=0, right=m*n-1;
        while(left<right-1){
            int mid = (left+right)/2;
            if(matrix[mid/n][mid%n]==target){
                return true;
            }else if(matrix[mid/n][mid%n]<target){
                left = mid;
            }else{
                right = mid;
            }
        }
        if(matrix[left/n][left%n]==target){
            return true;
        }
        if(matrix[right/n][right%n]==target){
            return true;
        }
        return false;
    }
}
