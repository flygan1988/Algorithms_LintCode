# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/search-a-2d-matrix
@Language: Python
@Datetime: 16-07-08 00:40
'''

class Solution:
    """
    @param matrix, a list of lists of integers
    @param target, an integer
    @return a boolean, indicate whether matrix contains target
    """
    def searchMatrix(self, matrix, target):
        # write your code here
        if len(matrix) == 0:
            return False
        m = len(matrix)
        n = len(matrix[0])
        
        left = 0
        right = m*n-1
        while left < right-1:
            mid = (left + right) / 2
            if matrix[mid/n][mid%n] == target:
                return True
            elif matrix[mid/n][mid%n] < target:
                left = mid
            else:
                right = mid
        if matrix[left/n][left%n] == target:
            return True
        if matrix[right/n][right%n] == target:
            return True
        return False