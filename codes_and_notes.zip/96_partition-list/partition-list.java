/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/partition-list
@Language: Java
@Datetime: 16-06-18 03:38
*/

/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 */ 
public class Solution {
    /**
     * @param head: The first node of linked list.
     * @param x: an integer
     * @return: a ListNode 
     */
    public ListNode partition(ListNode head, int x) {
        // write your code here
        if(head == null){
            return head;
        }
        ListNode dummy = new ListNode(0);
        dummy.next = head;
        head = dummy;
        ListNode p = dummy.next;
        //Find the first node to insert and first node whose val >= x
        while(p != null && p.val < x){
            head = p;
            p = p.next;
        }
        //Handle the case that all nodes are less than x
        if(p == null){
            return dummy.next;
        }
        //Record the fisrt node whose val >= x;
        ListNode pos = p;
        ListNode q = p.next;
        while(q!=null){
            if(q.val >= x){
                p = q;
                q = q.next;
            }else{
                head.next = q;
                head = head.next;
                p.next = q.next;
                q = q.next;
            }
        }
        head.next = pos;
        return dummy.next;
    }
}
