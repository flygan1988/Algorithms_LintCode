# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/partition-list
@Language: Python
@Datetime: 16-07-10 01:37
'''

"""
Definition of ListNode
class ListNode(object):

    def __init__(self, val, next=None):
        self.val = val
        self.next = next
"""
class Solution:
    """
    @param head: The first node of linked list.
    @param x: an integer
    @return: a ListNode 
    """
    def partition(self, head, x):
        # write your code here
        dummy = ListNode(0)
        dummy.next = head
        p = dummy
        while head is not None and head.val < x:
            p = head
            head = head.next
        if head is None:
            return dummy.next
        pre = head
        head = head.next
        while head is not None:
            if head.val >= x:
                pre = head
                head = head.next
            else:
                pre.next = pre.next.next
                head.next = p.next
                p.next = head
                p = p.next
                head = pre.next
        return dummy.next