```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/coins-in-a-line-ii
@Language: Markdown
@Datetime: 16-08-08 03:49
```

state

DP[i]表示从i到end能取到的最大value
function

当我们走到i时，有两种选择
取values[i]
取values[i] + values[i+1]
1. 我们取了values[i],对手的选择有 values[i+1]或者values[i+1] + values[i+2] 剩下的最大总value分别为DP[i+2]或DP[i+3], 对手也是理性的所以要让我们得到最小value
所以 value1 = values[i] + min(DP[i+2], DP[i+3])
2. 我们取了values[i]和values[i+1] 同理 value2 = values[i] + values[i+1] + min(DP[i+3], DP[i+4])
最后

DP[I] = max(value1, value2)