/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/coins-in-a-line-ii
@Language: Java
@Datetime: 16-07-06 19:25
*/

public class Solution {
    /**
     * @param values: an array of integers
     * @return: a boolean which equals to true if the first player will win
     */
    public boolean firstWillWin(int[] values) {
        // write your code here
        if(values == null || values.length == 0){
            return false;
        }
        if(values.length <= 2){
            return true;
        }
        int len = values.length;
        int[] f = new int[len];
        f[len-1] = values[len-1];
        f[len-2] = values[len-2] + values[len-1];
        for(int i=len-3; i>=0; i--){
            int a = 0, b = 0, c = 0;
            if(i+2 < len){
                a = f[i+2];
            }
            if(i+3 < len){
                b = f[i+3];
            }
            if(i+4 < len){
                c = f[i+4];
            }
            int value1 = values[i] + Math.min(a,b);
            int value2 = values[i] + values[i+1] + Math.min(b,c);
            f[i] = Math.max(value1,value2);
        }
        int total = 0;
        for(int i=0; i<len; i++){
            total += values[i];
        }
        return f[0]>total-f[0]?true:false;
    }
}