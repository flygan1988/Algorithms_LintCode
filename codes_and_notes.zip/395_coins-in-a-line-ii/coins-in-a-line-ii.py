# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/coins-in-a-line-ii
@Language: Python
@Datetime: 16-08-08 03:49
'''

class Solution:
    # @param values: a list of integers
    # @return: a boolean which equals to True if the first player will win
    def firstWillWin(self, values):
        # write your code here
        if not values or len(values) == 0:
            return False
        n = len(values)
        dp = [0 for i in range(n)]
        dp[n-1] = values[n-1]
        dp[n-2] = values[n-1] + values[n-2]
        for i in range(n-3,-1,-1):
            a,b,c = 0,0,0
            if i+2 < n:
                a = dp[i+2]
            if i+3 < n:
                b = dp[i+3]
            if i+4 < n:
                c = dp[i+4]
            value1 = values[i] + min(a,b)
            value2 = values[i] + values[i+1] + min(b,c)
            dp[i] = max(value1,value2)
        total = 0
        for i in range(n):
            total += values[i]
        if dp[0] > total-dp[0]:
            return True
        return False
