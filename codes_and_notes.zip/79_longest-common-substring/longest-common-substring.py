# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/longest-common-substring
@Language: Python
@Datetime: 16-07-09 22:43
'''

class Solution:
    # @param A, B: Two string.
    # @return: the length of the longest common substring.
    def longestCommonSubstring(self, A, B):
        # write your code here
        if len(A) == 0 or len(B) == 0:
            return 0
        
        m = len(A)
        n = len(B)
        res = 0
        
        f = [[0 for i in range(0,n+1)] for i in range(0,m+1)]
        
        for i in range(1,m+1):
            for j in range(1,n+1):
                if A[i-1] == B[j-1]:
                    f[i][j] = f[i-1][j-1] + 1
                    res = max(res,f[i][j])
                else:
                    f[i][j] = 0
        return res
        
                        
                