/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/last-position-of-target
@Language: Java
@Datetime: 16-06-14 18:31
*/

public class Solution {
    /**
     * @param nums: An integer array sorted in ascending order
     * @param target: An integer
     * @return an integer
     */
    public int lastPosition(int[] nums, int target) {
        // Write your code here
        if(nums == null || nums.length == 0){
            return -1;
        }
        int left = 0, right = nums.length-1;
        while(left < right - 1){
            int mid = (left + right)/2;
            if(nums[mid]<=target){
                left = mid;
            }else{
                right = mid;
            }
        }
        if(nums[left] != target && nums[right] != target){
            return -1;
        }
        if(nums[right] == target){
            return right;
        }
        return left;
    }
}