/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/intersection-of-two-linked-lists
@Language: Java
@Datetime: 16-07-03 02:16
*/

/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) {
 *         val = x;
 *         next = null;      
 *     }
 * }
 */
public class Solution {
    /**
     * @param headA: the first list
     * @param headB: the second list
     * @return: a ListNode 
     */
    //solution1: O(n) time, O(n) space
    public ListNode getIntersectionNode(ListNode headA, ListNode headB) {
        // Write your code here
        if(headA == null || headB == null){
            return null;
        }
        int distance = getLength(headA) - getLength(headB);
        if(distance < 0){
            int i = 0;
            while(i < Math.abs(distance)){
                headB = headB.next;
                i++;
            }
        }else{
            int i = 0;
            while(i < Math.abs(distance)){
                headA = headA.next;
                i++;
            }
        }
        while(headA != headB){
            headA = headA.next;
            headB = headB.next;
        }
        return headA;
    }
    public int getLength(ListNode head){
        int len = 0;
        if(head == null){
            return len;
        }
        while(head != null){
            len++;
            head = head.next;
        }
        return len;
    }
}