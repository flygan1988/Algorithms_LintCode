/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/find-minimum-in-rotated-sorted-array
@Language: Java
@Datetime: 16-09-01 18:51
*/

public class Solution {
    /**
     * @param num: a rotated sorted array
     * @return: the minimum number in the array
     */
    public int findMin(int[] num) {
        // write your code here
        int left = 0, right = num.length-1;
        while(left<right-1){
            int mid = (left+right)/2;
            if(num[mid]>num[right]){
                left = mid;
            }else{
                right = mid;
            }
        }
        if(num[left]<num[right]){
            return num[left];
        }
        return num[right];
    }
}