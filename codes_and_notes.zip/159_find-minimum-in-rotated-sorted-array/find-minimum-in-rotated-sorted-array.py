# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/find-minimum-in-rotated-sorted-array
@Language: Python
@Datetime: 16-07-08 01:11
'''

class Solution:
    # @param num: a rotated sorted array
    # @return: the minimum number in the array
    def findMin(self, num):
        # write your code here
        if num == None or len(num) == 0:
            return -1
        left = 0
        right = len(num)-1
        while left < right - 1:
            mid = (left + right) / 2
            if num[mid] > num[right]:
                left = mid
            else:
                right = mid
        if num[left] < num[right]:
            return num[left]
        return num[right]