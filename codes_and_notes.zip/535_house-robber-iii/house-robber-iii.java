/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/house-robber-iii
@Language: Java
@Datetime: 16-06-09 03:55
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int x) { val = x; }
 * }
 */
public class Solution {
    /**
     * @param root: The root of binary tree.
     * @return: The maximum amount of money you can rob tonight
     */
    public int houseRobber3(TreeNode root) {
        // write your code here
        int[] res = helper(root);
        return Math.max(res[0],res[1]);
    }
    public int[] helper(TreeNode root){
        if(root == null){
            int[] res = {0,0};
            return res;
        }
        int[] res = new int[2];
        int[] left = helper(root.left);
        int[] right = helper(root.right);
        
        res[0] = root.val + left[1] + right[1];
        res[1] = Math.max(left[0],left[1]) + Math.max(right[0],right[1]);
        return res;
    }
}