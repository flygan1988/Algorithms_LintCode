/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/top-k-largest-numbers
@Language: Java
@Datetime: 16-06-01 23:35
*/

class Solution {
    /*
     * @param nums an integer array
     * @param k an integer
     * @return the top k largest numbers in array
     */
    public int[] topk(int[] nums, int k) {
        // Write your code here
        int[] res = new int[k];
        if(nums == null || nums.length == 0 || k<=0){
            return res;
        }
        PriorityQueue<Integer> heap = new PriorityQueue<Integer>(1,new Comparator<Integer>(){
          public int compare(Integer i1, Integer i2){
               return i2-i1;
           } 
        });
        for(int i=0; i<nums.length; i++){
            heap.offer(nums[i]);
        }
        for(int i=0; i<res.length; i++){
            res[i] = heap.poll();
        }
        return res;
    }
};

