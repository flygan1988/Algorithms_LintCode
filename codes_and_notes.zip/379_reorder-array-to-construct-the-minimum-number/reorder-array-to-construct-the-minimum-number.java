/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/reorder-array-to-construct-the-minimum-number
@Language: Java
@Datetime: 16-08-23 23:46
*/

public class Solution {
    /**
     * @param nums n non-negative integer array
     * @return a string
     */
    public String minNumber(int[] nums) {
        // Write your code here
        String[] strs = new String[nums.length];
        for(int i=0; i<nums.length; i++){
            strs[i] = String.valueOf(nums[i]);
        }
        Arrays.sort(strs, new Comparator<String>(){
            public int compare(String a, String b){
                String ab = a.concat(b);
                String ba = b.concat(a);
                return -ba.compareTo(ab);
            }
        });
        StringBuilder sb = new StringBuilder();
        for(int i=0; i<strs.length; i++){
            sb.append(strs[i]);
        }
        String res = sb.toString();
        int i = 0;
        while(i < res.length() && res.charAt(i) == '0'){
            i++;
        }
        if(i == res.length()){
            return "0";
        }
        return res.substring(i);
    }
    public int compareInt(int num1, int num2){
        if(num1 == num2){
            return 0;
        }
        String str1 = String.valueOf(num1);
        String str2 = String.valueOf(num2);
        if(str1.length() == str2.length()){
            return num1<num2?-1:1;
        }
        int i = 0;
        for(; i<str1.length()&&i<str2.length(); i++){
            if(str1.charAt(i) < str1.charAt(i)){
                return -1;
            }
            else if(str1.charAt(i) > str2.charAt(i)){
                return 1;
            }
        }
        if(i == str2.length()){
            int k = 0;
            while(i < str1.length() && str1.charAt(i) == str1.charAt(k)){
                i++;
                k++;
            }
            if(i == str1.length()){
                return 0;
            }
            return str1.charAt(k)<str1.charAt(i)?1:-1;
        }
        else{
            int k = 0;
            while(i < str2.length() && str2.charAt(i) == str2.charAt(k)){
                i++;
                k++;
            }
            if(i == str2.length()){
                return 0;
            }
            return str2.charAt(k)<str2.charAt(i)?1:-1;
        }
    }
}