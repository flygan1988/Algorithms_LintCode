# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/min-stack
@Language: Python
@Datetime: 16-07-14 02:26
'''

class MinStack(object):

    def __init__(self):
        # do some intialize if necessary
        self.s1 = []
        self.s2 = []
        self.Min = sys.maxint

    def push(self, number):
        # write yout code here
        self.Min = min(self.Min, number)
        self.s1.append(number)
        self.s2.append(self.Min)
        
    def pop(self):
        # pop and return the top item in stack
        self.s2.pop()
        if len(self.s2) == 0:
            self.Min = sys.maxint
        else:
            self.Min = self.s2[len(self.s2)-1]
        return self.s1.pop()
        
    def min(self):
        # return the minimum number in stack
        return self.s2[len(self.s2)-1]