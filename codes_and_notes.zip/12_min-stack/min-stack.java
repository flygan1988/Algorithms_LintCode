/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/min-stack
@Language: Java
@Datetime: 16-04-12 19:58
*/

public class MinStack {
    private Stack<Integer> stack1 = new Stack<Integer>();
    private Stack<Integer> stack2 = new Stack<Integer>();
    private int min = Integer.MAX_VALUE;
    
    public MinStack() {
        // do initialize if necessary
    }

    public void push(int number) {
        // write your code here
        stack1.push(number);
        if(number < min){
            min = number;
            stack2.push(number);
        }
        else{
            stack2.push(min);   
        }
        
        
    }

    public int pop() {
        // write your code here
        stack2.pop();
        if(stack2.size() == 0){
            min = Integer.MAX_VALUE;
        }
        else{
            min = stack2.peek();
        }
        return stack1.pop();
    }

    public int min() {
        // write your code here
        return stack2.peek();
    }
}
