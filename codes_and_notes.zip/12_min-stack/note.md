```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/min-stack
@Language: Markdown
@Datetime: 16-07-14 02:26
```

use two stacks. The first stack stores the numbers and the other one stores the current minimum number. 
push operation:
if the new number is less than the current minimum number, then update the min = new number. push new number into stacks. 
otherwise just push the current minimum number into stack2 while push the new number into stack1.
Pop operation:
before return the top value in stack1, we should pop stack2 since we need to keep the size of the two stacks is equal.
if stack2.size == 0 after pop operation, we need to update the current minimum number into MAX_VALUE because there is no numbers in stack.
otherwise the current minimum number is the top number of stack2.