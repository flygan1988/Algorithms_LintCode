/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/zigzag-iterator-ii
@Language: Java
@Datetime: 16-06-22 01:04
*/

public class ZigzagIterator2 {
    /**
     * @param vecs a list of 1d vectors
     */
    ArrayList<Integer> merge;
    int curr;
    public ZigzagIterator2(ArrayList<ArrayList<Integer>> vecs) {
        // initialize your data structure here.
        curr = 0;
        merge = mergeList(vecs);
    }

    public int next() {
        // Write your code here
        return merge.get(curr++);
    }

    public boolean hasNext() {
        // Write your code here   
        if(curr < merge.size()){
            return true;
        }
        return false;
    }
    public int maxLength(ArrayList<ArrayList<Integer>> vecs){
        int maxLen = Integer.MIN_VALUE;
        for(int i=0; i<vecs.size(); i++){
            if(vecs.get(i).size() > maxLen){
                maxLen = vecs.get(i).size();
            }
        }
        return maxLen;
    }
    public ArrayList<Integer> mergeList(ArrayList<ArrayList<Integer>> vecs){
        int maxLen = maxLength(vecs);
        int n = vecs.size();
        ArrayList<Integer> res = new ArrayList<Integer>();
        for(int i=0; i<maxLen; i++){
            for(int k=0; k<n; k++){
                if(i >= vecs.get(k).size()){
                    continue;
                }
                res.add(vecs.get(k).get(i));
            }
        }
        return res;
    }
}

/**
 * Your ZigzagIterator2 object will be instantiated and called as such:
 * ZigzagIterator2 solution = new ZigzagIterator2(vecs);
 * while (solution.hasNext()) result.add(solution.next());
 * Output result
 */