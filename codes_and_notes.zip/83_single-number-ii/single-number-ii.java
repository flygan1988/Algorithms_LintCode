/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/single-number-ii
@Language: Java
@Datetime: 16-06-24 02:30
*/

public class Solution {
	/**
	 * @param A : An integer array
	 * @return : An integer 
	 */
	/**
    public int singleNumberII(int[] A) {
        // write your code here
        HashMap<Integer,Integer> map = new HashMap<Integer,Integer>();
        for(int i=0; i<A.length; i++){
            if(!map.containsKey(A[i])){
                map.put(A[i],1);
            }
            else{
                map.put(A[i],map.get(A[i])+1);
            }
        }
        for(int key:map.keySet()){
            if(map.get(key) != 3){
                return key;
            }
        }
        return -1;
    }**/
    //solution 2
    public int singleNumberII(int[] A) {
        if (A == null || A.length == 0) {
            return -1;
        }
        int result=0;
        int[] bits=new int[32];
        for (int i = 0; i < 32; i++) {
            for(int j = 0; j < A.length; j++) {
                bits[i] += A[j] >> i & 1;
                bits[i] %= 3;
            }

            result |= (bits[i] << i);
        }
        return result;
    }
}