```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/remove-node-in-binary-search-tree
@Language: Markdown
@Datetime: 16-07-05 15:34
```

Delete node 有三种情况
因为要delete,在find这个node的过程中要保留一个parent的变量
1. leaf node
删掉这个node，把parent对这个node的reference设为null
2. Node with only one child
delete the node,把parent对node的reference link到node的child
3. Node with 2 children
find the minimum node of right subtree
replace the value of found node
delete the old duplicate node(case 1/2, cause minimum node should not have left child)