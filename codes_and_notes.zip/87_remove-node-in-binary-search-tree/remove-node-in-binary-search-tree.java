/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/remove-node-in-binary-search-tree
@Language: Java
@Datetime: 16-07-05 15:34
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @param root: The root of the binary search tree.
     * @param value: Remove the node with given value.
     * @return: The root of the binary search tree after removal.
     */
    public TreeNode removeNode(TreeNode root, int value) {
        // write your code here
        TreeNode dummy = new TreeNode(0);
        dummy.left = root;
        TreeNode parent = findNodeParent(dummy, root, value);
        TreeNode node;
        if(parent.left != null && parent.left.val == value){
            node = parent.left;
            //delete(parent, node);
        }else if(parent.right != null && parent.right.val == value){
            node = parent.right;
            //delete(parent, node);
        }else{
            return dummy.left;
        }
        
        delete(parent, node);
        return dummy.left;
    }
    public TreeNode findNodeParent(TreeNode parent, TreeNode node, int val){
        if(node == null){
            return parent;
        }
        if(node.val == val){
            return parent;
        }
        else if(val < node.val){
            return findNodeParent(node,node.left,val);
        }
        else{
            return findNodeParent(node,node.right,val);
        }
    }
    public void delete(TreeNode parent, TreeNode node){
        if(node.right == null){
            if(parent.left == node){
                parent.left = node.left;
            }else{
                parent.right = node.left;
            }
        }
        else{
            TreeNode tmp = node.right;
            TreeNode father = node;
            while(tmp.left != null){
                father = tmp;
                tmp = tmp.left;
            }
            if(father.left == tmp){
                father.left = tmp.right;
            }else{
                father.right = tmp.right;
            }
            
            if(parent.left == node){
                parent.left = tmp;
            }else{
                parent.right = tmp;
            }
            
            tmp.left = node.left;
            tmp.right = node.right;
        }
    }
}