# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/inorder-successor-in-binary-search-tree
@Language: Python
@Datetime: 16-07-08 21:14
'''

# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Solution(object):
    """
    @param root <TreeNode>: The root of the BST.
    @param p <TreeNode>: You need find the successor node of p.
    @return <TreeNode>: Successor of p.
    """
    def inorderSuccessor(self, root, p):
        # write your code here
        if root is None:
            return None
        if p.right is not None:
            return self.findMin(p.right)
        successor = None
        while root.val is not None:
            if root.val < p.val:
                root = root.right
            elif root.val > p.val:
                successor = root
                root = root.left
            else:
                break
        return successor
        
    def findMin(self, root):
        if root.left is None:
            return root
        return self.findMin(root.left)