# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/reverse-nodes-in-k-group
@Language: Python
@Datetime: 16-07-11 20:06
'''

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, x):
#         self.val = x
#         self.next = None

class Solution:
    # @param head, a ListNode
    # @param k, an integer
    # @return a ListNode
    def reverseKGroup(self, head, k):
        # Write your code here
        if not head:
            return head
        dummy = ListNode(0)
        dummy.next = head
        length = self.getLen(head)
        times = length / k
        start = end = 0
        for i in range(times):
            start = end + 1
            end = start + k -1
            head = self.reverse(head, start, end)
        return head
    
    def reverse(self, head, m, n):
        if not head or m == n:
            return head
        dummy = ListNode(0)
        dummy.next = head
        head = dummy
        for i in range(m-1):
            head = head.next
        p = head.next
        pre = p
        for i in range(0,n-m+1):
            q = p.next
            p.next = head.next
            head.next = p
            pre.next = q
            p = q
        return dummy.next
    
    def getLen(self, head):
        length = 0
        while head:
            length += 1
            head = head.next
        return length
            