/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/remove-linked-list-elements
@Language: Java
@Datetime: 16-05-24 03:44
*/

/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) { val = x; }
 * }
 */
public class Solution {
    /**
     * @param head a ListNode
     * @param val an integer
     * @return a ListNode
     */
    public ListNode removeElements(ListNode head, int val) {
        // Write your code here
        ListNode dummy = new ListNode(0);
        dummy.next = head;
        ListNode p = head;
        head = dummy;
        while(p != null){
            if(p.val == val){
                head.next = p.next;
                p = p.next;
            }
            else{
                head = head.next;
                p = p.next;
            }
        }
        return dummy.next;
    }
}