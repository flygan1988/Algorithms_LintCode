/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/o1-check-power-of-2
@Language: Java
@Datetime: 16-06-18 02:57
*/

class Solution {
    /*
     * @param n: An integer
     * @return: True or false
     */
    //solution1:O(logn) time
    /**
    public boolean checkPowerOf2(int n) {
        // write your code here
        if(n == 1){
            return true;
        }
        if(n == 0){
            return false;
        }
        if(n % 2 != 0){
            return false;
        }
        return checkPowerOf2(n/2);
    }
    **/
    public boolean checkPowerOf2(int n) {
        // write your code here
        if(n <= 0){
            return false;
        }
        return ((n & (n-1)) == 0)?true:false;
    }
};