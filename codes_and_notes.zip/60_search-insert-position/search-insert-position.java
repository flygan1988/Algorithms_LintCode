/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/search-insert-position
@Language: Java
@Datetime: 16-05-27 02:26
*/

public class Solution {
    /** 
     * param A : an integer sorted array
     * param target :  an integer to be inserted
     * return : an integer
     */
    public int searchInsert(int[] A, int target) {
        // write your code here
        if(A.length == 0){
            return 0;
        }
        int left = 0, right = A.length-1;
        while(left < right-1){
            int mid = (left+right)/2;
            if(A[mid]==target){
                return mid;
            }
            else if(A[mid]<target){
                left = mid;
            }
            else{
                right = mid;
            }
        }
        if(A[left] == target){
            return left;
        }
        if(A[right] == target){
            return right;
        }
        if(A[left]<target && target<A[right]){
            return right;
        }
        if(target>A[right]){
            return right+1;
        }
        return left;
    }
}
