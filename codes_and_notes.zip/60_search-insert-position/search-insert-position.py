# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/search-insert-position
@Language: Python
@Datetime: 16-07-08 00:32
'''

class Solution:
    """
    @param A : a list of integers
    @param target : an integer to be inserted
    @return : an integer
    """
    def searchInsert(self, A, target):
        # write your code here
        if len(A) == 0:
            return 0
        left = 0
        right = len(A)-1
        while left < right-1:
            mid = (left + right)/2
            if A[mid] == target:
                return mid
            elif A[mid] < target:
                left = mid
            else:
                right = mid
        if A[left] == target:
            return left
        if A[right] == target:
            return right
        if target > A[right]:
            return right+1
        if target < A[left]:
            return left
        return right