/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/total-occurrence-of-target
@Language: Java
@Datetime: 16-06-20 06:28
*/

public class Solution {
    /**
     * @param A an integer array sorted in ascending order
     * @param target an integer
     * @return an integer
     */
    public int totalOccurrence(int[] A, int target) {
        // Write your code here
        return helper(A,0,A.length-1,target);
    }
    public int helper(int[] A, int start, int end, int target){
        if(start > end){
            return 0;
        }
        int mid = (start + end) / 2;
        if(A[mid] == target){
            return 1+helper(A,start,mid-1,target)+helper(A,mid+1,end,target);
        }
        return helper(A,start,mid-1,target)+helper(A,mid+1,end,target);
    }
}