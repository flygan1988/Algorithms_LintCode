/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/binary-tree-paths
@Language: Java
@Datetime: 16-08-18 18:12
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @param root the root of the binary tree
     * @return all root-to-leaf paths
     */
    public List<String> binaryTreePaths(TreeNode root) {
        // Write your code here
        List<String> result = new ArrayList<String>();
        if(root == null){
            return result;
        }
        dfs(root,String.valueOf(root.val),result);
        return result;
    }
    public void dfs(TreeNode node, String path, List<String> result){
        // if(node == null){
        //     return;
        // }
        if(node.left == null && node.right == null){
            result.add(path);
            return;
        }
        if(node.left != null){
            dfs(node.left, path + "->" + String.valueOf(node.left.val), result);
        }
        if(node.right != null){
            dfs(node.right, path + "->" + String.valueOf(node.right.val), result);
        }
        
    }
}