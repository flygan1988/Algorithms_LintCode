/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/maximum-product-subarray
@Language: Java
@Datetime: 16-07-13 02:31
*/

public class Solution {
    /**
     * @param nums: an array of integers
     * @return: an integer
     */
    public int maxProduct(int[] nums) {
        // write your code here
        // int[] f = new int[nums.length];
        // f[0] = nums[0];
        int max = nums[0], min = nums[0], res = nums[0];
        for(int i=1; i<nums.length; i++){
            int tmp = max;
            max = Math.max(Math.max(min*nums[i],max*nums[i]),nums[i]);
            min = Math.min(Math.min(min*nums[i],tmp*nums[i]),nums[i]);
            res = Math.max(max,res);
        }
        return res;
    }
}