# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/maximum-product-subarray
@Language: Python
@Datetime: 16-07-13 02:39
'''

class Solution:
    # @param nums: an integer[]
    # @return: an integer
    def maxProduct(self, nums):
        # write your code here
        Max = Min = res = nums[0]
        for i in range(1,len(nums)):
            tmp = Max
            Max = max(max(Max*nums[i],Min*nums[i]),nums[i])
            Min = min(min(tmp*nums[i],Min*nums[i]),nums[i])
            res = max(Max,res)
            
        return res