/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/next-permutation
@Language: Java
@Datetime: 16-07-02 04:45
*/

public class Solution {
    /**
     * @param nums: an array of integers
     * @return: return nothing (void), do not return anything, modify nums in-place instead
     */
    public int[] nextPermutation(int[] nums) {
        // write your code here
        int right = nums.length-1;
        
        while(right>0){
            if(nums[right] > nums[right-1]){
                right--;
                break;
            }
            right--;
        }
        int pos = nums.length-1;
        while(pos>0 && nums[pos]<=nums[right]){
            pos--;
        }
        if(right == pos){
            swapList(nums,0,nums.length-1);
            return nums;
        }
        swapItem(nums,right,pos);
        swapList(nums,right+1,nums.length-1);
        return nums;
    }
    public void swapItem(int[] nums, int i, int j){
        int tmp = nums[i];
        nums[i] = nums[j];
        nums[j] = tmp;
    }
    public void swapList(int[] nums, int i, int j){
        int left = i, right = j;
        while(left < right){
            swapItem(nums,left,right);
            left++;
            right--;
        }
    }
}