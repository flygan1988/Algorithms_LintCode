```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/next-permutation
@Language: Markdown
@Datetime: 16-07-02 04:45
```

http://fisherlei.blogspot.com/2012/12/leetcode-next-permutation.html