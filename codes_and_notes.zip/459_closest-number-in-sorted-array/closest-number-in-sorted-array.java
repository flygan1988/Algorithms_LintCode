/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/closest-number-in-sorted-array
@Language: Java
@Datetime: 16-06-11 17:57
*/

public class Solution {
    /**
     * @param A an integer array sorted in ascending order
     * @param target an integer
     * @return an integer
     */
    public int closestNumber(int[] A, int target) {
        // Write your code here
        int left = 0, right = A.length-1;
        while(left < right-1){
            int mid = (left + right) / 2;
            if(A[mid] == target){
                return mid;
            }
            else if(A[mid] < target){
                left = mid;
            }
            else{
                right = mid;
            }
        }
        return Math.abs(A[left]-target)<=Math.abs(A[right]-target)?left:right;
    }
}