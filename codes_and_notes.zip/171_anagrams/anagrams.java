/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/anagrams
@Language: Java
@Datetime: 16-08-12 22:34
*/

public class Solution {
    /**
     * @param strs: A list of strings
     * @return: A list of strings
     */
    public List<String> anagrams(String[] strs) {
        // write your code here
        boolean[] visited = new boolean[strs.length];
        List<String> result = new ArrayList<>();
        for(int i=0; i<strs.length; i++){
            for(int j=i+1; j<strs.length; j++){
                if(isAnagram(strs[i],strs[j])){
                    if(!visited[i]){
                        result.add(strs[i]);
                        visited[i] = true;
                    }
                    if(!visited[j]){
                        result.add(strs[j]);
                        visited[j] = true;
                    }
                }
            }
        }
        return result;
    }
    
    public boolean isAnagram(String s1, String s2){
        if(s1.length() != s2.length()){
            return false;
        }
        HashMap<Character,Integer> map = new HashMap<>();
        for(int i=0; i<s1.length(); i++){
            char c = s1.charAt(i);
            if(!map.containsKey(c)){
                map.put(c,1);
            }else{
                map.put(c,map.get(c)+1);
            }
        }
        for(int i=0; i<s2.length(); i++){
            char c = s2.charAt(i);
            if(!map.containsKey(c)){
                return false;
            }
            else{
                if(map.get(c) == 1){
                    map.remove(c);
                }else{
                    map.put(c,map.get(c)-1);
                }
            }
        }
        return true;
    }
}