/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/longest-substring-with-at-most-k-distinct-characters
@Language: Java
@Datetime: 16-05-21 17:00
*/

public class Solution {
    /**
     * @param s : A string
     * @return : The length of the longest substring 
     *           that contains at most k distinct characters.
     */
    public int lengthOfLongestSubstringKDistinct(String s, int k) {
        // write your code here
        int i=0, j=0;
        int count = 0;
        int ans = 0;
        if(k<=0){
            return 0;
        }
        HashMap<Character,Integer> hash = new HashMap<Character,Integer>();
        for(;i<s.length();i++){
            while(j<s.length() && count<k){
                if(!hash.containsKey(s.charAt(j))){
                    hash.put(s.charAt(j),1);
                    j++;
                    count++;
                }
                else{
                    hash.put(s.charAt(j),hash.get(s.charAt(j))+1);
                    j++;
                }
            }
            while(j<s.length() && hash.containsKey(s.charAt(j))){
                hash.put(s.charAt(j), hash.get(s.charAt(j))+1);
                j++;
            }
            ans = Math.max(ans,j-i);
            if(hash.get(s.charAt(i)) == 1){
                count--;
                hash.remove(s.charAt(i));
            }
            else{
                hash.put(s.charAt(i),hash.get(s.charAt(i))-1);
            }
        }
        return ans;
    }
}