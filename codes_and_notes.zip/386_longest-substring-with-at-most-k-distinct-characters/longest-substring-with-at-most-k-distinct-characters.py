# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/longest-substring-with-at-most-k-distinct-characters
@Language: Python
@Datetime: 16-08-06 00:43
'''

class Solution:
    # @param s : A string
    # @return : An integer
    def lengthOfLongestSubstringKDistinct(self, s, k):
        # write your code here
        if not s or len(s) == 0 or k == 0:
            return 0
        dic = {}
        maxLen = 0
        j = 0
        for i in range(len(s)):
            while j < len(s) and len(dic) < k:
                if s[j] not in dic:
                    dic[s[j]] = 1
                else:
                    dic[s[j]] += 1
                j += 1
            while j < len(s) and s[j] in dic:
                dic[s[j]] += 1
                j += 1
            maxLen = max(maxLen,j-i)
            if dic[s[i]] > 1:
                dic[s[i]] -= 1
            else:
                del dic[s[i]]
        return maxLen