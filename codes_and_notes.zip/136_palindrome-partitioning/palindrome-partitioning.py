# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/palindrome-partitioning
@Language: Python
@Datetime: 16-07-14 22:29
'''

class Solution:
    # @param s, a string
    # @return a list of lists of string
    def partition(self, s):
        # write your code here
        ans = []
        path = []
        if not s or len(s) == 0:
            return ans
        self.helper(ans, path, 0, s)
        return ans
        
    def isPalindrome(self, s):
        left = 0
        right = len(s)-1
        while left < right:
            if s[left] != s[right]:
                return False
            left += 1
            right -= 1
        return True
        
    def helper(self, ans, path, pos, s):
        if pos == len(s):
            ans.append(list(path))
            return 
        for i in range(pos+1, len(s)+1):
            substring = s[pos:i]
            if not self.isPalindrome(substring):
                continue
            path.append(substring)
            self.helper(ans, path, i, s)
            path.pop()
    