/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/palindrome-partitioning
@Language: Java
@Datetime: 16-04-07 21:09
*/

public class Solution {
    /**
     * @param s: A string
     * @return: A list of lists of string
     */
    private boolean isPalindrome(String s){
        int start = 0, end = s.length()-1;
        while(start < end){
            if(s.charAt(start) != s.charAt(end)){
                return false;
            }
            start++;
            end--;
        }
        return true;
    }
    private void helper(List<List<String>> result, ArrayList<String> path, int pos, String s){
        if(pos == s.length()){
            result.add(new ArrayList<String>(path));
            return;
        }
        for(int i=pos+1; i<=s.length(); i++){
            String prefix = s.substring(pos,i);
            if(!isPalindrome(prefix)){
                continue;
            }
            path.add(prefix);
            helper(result,path,i,s);
            path.remove(path.size()-1);
        }
    }
    public List<List<String>> partition(String s) {
        // write your code here
        List<List<String>> rst = new ArrayList<List<String>>();
        ArrayList<String> path = new ArrayList<String>();
        if(s == null){
            return rst;
        }
        helper(rst,path,0,s);
        return rst;
    }
}