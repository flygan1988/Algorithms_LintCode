/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/wiggle-sort
@Language: Java
@Datetime: 16-05-26 21:44
*/

public class Solution {
    /**
     * @param nums a list of integer
     * @return void
     */
    public void wiggleSort(int[] nums) {
        // Write your code here
        Arrays.sort(nums);
        int len = nums.length;
        int j = len%2==0?len/2:len/2+1;
        for(int i=0; i<=len&&j<len; i+=2){
            int tmp = nums[j];
            int k = j;
            while(k>i+1){
                nums[k] = nums[k-1];
                k--;
            }
            nums[k] = tmp;
            j++;
        }
    }
}