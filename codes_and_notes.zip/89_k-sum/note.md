```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/k-sum
@Language: Markdown
@Datetime: 16-07-04 18:18
```

http://www.cnblogs.com/yuzhangcmu/p/4279676.html