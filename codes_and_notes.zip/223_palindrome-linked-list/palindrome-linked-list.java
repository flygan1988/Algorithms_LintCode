/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/palindrome-linked-list
@Language: Java
@Datetime: 16-07-02 03:55
*/

/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) { val = x; }
 * }
 */
public class Solution {
    /**
     * @param head a ListNode
     * @return a boolean
     */
    public boolean isPalindrome(ListNode head) {
        // Write your code here
        if(head == null || head.next == null){
            return true;
        }
        ListNode median = findMedian(head);
        ListNode left = head;
        ListNode right = reverse(median.next);
        while(right != null){
            if(left.val != right.val){
                return false;
            }
            left = left.next;
            right = right.next;
        }
        return true;
    }
    public ListNode findMedian(ListNode head){
        ListNode slow = head;
        ListNode fast = head.next;
        while(fast != null && fast.next != null){
            slow = slow.next;
            fast = fast.next.next;
        }
        return slow;
    }
    public ListNode reverse(ListNode head){
        ListNode dummy = new ListNode(-1);
        dummy.next = head;
        ListNode q = head.next;
        while(q != null){
            head.next = q.next;
            q.next = dummy.next;
            dummy.next = q;
            q = head.next;
        }
        return dummy.next;
    }
}