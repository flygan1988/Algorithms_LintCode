# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/linked-list-cycle-ii
@Language: Python
@Datetime: 16-07-10 15:11
'''

"""
Definition of ListNode
class ListNode(object):

    def __init__(self, val, next=None):
        self.val = val
        self.next = next
"""
class Solution:
    """
    @param head: The first node of the linked list.
    @return: The node where the cycle begins. 
                if there is no cycle, return null
    """
    def detectCycle(self, head):
        # write your code here
        if not head:
            return head
        slow = head
        fast = head.next
        while slow != fast:
            if fast and fast.next:
                slow = slow.next
                fast = fast.next.next
            else:
                return None
        while head != slow.next:
            head = head.next
            slow = slow.next
        return head
