/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/remove-element
@Language: Java
@Datetime: 16-06-18 06:31
*/

public class Solution {
    /** 
     *@param A: A list of integers
     *@param elem: An integer
     *@return: The new length after remove
     */
    public int removeElement(int[] A, int elem) {
        // write your code here
        int i = 0, j = 0;
        while(j < A.length){
            while(j < A.length && A[j] == elem){
                j++;
            }
            if(j == A.length && i == 0){
                return 0;
            }
            A[i++] = A[j++];
        }
        return i;
    }
}
