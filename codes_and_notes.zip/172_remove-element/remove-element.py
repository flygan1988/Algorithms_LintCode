# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/remove-element
@Language: Python
@Datetime: 16-08-17 21:49
'''

class Solution:
    """
    @param A: A list of integers
    @param elem: An integer
    @return: The new length after remove
    """
    def removeElement(self, A, elem):
        # write your code here
        i = 0
        j = 0
        while j < len(A):
            while j < len(A) and A[j] == elem:
                j += 1
            if j == len(A):
                break
            A[i] = A[j]
            i += 1
            j += 1
        return i