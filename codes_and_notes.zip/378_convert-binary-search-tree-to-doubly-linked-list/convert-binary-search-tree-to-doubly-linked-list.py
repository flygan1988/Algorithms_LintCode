# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/convert-binary-search-tree-to-doubly-linked-list
@Language: Python
@Datetime: 16-07-10 16:21
'''

"""
Definition of TreeNode:
class TreeNode:
    def __init__(self, val):
        this.val = val
        this.left, this.right = None, None
Definition of Doubly-ListNode
class DoublyListNode(object):

    def __init__(self, val, next=None):
        self.val = val
        self.next = self.prev = next
"""

class Solution:
    """
    @param root, the root of tree
    @return: a doubly list node
    """
    def bstToDoublyList(self, root):
        # Write your code here
        if not root:
            return root
        stack = []
        dummy = ListNode(0)
        pre = dummy
        while len(stack) != 0 or root:
            if root:
                stack.append(root)
                root = root.left
                continue
            if len(stack) != 0:
                now = stack.pop()
                if now.right:
                    root = now.right
                lNode = ListNode(now.val)
                pre.next = lNode
                lNode.pre = pre
                pre = pre.next
        dummy.next.pre = None
        return dummy.next