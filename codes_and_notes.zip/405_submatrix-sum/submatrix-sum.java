/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/submatrix-sum
@Language: Java
@Datetime: 16-06-21 18:38
*/

public class Solution {
    /**
     * @param matrix an integer matrix
     * @return the coordinate of the left-up and right-down number
     */
    public int[][] submatrixSum(int[][] matrix) {
        // Write your code here
        int m = matrix.length;
        int n = matrix[0].length;
        int[][] result = new int[2][2];
        int[][] preSum = new int[m+1][n+1];
        for(int i=0; i<n+1; i++){
            preSum[0][i] = 0;
        }
        for(int i=0; i<m+1; i++){
            preSum[i][0] = 0;
        }
        //calculate the preSum
        for(int i=1; i<m+1; i++){
            for(int j=1; j<n+1; j++){
                preSum[i][j] = preSum[i-1][j] + preSum[i][j-1] - preSum[i-1][j-1] + matrix[i-1][j-1];
            }
        }
        //calculate the submatrix sum where the sum of numbers is zero;
        for(int l=0; l<m; l++){
            for(int h=l+1; h<m+1; h++){
                HashMap<Integer,Integer> map = new HashMap<>();
                for(int j=0; j<n+1; j++){
                    int diff = preSum[h][j] - preSum[l][j];
                    if(map.containsKey(diff)){
                        result[0][0] = l; result[0][1] = map.get(diff);
                        result[1][0] = h-1; result[1][1] = j-1;
                    }else{
                        map.put(diff,j);
                    }
                }
            }
        }
        return result;
    }
    public int[] subarraySum(ArrayList<Integer> list){
        int[] res = new int[2];
        ArrayList<Integer> preSum = new ArrayList<Integer>();
        int sum = 0;
        preSum.add(0);
        for(int i=0; i<list.size(); i++){
            sum += list.get(i);
            preSum.add(sum);
        }
        for(int i=0; i<preSum.size(); i++){
            for(int j=i+1; j<preSum.size(); j++){
                if(preSum.get(i)==preSum.get(j)){
                    res[0] = i;
                    res[1] = j-1;
                    return res;
                }
            }
        }
        return res;
    }
}