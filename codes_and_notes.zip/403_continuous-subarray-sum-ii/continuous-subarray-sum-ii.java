/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/continuous-subarray-sum-ii
@Language: Java
@Datetime: 16-05-26 20:27
*/

public class Solution {
    /**
     * @param A an integer array
     * @return  A list of integers includes the index of the first number and the index of the last number
     */
    public ArrayList<Integer> continuousSubarraySumII(int[] A) {
        // Write your code here
        ArrayList<Integer> res = new ArrayList<Integer>();
        int bestStart = 0, bestEnd = 0;
        int start = 0, end = 0;
        int sum = 0, total = 0;
        int global = Integer.MIN_VALUE;
        for(int i=0; i<A.length; i++){
            total += A[i];
            if(sum<0){
                sum = A[i];
                start = end = i;
            }
            else{
                sum += A[i];
                end = i;
            }
            if(sum > global){
                global = sum;
                bestStart = start;
                bestEnd = end;
            }
        }
        start = 0;
        end = 0;
        sum = 0;
        for(int i=0; i<A.length; i++){
            if(sum>0){
                sum = A[i];
                start = end = i;
            }
            else{
                sum += A[i];
                end = i;
            }
            if(start == 0 && end == A.length-1) continue;
            if(total-sum > global){
                global = total - sum;
                bestStart = (end+1)%A.length;
                bestEnd = (start+A.length-1)%A.length;
            }
        }
        res.add(bestStart);
        res.add(bestEnd);
        return res;
        
    }
}