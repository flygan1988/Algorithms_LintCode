```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/paint-house
@Language: Markdown
@Datetime: 16-07-03 03:37
```

r/b/g in the i-th loop means the minimum costs to paint the i-th house in red/blue/green respectively plus painting the previous houses. The time and space complexities are still ofO(n) and O(1).