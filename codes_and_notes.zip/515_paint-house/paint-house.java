/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/paint-house
@Language: Java
@Datetime: 16-07-03 03:37
*/

public class Solution {
    /**
     * @param costs n x 3 cost matrix
     * @return an integer, the minimum cost to paint all houses
     */
    public int minCost(int[][] costs) {
        // Write your code here
        if(costs == null || costs.length == 0){
            return 0;
        }
        int r=0, b=0, g=0;
        for(int i=0; i<costs.length; i++){
            int rr = r, bb = b, gg = g;
            r = costs[i][0] + Math.min(bb,gg);
            b = costs[i][1] + Math.min(rr,gg);
            g = costs[i][2] + Math.min(rr,bb);
        }
        return Math.min(Math.min(r,b),g);
    }
}