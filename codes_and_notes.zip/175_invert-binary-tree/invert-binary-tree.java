/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/invert-binary-tree
@Language: Java
@Datetime: 16-05-22 22:32
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @param root: a TreeNode, the root of the binary tree
     * @return: nothing
     */
    //solution 1: recursion
    /**
    public void invertBinaryTree(TreeNode root) {
        // write your code here
        if(root == null){
            return;
        }
        TreeNode tmp = root.left;
        root.left = root.right;
        root.right = tmp;
        invertBinaryTree(root.left);
        invertBinaryTree(root.right);
    }**/
    //solution 2: no recursion
    public void invertBinaryTree(TreeNode root){
        Queue<TreeNode> q = new LinkedList<>();
        ArrayList<TreeNode> list = new ArrayList<>();
        q.offer(root);
        while(!q.isEmpty()){
            TreeNode now = q.poll();
            if(now.left != null){
                q.offer(now.left);
            }
            if(now.right != null){
                q.offer(now.right);
            }
            list.add(now);
        }
        for(TreeNode node:list){
            TreeNode tmp = node.left;
            node.left = node.right;
            node.right = tmp;
        }
    }
}