# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/minimum-size-subarray-sum
@Language: Python
@Datetime: 16-08-11 02:45
'''

class Solution:
     # @param nums: a list of integers
     # @param s: an integer
     # @return: an integer representing the minimum size of subarray
    def minimumSize(self, nums, s):
        # write your code here
        
        minLen = sys.maxint
        Sum = 0
        j = 0
        for i in range(len(nums)):
            while j < len(nums) and Sum < s:
                Sum += nums[j]
                j += 1
            if Sum >= s and j-i < minLen:
                minLen = j-i
            Sum -= nums[i]
        if minLen == sys.maxint:
            return -1
        return minLen