/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/minimum-size-subarray-sum
@Language: Java
@Datetime: 16-05-20 23:37
*/

public class Solution {
    /**
     * @param nums: an array of integers
     * @param s: an integer
     * @return: an integer representing the minimum size of subarray
     */
    public int minimumSize(int[] nums, int s) {
        // write your code here
        int i = 0, j=0;
        int sum = 0;
        int ans = Integer.MAX_VALUE;
        for(;i<nums.length;i++){
            while(j<nums.length && sum<s){
                sum += nums[j];
                j++;
            }
            if(sum >= s){
                ans = Math.min(ans,j-i);
            }
            sum -= nums[i];
        }
        if(ans == Integer.MAX_VALUE){
            ans = -1;
        }
        return ans;
    }
}