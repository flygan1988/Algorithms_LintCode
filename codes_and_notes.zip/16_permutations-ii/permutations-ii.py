# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/permutations-ii
@Language: Python
@Datetime: 16-07-15 02:52
'''

class Solution:
    """
    @param nums: A list of integers.
    @return: A list of unique permutations.
    """
    def permuteUnique(self, nums):
        # write your code here
        ans = []
        if not nums or len(nums) == 0:
            return ans
        path = []
        visit = [False for i in range(len(nums))]
        nums.sort()
        self.helper(ans, path, visit, nums)
        return ans
        
    def helper(self, ans, path, visit, nums):
        if len(path) == len(nums):
            ans.append(list(path))
            return
        for i in range(len(nums)):
            if visit[i] or (i != 0 and nums[i] == nums[i-1] and not visit[i-1]):
                continue
            path.append(nums[i])
            visit[i] = True
            self.helper(ans, path, visit, nums)
            path.pop()
            visit[i] = False
