/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/construct-binary-tree-from-preorder-and-inorder-traversal
@Language: Java
@Datetime: 16-07-05 02:26
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
 
 
public class Solution {
    /**
     *@param preorder : A list of integers that preorder traversal of a tree
     *@param inorder : A list of integers that inorder traversal of a tree
     *@return : Root of a tree
     */
    public TreeNode buildTree(int[] preorder, int[] inorder) {
        // write your code here
        if(preorder.length == 0 || inorder.length == 0 || preorder.length != inorder.length){
            return null;
        }
        TreeNode root = new TreeNode(preorder[0]);
        int index = findIndex(inorder,preorder[0]);
        int[] leftInorder = new int[index];
        int[] rightInorder = new int[inorder.length-index-1];
        int[] leftPreorder = new int[index];
        int[] rightPreorder = new int[inorder.length-index-1];
        System.arraycopy(inorder,0,leftInorder,0,leftInorder.length);
        System.arraycopy(inorder,index+1,rightInorder,0,rightInorder.length);
        System.arraycopy(preorder,1,leftPreorder,0,leftPreorder.length);
        System.arraycopy(preorder,1+index,rightPreorder,0,rightPreorder.length);
        root.left = buildTree(leftPreorder,leftInorder);
        root.right = buildTree(rightPreorder,rightInorder);
        return root;
    }
    public int findIndex(int[] A, int target){
        for(int i=0; i<A.length; i++){
            if(A[i] == target){
                return i;
            }
        }
        return -1;
    }
}