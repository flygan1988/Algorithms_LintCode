/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/wood-cut
@Language: Java
@Datetime: 16-06-22 03:36
*/

public class Solution {
    /** 
     *@param L: Given n pieces of wood with length L[i]
     *@param k: An integer
     *return: The maximum length of the small pieces.
     */
    public int woodCut(int[] L, int k) {
        // write your code here
        int max = findMax(L);
        //int pieces = 0;
        int left = 1;
        int right = max;
        while(left < right-1){
            int mid = left + (right-left)/2;
            if(count(L,mid) >= k){
                left = mid;
            }
            else{
                right = mid;
            }
        }
        if(count(L,right) >= k){
            return right;
        }
        if(count(L,left) >= k){
            return left;
        }
        return 0;
    }
    public int findMax(int[] L){
        int max = Integer.MIN_VALUE;
        for(int i=0; i<L.length; i++){
            if(L[i] > max){
                max = L[i];
            }
        }
        return max;
    }
    private int count(int[] L, int length) {
        int sum = 0;
        for (int i = 0; i < L.length; i++) {
            sum += L[i] / length;
        }
        return sum;
    }
}