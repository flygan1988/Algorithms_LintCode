# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/sort-list
@Language: Python
@Datetime: 16-07-10 14:19
'''

"""
Definition of ListNode
class ListNode(object):

    def __init__(self, val, next=None):
        self.val = val
        self.next = next
"""
class Solution:
    """
    @param head: The first node of the linked list.
    @return: You should return the head of the sorted linked list,
                  using constant space complexity.
    """
    def sortList(self, head):
        # write your code here
        if not head or not head.next:
            return head
        median = self.findMedian(head)
        left = head
        right = median.next
        median.next = None
        leftSortedList = self.sortList(left)
        rightSortedList = self.sortList(right)
        return self.mergeTwoList(leftSortedList, rightSortedList)
        
    def mergeTwoList(self, head1, head2):
        dummy = ListNode(0)
        pre = dummy
        while head1 and head2:
            if head1.val < head2.val:
                pre.next = head1
                head1 = head1.next
            else:
                pre.next = head2
                head2 = head2.next
            pre = pre.next
        if not head1:
            pre.next = head2
        if not head2:
            pre.next = head1
        return dummy.next
        
    def findMedian(self, head):
        slow = head
        fast = head.next
        while fast and fast.next:
            slow = slow.next
            fast = fast.next.next
        return slow