/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/sort-list
@Language: Java
@Datetime: 16-03-27 21:45
*/

/**
 * Definition for ListNode.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int val) {
 *         this.val = val;
 *         this.next = null;
 *     }
 * }
 */ 
public class Solution {
    /**
     * @param head: The head of linked list.
     * @return: You should return the head of the sorted linked list,
                    using constant space complexity.
     */
    private ListNode findMiddle(ListNode head){
        if(head == null || head.next == null){
            return head;
        }
        ListNode slow = head;
        ListNode fast = head.next;
        while(fast != null && fast.next != null){
            slow = slow.next;
            fast = fast.next.next;
        }
        return slow;
    }
    private ListNode mergeTwoList(ListNode head1, ListNode head2){
        ListNode dummy = new ListNode(0);
        ListNode newHead = dummy;
        while(head1 != null && head2 != null){
            if(head1.val <= head2.val){
                newHead.next = head1;
                //newHead = newHead.next;
                head1 = head1.next;
            }
            else{
                newHead.next = head2;
                //newHead = newHead.next;
                head2 = head2.next;
            }
            newHead = newHead.next;
        }
        if(head1 == null){
            newHead.next = head2;
        }
        if(head2 == null){
            newHead.next = head1;
        }
        return dummy.next;
    }
    
    public ListNode sortList(ListNode head) {  
        // write your code here
        if(head == null || head.next == null){
            return head;
        }
        ListNode mid = findMiddle(head);
        ListNode right = sortList(mid.next);
        mid.next = null;
        ListNode left = sortList(head);
        return mergeTwoList(left,right);
    }
}
