```
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/sort-list
@Language: Markdown
@Datetime: 16-07-10 14:19
```

Use merge sorting:
first step: find the middle node of a list;
second step: divide the list into two sublists using the middle node;
third step: sort the two sublists respectively;
forth step: merge the two sorted sublists.