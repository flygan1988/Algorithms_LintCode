# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/sort-letters-by-case
@Language: Python
@Datetime: 16-07-13 18:49
'''

class Solution:
    """
    @param chars: The letters array you should sort.
    """
    def sortLetters(self, chars):
        # write your code here
        left = 0
        right = len(chars)-1
        while left < right:
            while chars[right].isupper() and left < right:
                right -= 1
            while chars[left].islower() and left < right:
                left += 1
            tmp = chars[left]
            chars[left] = chars[right]
            chars[right] = tmp
        