/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/rotate-string
@Language: Java
@Datetime: 16-06-18 16:18
*/

public class Solution {
    /**
     * @param str: an array of char
     * @param offset: an integer
     * @return: nothing
     */
    public void rotateString(char[] str, int offset) {
        // write your code here
        if(str == null || str.length == 0 || offset % str.length == 0){
            return;
        }
        int n = offset % str.length;
        while(n-- > 0){
            Character c = str[str.length-1];
            for(int i=str.length-1; i>0; i--){
                str[i] = str[i-1];
            }
            str[0] = c;
        }
    }
}