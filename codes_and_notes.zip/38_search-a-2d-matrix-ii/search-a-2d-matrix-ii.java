/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/search-a-2d-matrix-ii
@Language: Java
@Datetime: 16-06-29 05:02
*/

public class Solution {
    /**
     * @param matrix: A list of lists of integers
     * @param: A number you want to search in the matrix
     * @return: An integer indicate the occurrence of target in the given matrix
     */
    public int searchMatrix(int[][] matrix, int target) {
        // write your code here
        if(matrix == null || matrix.length == 0){
            return 0;
        }
        int count = 0;
        int m = matrix.length;
        int n = matrix[0].length;
        int i=m-1, j=0;
        while(i>=0 && j<n){
            if(target == matrix[i][j]){
                count++;
                i--;
                j++;
            }else if(target < matrix[i][j]){
                i--;
            }else{
                j++;
            }
        }
        return count;
    }
}
