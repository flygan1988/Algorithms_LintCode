/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/find-the-missing-number
@Language: Java
@Datetime: 16-06-20 23:07
*/

public class Solution {
    /**    
     * @param nums: an array of integers
     * @return: an integer
     */
    public int findMissing(int[] nums) {
        // write your code here
        int len = nums.length;
        int sum = len * (len+1) / 2;
        for(int i=0; i<len; i++){
            sum -= nums[i];
        }
        return sum;
    }
}