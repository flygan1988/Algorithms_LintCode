/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/distinct-subsequences
@Language: Java
@Datetime: 16-05-31 18:25
*/

public class Solution {
    /**
     * @param S, T: Two string.
     * @return: Count the number of distinct subsequences
     */
    //Solution 1
    /**
    public int numDistinct(String S, String T) {
        // write your code here
        if(T.length() == 0) return 1;
        if(S.length() == 0) return 0;
        int[] res = new int[T.length()+1];
        res[0] = 1;
        for(int i=0; i<S.length(); i++){
            for(int j=T.length()-1; j>=0; j--){
                res[j+1] = (S.charAt(i) == T.charAt(j)?res[j]:0) + res[j+1];
            }
        }
        return res[T.length()];
    }**/
    //Solution 2
    public int numDistinct(String S, String T) {
        // write your code here
        if(T.length() == 0) return 1;
        if(S.length() == 0) return 0;
        int[][] res = new int[S.length()+1][T.length()+1];
        for(int i=0; i<S.length()+1; i++){
            res[i][0] = 1;
        }
        for(int i=1; i<T.length()+1; i++){
            res[0][i] = 0;
        }
        for(int i=1; i<S.length()+1; i++){
            for(int j=1; j<T.length()+1; j++){
                res[i][j] = S.charAt(i-1) == T.charAt(j-1)?res[i-1][j]+res[i-1][j-1]:res[i-1][j];
            }
        }
        return res[S.length()][T.length()];
    }
}