# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/distinct-subsequences
@Language: Python
@Datetime: 16-07-09 17:48
'''

class Solution: 
    # @param S, T: Two string.
    # @return: Count the number of distinct subsequences
    def numDistinct(self, S, T):
        # write your code here
        if len(S) == 0:
            return 0
        if len(T) == 0:
            return 1
        m = len(S)
        n = len(T)
        
        f = [[0 for i in range(0,n+1)] for j in range(0,m+1)]
        
        for i in range(0,m+1):
            f[i][0] = 1
        
        for i in range(1,m+1):
            for j in range(1,n+1):
                if S[i-1] == T[j-1]:
                    f[i][j] = f[i-1][j] + f[i-1][j-1]
                else:
                    f[i][j] = f[i-1][j]
        return f[m][n]