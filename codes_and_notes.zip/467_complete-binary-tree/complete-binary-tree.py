# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/complete-binary-tree
@Language: Python
@Datetime: 16-07-08 04:50
'''

"""
Definition of TreeNode:
class TreeNode:
    def __init__(self, val):
        this.val = val
        this.left, this.right = None, None
"""
class Solution:
    """
    @param root, the root of binary tree.
    @return true if it is a complete binary tree, or false.
    """
    def isComplete(self, root):
        # Write your code here
        if root is None:
            return True
        if self.isPerfect(root):
            return True
        if self.isComplete(root.left) and self.isPerfect(root.right) and self.getHeight(root.left) == self.getHeight(root.right)+1:
            return True
        if self.isPerfect(root.left) and self.isComplete(root.right) and self.getHeight(root.left) == self.getHeight(root.right):
            return True
        return False
        
    def getHeight(self,root):
        if root is None:
            return -1
        return max(self.getHeight(root.left),self.getHeight(root.right))+1
    
    def isPerfect(self,root):
        if root is None:
            return True
        if root.left is None and root.right is not None:
            return False
        if root.right is None and root.left is not None:
            return False
        left = self.getHeight(root.left)
        right = self.getHeight(root.right)
        if left != right:
            return False
        return self.isPerfect(root.left) and self.isPerfect(root.right)