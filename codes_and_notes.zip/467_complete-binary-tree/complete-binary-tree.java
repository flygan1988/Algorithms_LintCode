/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/complete-binary-tree
@Language: Java
@Datetime: 16-06-12 16:40
*/

/**
 * Definition of TreeNode:
 * public class TreeNode {
 *     public int val;
 *     public TreeNode left, right;
 *     public TreeNode(int val) {
 *         this.val = val;
 *         this.left = this.right = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @param root, the root of binary tree.
     * @return true if it is a complete binary tree, or false.
     */
    public boolean isComplete(TreeNode root) {
        // Write your code here
        if(root == null){
            return true;
        }
        Queue<TreeNode> queue = new LinkedList<TreeNode>();
        ArrayList<TreeNode> list = new ArrayList<TreeNode>();
        queue.offer(root);
        while(!queue.isEmpty()){
            TreeNode tmp = queue.poll();
            list.add(tmp);
            if(tmp == null) continue;
            if(tmp.left == null && tmp.right != null){
                return false;
            }
            queue.offer(tmp.left);
            queue.offer(tmp.right);
        }
        int index = 0;
        for(int i=0; i<list.size(); i++){
            if(list.get(i) == null){
                index = i;
                break;
            }
        }
        for(int i=index+1; i<list.size(); i++){
            if(list.get(i) != null){
                return false;
            }
        }
        return true;
    }
    private int height(TreeNode root){
        if(root == null){
            return 0;
        }
        return Math.max(height(root.left),height(root.right))+1;
    }
    private boolean isFull(TreeNode root){
        if(root == null){
            return true;
        }
        if((root.left == null && root.right != null) || (root.left != null && root.right == null)){
            return false;
        }
        return isFull(root.left) && isFull(root.right);
    }
}