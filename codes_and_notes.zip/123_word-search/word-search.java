/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/word-search
@Language: Java
@Datetime: 16-07-15 22:53
*/

public class Solution {
    /**
     * @param board: A list of lists of character
     * @param word: A string
     * @return: A boolean
     */
    public boolean exist(char[][] board, String word) {
        // write your code here
        if(word == null || word.length() == 0){
            return true;
        }
        int m = board.length;
        int n = board[0].length;
        boolean[][] visited = new boolean[m][n];
        //boolean isExist = false;
        for(int i=0; i<m; i++){
            for(int j=0; j<n; j++){
                if(helper(board,i,j,word,0,visited)){
                    return true;
                }
            }
        }
        return false;
    }
    public boolean helper(char[][] board, int x, int y, String word, int pos, boolean[][] visited){
        if(x<0 || x>=board.length || y<0 || y>=board[0].length || board[x][y] != word.charAt(pos)){
            return false;
        }
        if(!visited[x][y] && board[x][y] == word.charAt(pos)){
            if(pos == word.length()-1){
                return true;
            }
            visited[x][y] = true;
            boolean up = helper(board,x-1,y,word,pos+1,visited);
            boolean down = helper(board,x+1,y,word,pos+1,visited);
            boolean left = helper(board,x,y-1,word,pos+1,visited);
            boolean right = helper(board,x,y+1,word,pos+1,visited);
            boolean res = up || down || left || right;
            visited[x][y] = up || down || left || right;
            if(res) return true;
        }
        return false;
    }
}