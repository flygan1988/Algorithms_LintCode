# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/word-search
@Language: Python
@Datetime: 16-07-28 01:25
'''

class Solution:
    # @param board, a list of lists of 1 length string
    # @param word, a string
    # @return a boolean
    def exist(self, board, word):
        # write your code here
        m = len(board)
        n = len(board[0])
        visit = [[False for i in range(n)] for j in range(m)]
        for i in range(m):
            for j in range(n):
                if self.search(board,i,j,visit,word,0):
                    return True
        return False
        
    def search(self, board, x, y, visit, word, index):
        if x<0 or x>=len(board) or y<0 or y>=len(board[0]) or board[x][y] != word[index]:
            return False
        if index==len(word)-1 and not visit[x][y] and board[x][y]==word[index]:
            return True
        if word[index] == board[x][y] and not visit[x][y]:
            visit[x][y] = True
            result = False
            left = self.search(board,x,y-1,visit,word,index+1)
            right = self.search(board,x,y+1,visit,word,index+1)
            up = self.search(board,x-1,y,visit,word,index+1)
            down = self.search(board,x+1,y,visit,word,index+1)
            result = left or right or up or down
            visit[x][y] = result
            if result:
                return True
        return False