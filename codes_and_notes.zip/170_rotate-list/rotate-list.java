/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/rotate-list
@Language: Java
@Datetime: 16-03-29 04:27
*/

/**
 * Definition for singly-linked list.
 * public class ListNode {
 *     int val;
 *     ListNode next;
 *     ListNode(int x) {
 *         val = x;
 *         next = null;
 *     }
 * }
 */
public class Solution {
    /**
     * @param head: the List
     * @param k: rotate to the right k places
     * @return: the list after rotation
     */
    private int totalNodes(ListNode head){
        int count = 0;
        while(head != null){
            count++;
            head = head.next;
        }
        return count;
    }
  
    public ListNode rotateRight(ListNode head, int k) {
        // write your code here
        if(head == null){
            return head;
        }
        int count = totalNodes(head);
        k = k % count;
        ListNode dummy = new ListNode(0);
        dummy.next = head;
        head = dummy;
        ListNode tail = dummy;
        for(int i=0; i<k; i++){
            head = head.next;
        }
        while(head.next != null){
            tail = tail.next;
            head = head.next;
        }
        
        head.next = dummy.next;
        dummy.next = tail.next;
        tail.next = null;
        return dummy.next;
    }
}