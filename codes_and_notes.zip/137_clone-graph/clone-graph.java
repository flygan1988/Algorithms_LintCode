/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/clone-graph
@Language: Java
@Datetime: 16-04-05 04:35
*/

/**
 * Definition for undirected graph.
 * class UndirectedGraphNode {
 *     int label;
 *     ArrayList<UndirectedGraphNode> neighbors;
 *     UndirectedGraphNode(int x) { label = x; neighbors = new ArrayList<UndirectedGraphNode>(); }
 * };
 */
public class Solution {
    /**
     * @param node: A undirected graph node
     * @return: A undirected graph node
     */
    public UndirectedGraphNode cloneGraph(UndirectedGraphNode node) {
        // write your code here
        if(node == null){
            return null;
        }
        HashMap<UndirectedGraphNode,UndirectedGraphNode> map = new HashMap<UndirectedGraphNode,UndirectedGraphNode>();
        ArrayList<UndirectedGraphNode> list = new ArrayList<UndirectedGraphNode>();
        map.put(node,new UndirectedGraphNode(node.label));
        list.add(node);
        int i = 0;
        //clone nodes
        while(i<list.size()){
            UndirectedGraphNode newNode = list.get(i++);
            for(int j=0; j<newNode.neighbors.size(); j++){
                UndirectedGraphNode neighbor = newNode.neighbors.get(j);
                if(!map.containsKey(neighbor)){
                    map.put(neighbor,new UndirectedGraphNode(neighbor.label));
                    list.add(neighbor);
                }
            }
        }
        //clone edges
        for(int k=0; k<list.size(); k++){
            UndirectedGraphNode temp = map.get(list.get(k));
            for(int j=0; j<list.get(k).neighbors.size(); j++){
                temp.neighbors.add(map.get(list.get(k).neighbors.get(j)));
            }
        }
        return map.get(node);
    }
}