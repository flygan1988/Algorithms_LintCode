# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/clone-graph
@Language: Python
@Datetime: 16-08-13 17:49
'''

# Definition for a undirected graph node
# class UndirectedGraphNode:
#     def __init__(self, x):
#         self.label = x
#         self.neighbors = []
class Solution:
    # @param node, a undirected graph node
    # @return a undirected graph node
    def __init__(self):
        self.dict = {}
        
    def cloneGraph(self, node):
        # write your code here
        if not node:
            return node
        newNode = UndirectedGraphNode(node.label)
        self.dict[node] = newNode
        queue = []
        visit = {}
        visit[node] = True
        queue.insert(0,node)
        while len(queue) != 0:
            now = queue.pop()
            copy = self.dict[now]
            for n in now.neighbors:
                if n in self.dict:
                    copy.neighbors.append(self.dict[n])
                else:
                    new = UndirectedGraphNode(n.label)
                    copy.neighbors.append(new)
                    self.dict[n] = new
                if n not in visit:
                    queue.append(n)
                    visit[n] = True
        return newNode    