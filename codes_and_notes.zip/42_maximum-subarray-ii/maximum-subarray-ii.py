# coding:utf-8
'''
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/maximum-subarray-ii
@Language: Python
@Datetime: 16-07-14 00:09
'''

class Solution:
    """
    @param nums: A list of integers
    @return: An integer denotes the sum of max two non-overlapping subarrays
    """
    
    def preSum(self, nums):
        pre = []
        Max = -sys.maxint
        minSum = Sum = 0
        for i in range(len(nums)):
            Sum += nums[i]
            Max = max(Max, Sum-minSum)
            minSum = min(minSum, Sum)
            pre.append(Max)
        return pre
        
    def postSum(self, nums):
        post = []
        Max = -sys.maxint
        minSum = Sum = 0
        for i in range(len(nums)-1,-1,-1):
            Sum += nums[i]
            Max = max(Max, Sum-minSum)
            minSum = min(minSum, Sum)
            post.insert(0,Max)
        return post
        
    def maxTwoSubArrays(self, nums):
        # write your code here
        pre = self.preSum(nums)
        post = self.postSum(nums)
        
        maxSum = -sys.maxint
        for i in range(len(nums)-1):
            maxSum = max(maxSum, pre[i]+post[i+1])
        return maxSum
