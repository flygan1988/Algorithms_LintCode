/*
@Copyright:LintCode
@Author:   fly
@Problem:  http://www.lintcode.com/problem/maximum-subarray-ii
@Language: Java
@Datetime: 16-04-04 02:08
*/

public class Solution {
    /**
     * @param nums: A list of integers
     * @return: An integer denotes the sum of max two non-overlapping subarrays
     */
    private int maxSubArray(ArrayList<Integer> nums, int start, int end){
        if(start == end){
            return nums.get(start);
        }
        int sum = 0, minSum = 0;
        int max = Integer.MIN_VALUE;
        for(int i=start; i<=end; i++){
            sum += nums.get(i);
            max = Math.max(max,sum-minSum);
            minSum = Math.min(sum,minSum);
        }
        return max;
    }
    public int maxTwoSubArrays(ArrayList<Integer> nums) {
        // write your code
        int sum = Integer.MIN_VALUE;
        for(int i=0; i<nums.size()-1; i++){
            sum = Math.max(sum,maxSubArray(nums,0,i)+maxSubArray(nums,i+1,nums.size()-1));
        }
        return sum;
    }
}

